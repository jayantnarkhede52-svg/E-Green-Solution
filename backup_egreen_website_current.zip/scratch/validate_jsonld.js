const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const files = fs.readdirSync(ROOT).filter(f => f.endsWith('.html'));

// Also check blog files
const blogDir = path.join(ROOT, 'blog');
if (fs.existsSync(blogDir)) {
    const blogFiles = fs.readdirSync(blogDir).filter(f => f.endsWith('.html')).map(f => path.join('blog', f));
    files.push(...blogFiles);
}

let errorCount = 0;
let jsonLdCount = 0;

for (const file of files) {
    const fullPath = path.join(ROOT, file);
    const content = fs.readFileSync(fullPath, 'utf8');
    const regex = /<script type="application\/ld\+json">([\s\S]*?)<\/script>/gi;
    let match;

    while ((match = regex.exec(content)) !== null) {
        jsonLdCount++;
        const jsonText = match[1].trim();
        try {
            JSON.parse(jsonText);
        } catch (err) {
            console.error(`❌ JSON-LD Parse Error in ${file}:`, err.message);
            console.error('Snippet:', jsonText.slice(0, 150));
            errorCount++;
        }
    }
}

console.log(`\nVerified ${jsonLdCount} JSON-LD blocks across ${files.length} HTML files.`);
if (errorCount === 0) {
    console.log('🎉 100% Valid JSON-LD across all pages! No syntax errors.');
} else {
    console.error(`Found ${errorCount} JSON-LD errors.`);
    process.exit(1);
}
