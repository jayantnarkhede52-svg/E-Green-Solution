const http = require('http');

const urls = [
  '/areas',
  '/solar-panel-pune',
  '/solar-panel-pimpri-chinchwad',
  '/solar-panel-baner-bavdhan',
  '/solar-panel-bhosari-pcmc',
  '/solar-panel-chakan',
  '/solar-panel-kiwale',
  '/solar-panel-lonavala'
];

let completed = 0;

urls.forEach(path => {
  http.get(`http://localhost:3000${path}`, (res) => {
    console.log(`GET ${path} -> Status: ${res.statusCode} (${res.headers['content-type']})`);
    completed++;
    if (completed === urls.length) {
      console.log('ALL 8 PAGES RESPONDED 200 OK!');
    }
  }).on('error', (err) => {
    console.error(`Error requesting ${path}: ${err.message}`);
  });
});
