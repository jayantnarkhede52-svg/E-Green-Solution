const fs = require('fs');
const path = require('path');
const http = require('http');

const blogDir = 'c:\\work\\E GREEN WEBSITE\\blog';
const blogFiles = fs.readdirSync(blogDir).filter(f => f.endsWith('.html'));

console.log('=== 1. VALIDATING JSON-LD SCHEMAS IN BLOG FILES ===');
let schemaErrors = 0;
for (const file of blogFiles) {
    const fullPath = path.join(blogDir, file);
    const content = fs.readFileSync(fullPath, 'utf8');
    const matches = content.match(/<script\s+type=["']application\/ld\+json["']>([\s\S]*?)<\/script>/gi);
    if (!matches || matches.length === 0) {
        console.error(`[ERROR] No JSON-LD found in ${file}`);
        schemaErrors++;
    } else {
        matches.forEach((m, idx) => {
            const rawJson = m.replace(/<script[^>]*>/i, '').replace(/<\/script>/i, '').trim();
            try {
                const parsed = JSON.parse(rawJson);
                console.log(`[PASS] ${file} -> Schema #${idx + 1} (${parsed['@type'] || 'Custom'}) is valid JSON`);
            } catch (err) {
                console.error(`[FAIL] ${file} -> Schema #${idx + 1} JSON PARSE ERROR:`, err.message);
                schemaErrors++;
            }
        });
    }
}

console.log('\n=== 2. AUDIT INTEGRITY CHECKS (Section 80D, hits.sh, NAP) ===');
let auditErrors = 0;
for (const file of blogFiles) {
    const fullPath = path.join(blogDir, file);
    const content = fs.readFileSync(fullPath, 'utf8');

    if (content.includes('Section 80D') || content.includes('80D')) {
        console.error(`[FAIL] ${file} contains Section 80D reference!`);
        auditErrors++;
    }
    if (content.includes('hits.sh')) {
        console.error(`[FAIL] ${file} contains hits.sh tracking!`);
        auditErrors++;
    }
    if (!content.includes('7249187969')) {
        console.warn(`[WARN] ${file} missing canonical phone number!`);
        auditErrors++;
    }
    if (!content.includes('Dhankawadi')) {
        console.warn(`[WARN] ${file} missing canonical office location!`);
        auditErrors++;
    }
}
if (auditErrors === 0) {
    console.log('[PASS] All blog files pass audit compliance checks!');
}

console.log('\n=== 3. HTTP ROUTE VERIFICATION (localhost:3000) ===');
const routesToTest = [
    '/blog',
    '/blog/bifacial-solar-panels-pune',
    '/blog/mono-perc-vs-topcon-solar-pune',
    '/blog/dcr-solar-panels-pune',
    '/blog/hybrid-solar-system-lithium-battery-pune',
    '/blog/enphase-microinverter-installers-pune',
    '/blog/on-grid-solar-inverter-dealers-pune',
    '/blog/elevated-rooftop-solar-structure-pune',
    // also check core pages
    '/',
    '/services',
    '/solar-guide',
    '/calculator',
    '/solar-subsidy',
    '/solar-panel-cleaning-pune',
    '/solar-amc-pune',
    '/solar-repair-maintenance-pune',
    '/solar-inverter-repair-pune',
    '/solar-net-meter-msedcl-pune',
    '/solar-plant-revamping-repowering'
];

function checkRoute(route) {
    return new Promise((resolve) => {
        http.get(`http://localhost:3000${route}`, (res) => {
            console.log(`[HTTP ${res.statusCode}] ${route}`);
            resolve({ route, status: res.statusCode });
        }).on('error', (err) => {
            console.error(`[CONN ERROR] ${route} ->`, err.message);
            resolve({ route, status: 'CONN_ERR' });
        });
    });
}

(async () => {
    let failedRoutes = 0;
    for (const r of routesToTest) {
        const result = await checkRoute(r);
        if (result.status !== 200) {
            failedRoutes++;
        }
    }
    console.log(`\n=== SUMMARY ===`);
    console.log(`Schema Errors: ${schemaErrors}`);
    console.log(`Audit Errors: ${auditErrors}`);
    console.log(`Failed HTTP Routes: ${failedRoutes}`);
})();
