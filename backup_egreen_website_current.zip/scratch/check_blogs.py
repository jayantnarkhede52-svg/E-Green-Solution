import glob, os

files = glob.glob('c:/work/E GREEN WEBSITE/blog/*.html')
for f in files:
    if 'index.html' in f: continue
    with open(f, 'r', encoding='utf-8') as fp:
        c = fp.read()
    print(os.path.basename(f), '--> <article class="article-content">:', '<article class="article-content">' in c)
