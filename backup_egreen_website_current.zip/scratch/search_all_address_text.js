const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const files = fs.readdirSync(ROOT).filter(f => f.endsWith('.html'));
const blogFiles = fs.existsSync(path.join(ROOT, 'blog')) ? fs.readdirSync(path.join(ROOT, 'blog')).filter(f => f.endsWith('.html')).map(f => 'blog/' + f) : [];
const projectFiles = fs.existsSync(path.join(ROOT, 'projects')) ? fs.readdirSync(path.join(ROOT, 'projects')).filter(f => f.endsWith('.html')).map(f => 'projects/' + f) : [];
const all = [...files, ...blogFiles, ...projectFiles];

const addressTextOccurrences = [];

all.forEach(file => {
    const content = fs.readFileSync(path.join(ROOT, file), 'utf8');
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
        // Look for address keywords in HTML text (excluding script tags)
        if (/(Hira Banglow|Nisarg|Pruthvi|Gokul Nagar|Taljai Road|Vidyadeep)/i.test(line)) {
            addressTextOccurrences.push({ file, line: idx + 1, text: line.trim() });
        }
    });
});

console.log('Total occurrences of address keywords:', addressTextOccurrences.length);
addressTextOccurrences.forEach(o => console.log(`${o.file}:${o.line} | ${o.text}`));
