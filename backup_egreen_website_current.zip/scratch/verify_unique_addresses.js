const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const files = fs.readdirSync(ROOT).filter(f => f.endsWith('.html'));
const blogFiles = fs.existsSync(path.join(ROOT, 'blog')) ? fs.readdirSync(path.join(ROOT, 'blog')).filter(f => f.endsWith('.html')).map(f => 'blog/' + f) : [];
const projectFiles = fs.existsSync(path.join(ROOT, 'projects')) ? fs.readdirSync(path.join(ROOT, 'projects')).filter(f => f.endsWith('.html')).map(f => 'projects/' + f) : [];
const all = [...files, ...blogFiles, ...projectFiles];

const addresses = new Set();
const postalCodes = new Set();
const localities = new Set();

all.forEach(file => {
    const content = fs.readFileSync(path.join(ROOT, file), 'utf8');
    const streetRegex = /"streetAddress":\s*"([^"]+)"/g;
    let m;
    while ((m = streetRegex.exec(content)) !== null) {
        addresses.add(m[1]);
    }
    const pinRegex = /"postalCode":\s*"([^"]+)"/g;
    while ((m = pinRegex.exec(content)) !== null) {
        postalCodes.add(m[1]);
    }
    const locRegex = /"addressLocality":\s*"([^"]+)"/g;
    while ((m = locRegex.exec(content)) !== null) {
        localities.add(m[1]);
    }
});

console.log('=== UNIQUE ADDRESSES IN JSON-LD ===');
console.log('Street Addresses count:', addresses.size);
addresses.forEach(a => console.log(' ->', a));

console.log('\nPostal Codes count:', postalCodes.size);
postalCodes.forEach(p => console.log(' ->', p));

console.log('\nLocalities count:', localities.size);
localities.forEach(l => console.log(' ->', l));
