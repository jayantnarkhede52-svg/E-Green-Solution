const fs = require('fs');

const files = [
  'solar-panel-baner-bavdhan.html',
  'solar-panel-bhosari-pcmc.html',
  'solar-panel-chakan.html',
  'solar-panel-kiwale.html',
  'solar-panel-lonavala.html'
];

files.forEach(f => {
  console.log(`\n=== FILE: ${f} ===`);
  const html = fs.readFileSync(f, 'utf8');
  
  // Extract all H2 and their following paragraph
  const h2Matches = [...html.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>([\s\S]*?)(?=<h2|<\/section|<\/main|$)/gi)];
  h2Matches.forEach((m, i) => {
    const h2Title = m[1].replace(/<[^>]+>/g, '').trim();
    const content = m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 180);
    console.log(`  H2 #${i+1}: ${h2Title}`);
    console.log(`    Content sample: ${content}...`);
  });
});
