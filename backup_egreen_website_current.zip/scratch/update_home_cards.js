const fs = require('fs');
const path = require('path');

const indexPath = path.join('c:\\work\\E GREEN WEBSITE', 'index.html');
const cssPath = path.join('c:\\work\\E GREEN WEBSITE', 'css', 'style.css');

let indexContent = fs.readFileSync(indexPath, 'utf8');

// 1. Remove the "Explore Your Solar Power Plant" section completely
const explorerRegex = /<!--\s*Idea 2:\s*Component Explorer\s*-->[\s\S]*?<\/section>/i;
if (explorerRegex.test(indexContent)) {
    indexContent = indexContent.replace(explorerRegex, '');
    console.log('[SUCCESS] Removed Explore Your Solar Power Plant section from index.html');
} else {
    console.error('[ERROR] Could not find Explore Your Solar Power Plant section in index.html');
}

// 2. Replace the 6 service cards in #services-section with enhanced markup
const servicesGridRegex = /<div class="services-grid">([\s\S]*?)<\/div>\s*<\/div>\s*<\/section>\s*<!--\s*Featured Projects/i;
const servicesGridMatch = indexContent.match(servicesGridRegex);

if (servicesGridMatch) {
    const updatedCardsHtml = `<div class="services-grid services-grid-3col">
                <!-- Card 1: Residential Solar -->
                <div class="service-card">
                    <div class="service-icon-box" style="background: #e8f5e9; color: #2e7d32;">
                        <i class="fas fa-home"></i>
                    </div>
                    <h3>Residential Solar Panel Installations</h3>
                    <p>Stop worrying about high power bills. Our residential solar panel installations in Pune slash monthly MSEDCL bills by up to 90% with ₹78,000 PM Surya Ghar subsidy.</p>
                    <a href="/residential-solar" class="service-card-btn">Explore Residential <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- Card 2: Commercial Solar -->
                <div class="service-card">
                    <div class="service-icon-box" style="background: #fff8e1; color: #f57f17;">
                        <i class="fas fa-building"></i>
                    </div>
                    <h3>Commercial Solar Installations</h3>
                    <p>Turn your office or hospital roof into a profit center. We help Pune businesses achieve fast 3-year ROI and 40% tax depreciation with high-yield commercial solar plants.</p>
                    <a href="/industrial-solar" class="service-card-btn">Explore Commercial <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- Card 3: Industrial Solar MIDC -->
                <div class="service-card">
                    <div class="service-icon-box" style="background: #e1f5fe; color: #0288d1;">
                        <i class="fas fa-industry"></i>
                    </div>
                    <h3>Industrial Solar Panel Installations (MIDC)</h3>
                    <p>Heavy-duty turnkey EPC installations for Chakan, Bhosari, and Talegaon MIDC manufacturing plants with Tier-1 Vikram Solar panels and seamless HT grid sync.</p>
                    <a href="/industrial-solar" class="service-card-btn">Explore Industrial <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- Card 4: Solar Water Heaters & Utilities -->
                <div class="service-card">
                    <div class="service-icon-box" style="background: #fbe9e7; color: #e64a19;">
                        <i class="fas fa-water"></i>
                    </div>
                    <h3>Solar Water Heaters &amp; Utilities</h3>
                    <p>MNRE-approved pressurized solar water heating systems and commercial solar thermal solutions for societies, hotels, and hospitals without recurring power costs.</p>
                    <a href="/services" class="service-card-btn">Explore Water Heaters <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- Card 5: Solar AMC & Plant Maintenance -->
                <div class="service-card">
                    <div class="service-icon-box" style="background: #e8f5e9; color: #1b5e20;">
                        <i class="fas fa-file-contract"></i>
                    </div>
                    <h3>Solar AMC &amp; Plant Maintenance</h3>
                    <p>Quarterly electrical checkups, earth resistance testing (&lt;5 ohms), thermal imaging scans, and rapid emergency breakdown support for Pune societies and factories.</p>
                    <a href="/solar-amc-pune" class="service-card-btn">View Solar AMC Plans <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- Card 6: Panel Cleaning & Inverter Repair -->
                <div class="service-card">
                    <div class="service-icon-box" style="background: #e0f2f1; color: #00796b;">
                        <i class="fas fa-broom"></i>
                    </div>
                    <h3>Panel Cleaning &amp; Inverter Repair</h3>
                    <p>Pure demineralized RO water washing restoring up to 25% yield, on-site inverter troubleshooting, and MSEDCL net meter testing liaisoning across Pune &amp; PCMC.</p>
                    <a href="/solar-panel-cleaning-pune" class="service-card-btn">Explore Cleaning &amp; Repair <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Projects`;

    indexContent = indexContent.replace(servicesGridRegex, updatedCardsHtml);
    console.log('[SUCCESS] Updated service cards with 3-per-row markup in index.html');
} else {
    console.error('[ERROR] Could not match services grid in index.html');
}

fs.writeFileSync(indexPath, indexContent, 'utf8');

// 3. Update CSS in css/style.css
let cssContent = fs.readFileSync(cssPath, 'utf8');

// Update .services-grid rules
const oldServiceGridCssRegex = /\/\* === SERVICE CARDS \(home\) === \*\/[\s\S]*?\.service-card p \{[\s\S]*?\}/i;

const newServiceCardCss = `/* === SERVICE CARDS (home) === */
.services-grid-3col {
    display: grid;
    grid-template-columns: repeat(3, 1fr) !important;
    gap: 32px !important;
    margin-top: 35px;
}

#process .services-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 24px;
    margin-top: 25px;
}

.service-card {
    background: #ffffff;
    padding: 44px 32px 36px;
    border-radius: 26px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
    border: 1.5px solid #edf2f7;
    border-bottom: 4px solid transparent;
    transition: all 0.35s cubic-bezier(0.165, 0.84, 0.44, 1);
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
}

.service-card:hover {
    transform: translateY(-8px);
    border-color: rgba(27, 94, 32, 0.25);
    border-bottom: 4px solid var(--primary);
    box-shadow: 0 22px 48px rgba(27, 94, 32, 0.12);
}

.service-icon-box {
    width: 80px;
    height: 80px;
    border-radius: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 34px;
    transition: transform 0.35s ease;
}

.service-card:hover .service-icon-box {
    transform: scale(1.1);
}

.service-card h3 {
    font-size: 22px;
    margin: 8px 0 14px;
    color: var(--primary);
    font-weight: 800;
    line-height: 1.35;
    min-height: 58px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
}

.service-card p {
    font-size: 15.5px;
    color: #4b5563;
    line-height: 1.72;
    margin: 0 0 24px;
    flex-grow: 1;
    text-align: center;
}

.service-card-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 22px;
    border-radius: 50px;
    background: #f0fdf4;
    color: #1b5e20;
    font-weight: 700;
    font-size: 14.5px;
    text-decoration: none;
    border: 1px solid #dcfce7;
    transition: all 0.25s ease;
    margin-top: auto;
}

.service-card:hover .service-card-btn {
    background: #1b5e20;
    color: #ffffff !important;
    gap: 12px;
    border-color: #1b5e20;
    box-shadow: 0 4px 14px rgba(27, 94, 32, 0.25);
}`;

if (oldServiceGridCssRegex.test(cssContent)) {
    cssContent = cssContent.replace(oldServiceGridCssRegex, newServiceCardCss);
    console.log('[SUCCESS] Replaced .services-grid CSS with 3-column wide card styles');
} else {
    console.error('[ERROR] Could not find old service card CSS block');
}

// Update responsive rules for max-width: 1024px if present
if (!cssContent.includes('.services-grid-3col { grid-template-columns: repeat(2, 1fr)')) {
    cssContent = cssContent.replace(/@media\s*\(\s*max-width:\s*1024px\s*\)\s*\{/i, (match) => {
        return `${match}\n    .services-grid-3col {\n        grid-template-columns: repeat(2, 1fr) !important;\n        gap: 24px !important;\n    }\n    #process .services-grid {\n        grid-template-columns: repeat(2, 1fr) !important;\n        gap: 20px !important;\n    }`;
    });
    console.log('[SUCCESS] Added 1024px tablet responsive query for .services-grid-3col');
}

fs.writeFileSync(cssPath, cssContent, 'utf8');
console.log('Finished updating home cards and removing explorer section.');
