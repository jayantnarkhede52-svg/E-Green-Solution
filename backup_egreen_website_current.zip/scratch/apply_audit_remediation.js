const fs = require('fs');

console.log('=== APPLYING COMPREHENSIVE AUDIT REMEDIATION ===\n');

// 1. Fix contact.html (Reply time, duplicate H2, consent microcopy)
if (fs.existsSync('contact.html')) {
  let contact = fs.readFileSync('contact.html', 'utf8');
  
  // Fix reply time (Low #32)
  contact = contact.replace(/Reply in:\s*<strong>&lt;\s*15\s*Mins<\/strong>/gi, 'Prompt Response: <strong>Within 2 Hours</strong>');
  
  // Fix duplicate H2 (Medium #17)
  contact = contact.replace(/<div class="contact-info-panel">\s*<h2>Send Us a Message<\/h2>/i, '<div class="contact-info-panel">\n                    <h2>Contact Information &amp; Offices</h2>');
  
  // Add consent microcopy under form button (Medium #27)
  if (!contact.includes('We respect your privacy')) {
    contact = contact.replace(/(<button type="submit" class="submit-btn shadow">Get Your Free Quote<\/button>)/i, '$1\n                        <p style="font-size: 13px; color: #777; margin-top: 10px; text-align: center;"><i class="fas fa-lock"></i> We respect your privacy. By submitting, you agree to our <a href="/privacy-policy" style="color: var(--primary); text-decoration: underline;">Privacy Policy</a>. No spam guaranteed.</p>');
  }

  // Update title
  contact = contact.replace(/<title>[\s\S]*?<\/title>/i, '<title>Contact E Green Solution | Solar Company Pune &amp; Free Site Survey</title>');

  fs.writeFileSync('contact.html', contact, 'utf8');
  console.log('✓ contact.html updated (reply time, duplicate H2, consent microcopy, title)');
}

// 2. Fix index.html (H2 2MW+ heading, Live output label, title, consent microcopy)
if (fs.existsSync('index.html')) {
  let index = fs.readFileSync('index.html', 'utf8');
  
  // H2 2MW+ fix (Medium #17)
  index = index.replace(/<h2 style="font-size: 160px; font-weight: 900; color: rgba\(251,192,45,0\.12\); line-height: 1; margin: 0; position: absolute; top: -40px; left: -10px; z-index: 0; pointer-events: none; user-select: none;">2MW\+<\/h2>/i,
    '<div style="font-size: 160px; font-weight: 900; color: rgba(251,192,45,0.12); line-height: 1; margin: 0; position: absolute; top: -40px; left: -10px; z-index: 0; pointer-events: none; user-select: none;">2MW+</div>');

  // Live output label fix (Medium #20)
  index = index.replace(/<div class="live-label">W Live Output<\/div>/i, '<div class="live-label">W Real-Time Demo (5kW Reference)</div>');

  // Title tag update (Removing spammy #1/Best while maintaining exact target keywords)
  index = index.replace(/<title>Solar Panel Dealers Pune \| Solar Panel Installations Pune<\/title>/i,
    '<title>Solar Panel Dealers Pune | Solar Panel Installations | E Green Solution</title>');

  // Add consent microcopy under consultation form
  if (!index.includes('We respect your privacy')) {
    index = index.replace(/(<button type="submit" class="btn-primary shimmer-effect"[^>]*>[\s\S]*?Get Free Solar Quote[\s\S]*?<\/button>)/i,
      '$1\n                <p style="font-size: 12px; color: rgba(255,255,255,0.7); margin-top: 10px; text-align: center;"><i class="fas fa-lock"></i> We respect your privacy. By submitting, you agree to our <a href="/privacy-policy" style="color: var(--accent); text-decoration: underline;">Privacy Policy</a>. No spam.</p>');
  }

  fs.writeFileSync('index.html', index, 'utf8');
  console.log('✓ index.html updated (H2 2MW+, live output label, title, consent microcopy)');
}

// 3. Fix about.html (CO2 claim, title)
if (fs.existsSync('about.html')) {
  let about = fs.readFileSync('about.html', 'utf8');
  
  // CO2 claim fix (Medium #19)
  about = about.replace(/dedicated to reducing 10,000\+ tons of CO2 emissions annually/gi,
    'dedicated to offsetting over 2,400+ tons of CO2 emissions annually (50,000+ tons lifetime impact)');

  // Title
  about = about.replace(/<title>[\s\S]*?<\/title>/i, '<title>About E Green Solution | Solar Energy Company Pune</title>');

  fs.writeFileSync('about.html', about, 'utf8');
  console.log('✓ about.html updated (CO2 claim, title)');
}

// 4. Fix "life bill zero" in industrial-solar.html, residential-solar.html, services.html (High #5)
const lifeBillFiles = ['industrial-solar.html', 'residential-solar.html', 'services.html'];
lifeBillFiles.forEach(f => {
  if (fs.existsSync(f)) {
    let content = fs.readFileSync(f, 'utf8');
    content = content.replace(/Designed to make your industrial life bill zero or reduce it by 90%/gi,
      'Designed to reduce your industrial electricity bills by up to 90% with captive clean energy');
    content = content.replace(/Make your life bill zero or reduce bills by 90%/gi,
      'Achieve net-zero electricity bills or reduce costs by up to 90%');
    fs.writeFileSync(f, content, 'utf8');
    console.log(`✓ ${f} updated (removed "life bill zero")`);
  }
});

// 5. Update footer descriptions & clean privacy-policy links sitewide (Medium #16)
const oldFooterText = /E Green Solution is the leading solar panel pune expert, providing premium solar panel installations in pune and energy-efficient water heaters for homes and businesses across Maharashtra\./gi;
const cleanFooterText = 'E Green Solution is a trusted Pune-based solar energy company providing turnkey residential and commercial rooftop solar installations with Tier-1 modules, MSEDCL net metering, and PM Surya Ghar subsidy support across Maharashtra.';

const allHtml = fs.readdirSync('.').filter(f => f.endsWith('.html'));

allHtml.forEach(f => {
  let content = fs.readFileSync(f, 'utf8');
  let changed = false;

  if (oldFooterText.test(content)) {
    content = content.replace(oldFooterText, cleanFooterText);
    changed = true;
  }

  // Replace /privacy-policy.html with clean /privacy-policy
  if (content.includes('/privacy-policy.html')) {
    content = content.replace(/\/privacy-policy\.html/g, '/privacy-policy');
    changed = true;
  }

  // Standardize brand in copyright
  if (content.includes('&copy; 2026 Egreen Solution.')) {
    content = content.replace(/&copy; 2026 Egreen Solution\./g, '&copy; 2026 E Green Solution.');
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(f, content, 'utf8');
    console.log(`✓ Cleaned footer & links in ${f}`);
  }
});

// 6. Update titles on service/guide pages to match Section 7 of the audit report
const titleMap = {
  'residential-solar.html': {
    title: 'Residential Rooftop Solar Pune | Home Solar Systems | E Green Solution',
    desc: 'Home rooftop solar installation in Pune with PM Surya Ghar subsidy guidance, system sizing, MSEDCL net metering and transparent savings estimates.'
  },
  'industrial-solar.html': {
    title: 'Industrial Solar EPC Pune | Factory Solar Plants | E Green Solution',
    desc: 'Industrial rooftop solar EPC for Pune and MIDC facilities, including engineering, CEIG approvals, 40% depreciation benefits, monitoring and project execution.'
  },
  'solar-subsidy.html': {
    title: 'PM Surya Ghar Subsidy Pune 2026 | Solar Scheme | E Green Solution',
    desc: 'Check current PM Surya Ghar subsidy amounts, eligibility, application steps and required documents for residential rooftop solar in Pune.'
  },
  'services.html': {
    title: 'Solar Energy Services Pune | Rooftop EPC & Maintenance | E Green Solution',
    desc: 'Turnkey solar energy services in Pune including residential rooftop solar, industrial solar EPC, solar water heating, and annual maintenance contracts.'
  },
  'projects.html': {
    title: 'Solar Projects & Case Studies Pune | E Green Solution',
    desc: 'Explore commissioned solar rooftop projects and commercial solar EPC installations across Pune, PCMC, and Maharashtra industrial zones.'
  },
  'calculator.html': {
    title: 'Solar Savings & ROI Calculator Pune | E Green Solution',
    desc: 'Calculate your rooftop solar system size, monthly electricity bill savings, PM Surya Ghar subsidy, and estimated payback period in Pune.'
  },
  'solar-guide.html': {
    title: 'Solar 101 Guide | Rooftop Solar Installation Pune | E Green Solution',
    desc: 'A comprehensive beginner guide to rooftop solar panels, on-grid vs hybrid systems, net metering with MSEDCL, and PM Surya Ghar subsidies in Pune.'
  }
};

for (const [file, meta] of Object.entries(titleMap)) {
  if (fs.existsSync(file)) {
    let content = fs.readFileSync(file, 'utf8');
    content = content.replace(/<title>[\s\S]*?<\/title>/i, `<title>${meta.title}</title>`);
    content = content.replace(/<meta\s+name=["']description["']\s+content=["'][^"']*["']/i, `<meta name="description" content="${meta.desc}">`);
    fs.writeFileSync(file, content, 'utf8');
    console.log(`✓ Updated title & description in ${file}`);
  }
}

console.log('\nAll audit remediation tasks applied successfully!');
