const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const blogDir = path.join(rootDir, 'blog');

const indexHtml = fs.readFileSync(path.join(rootDir, 'index.html'), 'utf8');

// 1. Extract standard navbar from index.html
const navRegex = /<nav\s+id=["']navbar["'][\s\S]*?<\/nav>/i;
const navMatch = indexHtml.match(navRegex);
if (!navMatch) {
    console.error('Failed to extract navbar from index.html');
    process.exit(1);
}
// For subpages, ensure it has class="scrolled"
const subpageNav = navMatch[0].replace('<nav id="navbar"', '<nav id="navbar" class="scrolled"');

// 2. Extract standard footer, fab, and mobile-bottom-nav from index.html
const footerRegex = /<footer\s+class=["']section-padding\s+bg-primary-gradient["'][\s\S]*?<\/nav>/i;
const footerMatch = indexHtml.match(footerRegex);
if (!footerMatch) {
    console.error('Failed to extract footer block from index.html');
    process.exit(1);
}
const standardFooterBlock = footerMatch[0];

console.log('Successfully extracted standard navbar and footer blocks from index.html');

// List of all HTML files except index.html and solar-hero.html
const rootFiles = fs.readdirSync(rootDir).filter(f => f.endsWith('.html') && f !== 'index.html' && f !== 'solar-hero.html').map(f => path.join(rootDir, f));
const blogFiles = fs.readdirSync(blogDir).filter(f => f.endsWith('.html')).map(f => path.join(blogDir, f));

const allTargetFiles = [...rootFiles, ...blogFiles];

let updatedCount = 0;

for (const filePath of allTargetFiles) {
    const rel = path.relative(rootDir, filePath);
    let content = fs.readFileSync(filePath, 'utf8');
    const original = content;

    // A. Replace Navigation
    // Check if it has <header class="header"> with nav inside (some blog files)
    if (/<header class=["']header["']>[\s\S]*?<\/header>/i.test(content)) {
        content = content.replace(/<header class=["']header["']>[\s\S]*?<\/header>/i, subpageNav);
    } else if (/<nav\s+id=["']navbar["'][\s\S]*?<\/nav>/i.test(content)) {
        content = content.replace(/<nav\s+id=["']navbar["'][\s\S]*?<\/nav>/i, subpageNav);
    }

    // B. Replace Footer + FAB + Mobile Bottom Nav
    // We look for <footer> until either <script> or </body>
    const targetFooterRegex = /<footer[\s\S]*?(?:<nav[^>]*class=["']mobile-bottom-nav["'][\s\S]*?<\/nav>|<div[^>]*class=["']fab-container["'][\s\S]*?<\/div>|<\/footer>)/i;
    
    // Find where footer starts
    const footerStartIdx = content.indexOf('<footer');
    if (footerStartIdx !== -1) {
        // Find where scripts start after footer
        const scriptMatch = content.slice(footerStartIdx).match(/<script/i);
        if (scriptMatch) {
            const footerEndIdx = footerStartIdx + scriptMatch.index;
            content = content.slice(0, footerStartIdx) + standardFooterBlock + '\n\n    ' + content.slice(footerEndIdx);
        }
    }

    // Customize active state on mobile-bottom-nav for this page
    if (rel.includes('services')) {
        content = content.replace(/(<nav[^>]*class=["']mobile-bottom-nav["'][\s\S]*?href="\/services"[^>]*class=["']bottom-nav-item)(["'])/i, '$1 active$2');
    } else if (rel.includes('calculator')) {
        content = content.replace(/(<nav[^>]*class=["']mobile-bottom-nav["'][\s\S]*?href="\/calculator"[^>]*class=["']bottom-nav-item)(["'])/i, '$1 active$2');
    } else if (rel.includes('subsidy')) {
        content = content.replace(/(<nav[^>]*class=["']mobile-bottom-nav["'][\s\S]*?href="\/solar-subsidy"[^>]*class=["']bottom-nav-item)(["'])/i, '$1 active$2');
    }

    if (content !== original) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Updated navbar and footer in: ${rel}`);
        updatedCount++;
    } else {
        console.log(`No change needed in: ${rel}`);
    }
}

console.log(`\nSuccessfully standardized navbar and footer in ${updatedCount} files.`);
