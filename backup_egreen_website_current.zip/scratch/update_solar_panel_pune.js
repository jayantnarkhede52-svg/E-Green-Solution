const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'solar-panel-pune.html');

const htmlContent = `<!DOCTYPE html>
<html lang="en-IN">
<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-6RB8MHEG1S"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-6RB8MHEG1S');
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Primary SEO Metadata -->
    <title>Rooftop Solar Panel Installation in Pune City | E Green Solution</title>
    <meta name="description" content="Certified rooftop solar EPC in Pune City. Installations across Kothrud, Deccan, Shivajinagar & Sopan Baug. PM Surya Ghar ₹78,000 subsidy & MSEDCL net metering.">
    <meta name="keywords" content="solar panel installation in pune, rooftop solar pune city, solar installer kothrud, solar panels deccan pune, housing society solar pune, msedcl net metering pune">
    <link rel="canonical" href="https://egreensolution.in/solar-panel-pune">
    
    <!-- Geo Targeting Metadata -->
    <meta name="geo.region" content="IN-MH">
    <meta name="geo.placename" content="Pune, Maharashtra, India">
    <meta name="geo.position" content="18.5204;73.8567">
    <meta name="ICBM" content="18.5204, 73.8567">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://egreensolution.in/solar-panel-pune">
    <meta property="og:title" content="Rooftop Solar Panel Installation in Pune City | E Green Solution">
    <meta property="og:description" content="Turnkey rooftop solar installations across Pune City bungalows, societies & businesses. ₹78,000 PM Surya Ghar subsidy & MSEDCL net metering.">
    <meta property="og:image" content="https://egreensolution.in/assets/areas/solar-pune.png">
    <meta property="og:image:width" content="1024">
    <meta property="og:image:height" content="1024">
    <meta property="og:image:alt" content="Rooftop Solar Panel Installation in Pune City">

    <!-- Twitter Cards -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Rooftop Solar Panel Installation in Pune City | E Green Solution">
    <meta name="twitter:description" content="Premier solar EPC in Pune City. High-efficiency DCR mono PERC & TOPCon installations with 25-year performance warranty.">
    <meta name="twitter:image" content="https://egreensolution.in/assets/areas/solar-pune.png">

    <!-- Structured Data (JSON-LD) -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": ["LocalBusiness", "SolarEnergyContractor"],
          "@id": "https://egreensolution.in/#organization",
          "name": "E Green Solution - Pune City Solar Hub",
          "alternateName": "E Green Solution",
          "url": "https://egreensolution.in/solar-panel-pune",
          "logo": "https://egreensolution.in/assets/logo.png",
          "image": "https://egreensolution.in/assets/areas/solar-pune.png",
          "telephone": "+917249187969",
          "email": "info@egreensolution.in",
          "priceRange": "₹₹ - ₹₹₹",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi",
            "addressLocality": "Pune",
            "addressRegion": "Maharashtra",
            "postalCode": "411043",
            "addressCountry": "IN"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": 18.5204,
            "longitude": 73.8567
          },
          "areaServed": [
            {
              "@type": "City",
              "name": "Pune",
              "sameAs": "https://www.wikidata.org/wiki/Q1538"
            },
            "Kothrud", "Deccan Gymkhana", "Shivajinagar", "Model Colony", "Prabhat Road", 
            "Aundh", "Camp", "Swargate", "Sopan Baug", "Kalyani Nagar", "Erandwane", "Karve Nagar"
          ],
          "knowsAbout": [
            "Rooftop Solar PV Systems",
            "PM Surya Ghar Muft Bijli Yojana Subsidy",
            "MSEDCL Net Metering Ganeshkhind & Rasta Peth Circles",
            "Elevated Terrace Solar Pergolas",
            "Housing Society Common Meter Solar"
          ],
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.9",
            "reviewCount": "184"
          },
          "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
            "opens": "09:00",
            "closes": "19:00"
          }
        },
        {
          "@type": "Service",
          "@id": "https://egreensolution.in/solar-panel-pune#service",
          "name": "Rooftop Solar Panel Installation Pune City",
          "serviceType": "Solar Panel Installation",
          "provider": {
            "@type": "LocalBusiness",
            "name": "E Green Solution"
          },
          "areaServed": {
            "@type": "City",
            "name": "Pune"
          },
          "description": "Turnkey rooftop solar EPC services for bungalows, penthouses, cooperative housing societies, and commercial institutions across Pune Municipal Corporation."
        },
        {
          "@type": "BreadcrumbList",
          "@id": "https://egreensolution.in/solar-panel-pune#breadcrumb",
          "itemListElement": [
            {
              "@type": "ListItem",
              "position": 1,
              "name": "Home",
              "item": "https://egreensolution.in/"
            },
            {
              "@type": "ListItem",
              "position": 2,
              "name": "Service Areas",
              "item": "https://egreensolution.in/areas"
            },
            {
              "@type": "ListItem",
              "position": 3,
              "name": "Pune City",
              "item": "https://egreensolution.in/solar-panel-pune"
            }
          ]
        },
        {
          "@type": "FAQPage",
          "@id": "https://egreensolution.in/solar-panel-pune#faq",
          "mainEntity": [
            {
              "@type": "Question",
              "name": "How much does a 3kW rooftop solar installation cost in Pune City after subsidy?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "In Pune City, a premium 3kW on-grid solar system costs approximately ₹1,95,000 before incentives. Under the central PM Surya Ghar Muft Bijli Yojana, eligible residential homeowners receive an upfront direct bank credit of ₹78,000, bringing the net out-of-pocket cost down to ~₹1,17,000. Generating 360-400 units monthly, the system achieves complete payback in under 3 years."
              }
            },
            {
              "@type": "Question",
              "name": "How is MSEDCL net metering processed in Pune City circles?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Pune City is serviced under MSEDCL Ganeshkhind and Rasta Peth Urban Circles. E Green Solution handles the entire regulatory liaison: online application submission on the National Solar Portal, transformer feasibility sanction, bidirectional net meter installation and lab testing, and commissioning sync—all completed in 2 to 3 weeks."
              }
            },
            {
              "@type": "Question",
              "name": "Can older bungalows in Kothrud, Prabhat Road, or Deccan install solar without roof damage?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Yes. Our licensed structural engineers conduct load-bearing assessments and install elevated hot-dip galvanized superstructures (8 to 9.5 feet clearance) anchored with non-destructive chemical fasteners and industrial silicone waterproofing, completely preserving your terrace floor, garden space, and waterproofing membrane."
              }
            },
            {
              "@type": "Question",
              "name": "Are cooperative housing societies in Pune eligible for common meter solar subsidies?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Yes! Cooperative Housing Societies (CHSs) and Resident Welfare Associations (RWAs) in Pune can claim a central government subsidy of ₹18,000 per kW up to 500 kW under PM Surya Ghar for powering common amenities like elevators, water supply pumps, and perimeter lighting."
              }
            }
          ]
        }
      ]
    }
    </script>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/favicon.png">
    <link rel="apple-touch-icon" href="/assets/logo.png">
    <link rel="stylesheet" href="/css/style.css?v=1.2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .breadcrumbs-bar { background: #f4f6f8; padding: 12px 0; font-size: 14px; border-bottom: 1px solid #e2e8f0; }
        .breadcrumbs-bar a { color: var(--primary); text-decoration: none; font-weight: 500; }
        .breadcrumbs-bar span { color: #64748b; margin: 0 8px; }
        .breadcrumbs-bar .current-crumb { color: #1e293b; font-weight: 600; }
        .dealership-callout { background: #fff8eb; border: 2px dashed #f59e0b; border-radius: 16px; padding: 25px; margin: 35px 0; }
        .dealership-callout h4 { color: #92400e; font-size: 18px; margin-bottom: 8px; }
        .dealership-callout p { color: #78350f; font-size: 14px; line-height: 1.6; margin: 0; }
        .pricing-mini-table { width: 100%; border-collapse: collapse; margin: 25px 0; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .pricing-mini-table th { background: #2e7d32; color: white; padding: 12px 16px; font-size: 14px; text-align: left; }
        .pricing-mini-table td { padding: 12px 16px; font-size: 14px; border-bottom: 1px solid #eee; color: #444; }
        .pricing-mini-table tr:hover td { background: #f9fdf9; }
        .faq-item { background: white; margin-bottom: 12px; border-radius: 12px; overflow: hidden; box-shadow: 0 3px 12px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; }
        .faq-question { width: 100%; padding: 18px 22px; text-align: left; background: white; border: none; cursor: pointer; font-size: 16px; font-weight: 600; color: var(--text-dark); display: flex; justify-content: space-between; align-items: center; }
        .faq-question:hover { color: var(--primary); }
        .faq-answer { display: none; padding: 0 22px 18px; color: #555; line-height: 1.7; font-size: 14px; }
        .area-photo-box { margin: 30px 0; border-radius: 18px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.08); background: #f8fafc; border: 1px solid #e2e8f0; }
        .area-photo-box img { width: 100%; height: auto; display: block; }
        .area-photo-caption { padding: 12px 18px; font-size: 13.5px; color: #475569; background: #fff; border-top: 1px solid #f1f5f9; display: flex; align-items: center; gap: 8px; }
        .area-photo-caption i { color: var(--primary); }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav id="navbar" class="scrolled" aria-label="Main Navigation Menu">
        <div class="container nav-container">
            <a href="/" class="logo" aria-label="Egreen Solution Home">
                <img src="/assets/logo.png" alt="E Green Solution - Solar Panel Dealers Pune &amp; Solar Panel Installations" width="180" height="60" decoding="async">
            </a>
            <ul class="nav-links">
                <li><a href="/">Home</a></li>
                <li><a href="/solar-guide">Solar 101</a></li>
                <li class="nav-item-dropdown">
                    <a href="/services" class="dropdown-trigger">Services <i class="fas fa-chevron-down nav-arrow"></i></a>
                    <div class="nav-dropdown-menu">
                        <div class="dropdown-inner">
                            <div class="dropdown-col">
                                <span class="dropdown-heading"><i class="fas fa-solar-panel"></i> Solar Installations</span>
                                <a href="/residential-solar" class="dropdown-item">
                                    <div class="item-icon green"><i class="fas fa-home"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Residential Solar</span>
                                        <span class="item-desc">Rooftops &amp; Housing Societies</span>
                                    </div>
                                </a>
                                <a href="/commercial-solar-pune" class="dropdown-item">
                                    <div class="item-icon amber"><i class="fas fa-building"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Commercial Solar</span>
                                        <span class="item-desc">Offices, Hospitals &amp; Malls</span>
                                    </div>
                                </a>
                                <a href="/industrial-solar" class="dropdown-item">
                                    <div class="item-icon blue"><i class="fas fa-industry"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Industrial Solar EPC</span>
                                        <span class="item-desc">MIDC Chakan, Bhosari &amp; Talegaon</span>
                                    </div>
                                </a>
                                <a href="/solar-water-heater-pune" class="dropdown-item">
                                    <div class="item-icon red"><i class="fas fa-water"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Solar Water Heaters</span>
                                        <span class="item-desc">ETC &amp; FPC Water Heating</span>
                                    </div>
                                </a>
                                <a href="/solar-subsidy" class="dropdown-item">
                                    <div class="item-icon gold"><i class="fas fa-file-invoice-dollar"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">PM Surya Ghar Subsidy</span>
                                        <span class="item-desc">Save up to ₹78,000 Direct Credit</span>
                                    </div>
                                </a>
                            </div>
                            <div class="dropdown-col">
                                <span class="dropdown-heading"><i class="fas fa-tools"></i> Plant Care &amp; Maintenance</span>
                                <a href="/solar-panel-cleaning-pune" class="dropdown-item">
                                    <div class="item-icon teal"><i class="fas fa-broom"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Solar Panel Cleaning</span>
                                        <span class="item-desc">RO Water Wash (+25% Yield)</span>
                                    </div>
                                </a>
                                <a href="/solar-amc-pune" class="dropdown-item">
                                    <div class="item-icon emerald"><i class="fas fa-file-contract"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Solar AMC Contracts</span>
                                        <span class="item-desc">Quarterly Audits &amp; Rapid SLA</span>
                                    </div>
                                </a>
                                <a href="/solar-repair-maintenance-pune" class="dropdown-item">
                                    <div class="item-icon red"><i class="fas fa-wrench"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Maintenance &amp; Repair</span>
                                        <span class="item-desc">Breakdown Fixes &amp; Fault Testing</span>
                                    </div>
                                </a>
                                <a href="/solar-inverter-repair-pune" class="dropdown-item">
                                    <div class="item-icon orange"><i class="fas fa-bolt"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Solar Inverter Repair</span>
                                        <span class="item-desc">Growatt, Sungrow, Solis, Fronius</span>
                                    </div>
                                </a>
                                <a href="/solar-net-meter-msedcl-pune" class="dropdown-item">
                                    <div class="item-icon purple"><i class="fas fa-tachometer-alt"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Net Meter Testing</span>
                                        <span class="item-desc">MSEDCL Replacement &amp; Credit Sync</span>
                                    </div>
                                </a>
                                <a href="/solar-plant-revamping-repowering" class="dropdown-item">
                                    <div class="item-icon cyan"><i class="fas fa-sync-alt"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Revamping &amp; Repowering</span>
                                        <span class="item-desc">Double Yield on Existing Sheds</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="dropdown-footer-link">
                            <span>Explore our complete range of turnkey engineering solutions</span>
                            <a href="/services">View All Solar Services &rarr;</a>
                        </div>
                    </div>
                </li>
                <li><a href="/blog">Blog</a></li>
                <li><a href="/projects">Projects</a></li>
                <li><a href="/calculator">Calculator</a></li>
                <li><a href="/solar-subsidy">Subsidy</a></li>
                <li><a href="/areas">Areas</a></li>
                <li><a href="/about">About</a></li>
                <li><a href="/contact" class="btn-contact">Contact Us</a></li>
            </ul>
            <div class="hamburger" id="hamburger" aria-label="Toggle Mobile Menu" aria-expanded="false" role="button" tabindex="0">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="mobile-menu" id="mobile-menu">
                <ul class="mobile-nav-links">
                    <li><a href="/">Home</a></li>
                    <li><a href="/solar-guide">Solar 101</a></li>
                    <li><a href="/services">Services</a></li>
                    <li><a href="/blog">Blog</a></li>
                    <li><a href="/projects">Projects</a></li>
                    <li><a href="/calculator">Calculator</a></li>
                    <li><a href="/solar-subsidy">Subsidy</a></li>
                    <li><a href="/areas">Areas</a></li>
                    <li><a href="/about">About</a></li>
                    <li><a href="/contact" class="btn-contact-mobile">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Breadcrumb Bar -->
    <div class="breadcrumbs-bar">
        <div class="container">
            <a href="/"><i class="fas fa-home"></i> Home</a>
            <span><i class="fas fa-chevron-right" style="font-size: 10px;"></i></span>
            <a href="/areas">Service Areas</a>
            <span><i class="fas fa-chevron-right" style="font-size: 10px;"></i></span>
            <span class="current-crumb">Pune City</span>
        </div>
    </div>

    <!-- Main Content Landmark -->
    <main id="main-content">
        <!-- Top Split Hero Section with Quick Lead Form -->
        <header class="hero-split">
            <div class="container hero-split-grid">
                <div class="hero-split-left">
                    <div class="hero-eyebrow-badge">
                        <i class="fas fa-bolt"></i>
                        <span>PMC Urban Zone Solar Engineering</span>
                    </div>
                    <h1 class="hero-split-title">Rooftop Solar Panel Installation in Pune City</h1>
                    <p class="hero-split-desc">Turnkey rooftop solar EPC for independent bungalows, penthouses, cooperative housing societies, and commercial properties across Pune City. Claim <span class="highlight-mark">₹78,000 direct PM Surya Ghar subsidy</span> and end-to-end MSEDCL net metering approvals.</p>
                    <div class="hero-feature-chips">
                        <div class="hero-feature-chip">
                            <i class="fas fa-check-circle"></i>
                            <span>Free On-Site Pune Roof Survey</span>
                        </div>
                        <div class="hero-feature-chip">
                            <i class="fas fa-check-circle"></i>
                            <span>Tier-1 Bifacial & TOPCon Panels</span>
                        </div>
                        <div class="hero-feature-chip">
                            <i class="fas fa-check-circle"></i>
                            <span>Rasta Peth & Ganeshkhind Circles</span>
                        </div>
                        <div class="hero-feature-chip">
                            <i class="fas fa-check-circle"></i>
                            <span>25-Year Performance Guarantee</span>
                        </div>
                    </div>
                    <div class="hero-trust-row">
                        <span>⭐ 4.9/5 Rating (200+ Pune Installations)</span>
                        <span><i class="fas fa-shield-halved" style="color: #4ade80;"></i> MSEDCL Approved</span>
                        <span><i class="fas fa-award" style="color: #fbc02d;"></i> MNRE Empanelled</span>
                    </div>
                </div>

                <div class="hero-split-right">
                    <div class="hero-form-card">
                        <span class="form-badge-strip">FAST CALLBACK • 100% FREE SURVEY</span>
                        <h3>Get Instant Pune Solar Quote</h3>
                        <div class="form-subtitle">Certified rooftop solar engineer callback within 15 minutes</div>
                        <form action="https://formsubmit.co/egreensolution1@gmail.com" method="POST" class="hero-quick-form">
                            <input type="hidden" name="_subject" value="Pune City Solar Inquiry - Website Lead">
                            <input type="hidden" name="_template" value="table">
                            <input type="hidden" name="_captcha" value="false">
                            
                            <div class="form-group-compact">
                                <label><i class="fas fa-user"></i> Full Name *</label>
                                <input type="text" name="name" required placeholder="Enter your full name">
                            </div>

                            <div class="form-group-compact">
                                <label><i class="fas fa-phone-alt"></i> Mobile / WhatsApp *</label>
                                <input type="tel" name="phone" required placeholder="Enter 10-digit mobile number">
                            </div>

                            <div class="form-row-2col">
                                <div class="form-group-compact">
                                    <label><i class="fas fa-location-dot"></i> Pune Locality</label>
                                    <input type="text" name="location" placeholder="e.g. Kothrud, Deccan, Sopan Baug">
                                </div>
                                <div class="form-group-compact">
                                    <label><i class="fas fa-solar-panel"></i> Property Type</label>
                                    <select name="propertyType">
                                        <option value="Independent Bungalow / Row House">Bungalow / Row House</option>
                                        <option value="Housing Society Common Meter">Housing Society Common Meter</option>
                                        <option value="Commercial Office / Hospital">Commercial / Hospital</option>
                                        <option value="Penthouse / Duplex Terrace">Penthouse Terrace</option>
                                    </select>
                                </div>
                            </div>

                            <button type="submit" class="btn-hero-form">
                                <span>Get Free Pune Solar Assessment</span>
                                <i class="fas fa-arrow-right"></i>
                            </button>
                            <div class="form-trust-footer">
                                <i class="fas fa-lock"></i> 100% Privacy • Direct Technical Assessment
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </header>

        <section class="section-padding">
            <div class="container">
                <div class="responsive-grid-2">
                    <div class="human-content">
                        <h2 style="font-size: 32px; margin-bottom: 18px; color: var(--primary);">Engineering Solar for Pune's Distinct Urban Architecture</h2>
                        
                        <p style="font-size: 16.5px; line-height: 1.8; margin-bottom: 18px;">
                            Pune City features a unique blend of heritage residential localities—such as <strong>Kothrud, Deccan Gymkhana, Prabhat Road, Model Colony, Shivajinagar, Erandwane, and Camp</strong>—alongside modern upscale enclaves like <strong>Sopan Baug, Kalyani Nagar, and Aundh</strong>. Rooftops in these established wards present specific structural conditions: vintage concrete slabs requiring waterproof chemical-anchored fasteners, space constraints due to water tanks and staircases, and shadow obstacles from surrounding foliage.
                        </p>

                        <p style="font-size: 16.5px; line-height: 1.8; margin-bottom: 20px;">
                            As an established Pune-based solar EPC, <strong>E Green Solution</strong> specializes in customized structural engineering that maximizes sunshine harvesting across Pune's 300+ annual sunny days, reducing monthly MSEDCL bills by up to 90% while fully protecting the structural integrity of your roof.
                        </p>

                        <!-- Primary Feature Image with Exact Dimensions -->
                        <figure class="area-photo-box">
                            <img src="/assets/areas/solar-pune.png" alt="Rooftop Solar Panel Installation across Pune City bungalows and residential societies" width="1024" height="1024" loading="eager" decoding="async">
                            <figcaption class="area-photo-caption">
                                <i class="fas fa-camera"></i> Certified rooftop solar PV installation on an independent residence in Pune City
                            </figcaption>
                        </figure>

                        <h2 style="font-size: 28px; margin: 35px 0 16px; color: var(--primary);">Pune City Rooftop Solar Cost, Capacity &amp; Subsidy Slabs (2026)</h2>
                        <p style="font-size: 16px; line-height: 1.8; color: #555;">
                            Under the central <strong>PM Surya Ghar Muft Bijli Yojana</strong>, domestic homeowners in Pune receive direct bank transfer (DBT) subsidies of up to ₹78,000. Because MSEDCL domestic LT-I tariffs rapidly escalate from ₹5.88 up to ₹16.15 per unit for consumers using above 300 units monthly, rooftop solar delivers substantial financial savings and amortizes in less than 3 years:
                        </p>

                        <table class="pricing-mini-table">
                            <thead>
                                <tr>
                                    <th>System Capacity</th>
                                    <th>Avg. Gross Cost</th>
                                    <th>PM Surya Ghar Subsidy</th>
                                    <th>Net Out-of-Pocket</th>
                                    <th>Monthly Generation</th>
                                    <th>Monthly Savings</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>3 kW System</strong> (2-3 BHK Home)</td>
                                    <td>₹1,95,000</td>
                                    <td><strong>₹78,000</strong></td>
                                    <td>₹1,17,000</td>
                                    <td>360 - 400 Units</td>
                                    <td>₹3,800 - ₹4,800</td>
                                </tr>
                                <tr>
                                    <td><strong>5 kW System</strong> (Row House/Bungalow)</td>
                                    <td>₹2,85,000</td>
                                    <td><strong>₹78,000</strong></td>
                                    <td>₹2,07,000</td>
                                    <td>600 - 660 Units</td>
                                    <td>₹6,800 - ₹8,500</td>
                                </tr>
                                <tr>
                                    <td><strong>8 kW System</strong> (Large Bungalow/Duplex)</td>
                                    <td>₹4,30,000</td>
                                    <td><strong>₹78,000</strong></td>
                                    <td>₹3,52,000</td>
                                    <td>960 - 1,050 Units</td>
                                    <td>₹11,500 - ₹14,000</td>
                                </tr>
                                <tr>
                                    <td><strong>10 kW+ System</strong> (Housing Society Common)</td>
                                    <td>₹5,20,000</td>
                                    <td><strong>₹18,000 / kW</strong></td>
                                    <td>Subsidized</td>
                                    <td>1,200 - 1,350 Units</td>
                                    <td>₹15,000 - ₹19,500</td>
                                </tr>
                            </tbody>
                        </table>

                        <!-- Secondary Engineering Visual: Elevated Pergola -->
                        <h2 style="font-size: 28px; margin: 35px 0 16px; color: var(--primary);">Elevated Terrace Pergolas: 100% Usable Rooftop Space</h2>
                        <p style="font-size: 16px; line-height: 1.8; color: #555;">
                            In dense urban wards like Kothrud, Shivajinagar, and Prabhat Road, terrace space is deeply cherished for family gatherings, morning walks, yoga, and rooftop gardening. We engineer custom elevated superstructures (8 to 9.5 feet ground clearance) fabricated with heavy-gauge hot-dip galvanized iron (minimum 80-micron zinc coating). This keeps your entire terrace open, cools the top floor by 3°C to 5°C during hot Pune summers, and ensures zero roof penetration through chemical anchoring.
                        </p>

                        <figure class="area-photo-box">
                            <img src="/assets/blog/elevated_rooftop_solar_structure_pune.jpg" alt="Elevated Terrace Rooftop Solar Pergola Structure in Pune City" width="1376" height="768" loading="lazy" decoding="async">
                            <figcaption class="area-photo-caption">
                                <i class="fas fa-shield-alt"></i> 9-foot elevated galvanized pergola structure preserving 100% usable terrace recreation space
                            </figcaption>
                        </figure>

                        <!-- Anti-Cannibalization Anchor Callout -->
                        <div class="dealership-callout">
                            <h4>Looking for Wholesale Solar Panels or Central Distribution in Pune?</h4>
                            <p>
                                If you are seeking bulk module supplies, tier-1 inverters, or wholesale distribution across Pune district, visit our central 
                                <a href="/" style="font-weight: 700; color: #92400e; text-decoration: underline;">solar panel dealers in Pune</a> page. For complete turnkey EPC installations, explore our proven 
                                <a href="/" style="font-weight: 700; color: #92400e; text-decoration: underline;">solar panel installations in Pune</a> portfolio covering 200+ residential and commercial sites.
                            </p>
                        </div>

                        <h2 style="font-size: 28px; margin: 35px 0 16px; color: var(--primary);">MSEDCL Net Metering in Ganeshkhind &amp; Rasta Peth Circles</h2>
                        <p style="font-size: 16px; line-height: 1.8; color: #555;">
                            In Pune City, rooftop solar grid synchronization is governed by two major MSEDCL circles: <strong>Ganeshkhind Urban Circle</strong> (covering Kothrud, Aundh, Shivajinagar, and Model Colony) and <strong>Rasta Peth Urban Circle</strong> (covering Camp, Swargate, Hadapsar, and Sopan Baug). 
                        </p>
                        <p style="font-size: 16px; line-height: 1.8; color: #555;">
                            E Green Solution coordinates the complete regulatory workflow without demanding customer visits to DISCOM offices:
                        </p>
                        <ul style="color: #475569; font-size: 15.5px; line-height: 1.8; margin-left: 20px; margin-bottom: 25px;">
                            <li>Technical feasibility verification against local distribution transformer (DTR) solar capacity quotas.</li>
                            <li>Digital application filing on the National Solar Rooftop Portal and MSEDCL renewable energy cell.</li>
                            <li>Procurement, calibration, and statutory lab testing of bidirectional net meters.</li>
                            <li>Joint on-site commissioning with MSEDCL junior engineers and release of direct bank subsidy.</li>
                        </ul>

                        <!-- Local Case Study Callout with Real Project Image -->
                        <div style="background: #fff; border: 2px solid #2e7d32; border-radius: 18px; padding: 25px 28px; margin: 30px 0; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 15px;">
                                <div>
                                    <span style="background: #2e7d32; color: white; font-size: 12px; font-weight: 700; padding: 4px 12px; border-radius: 20px;"><i class="fas fa-star"></i> Featured Pune Landmark Case Study</span>
                                    <h3 style="font-size: 20px; color: #0f172a; margin: 10px 0 6px;">Konark A Plus Housing Society (100kW, Sopan Baug, Pune)</h3>
                                    <p style="color: #475569; font-size: 14.5px; margin: 0 0 15px; line-height: 1.6; max-width: 600px;">
                                        Installed a 100kW grid-connected rooftop solar plant generating 12,000+ units per month. Slashed monthly common electricity bills from ₹3.2+ Lakhs down by 90% for elevators, water pumping, and campus lighting with ₹18 Lakhs PM Surya Ghar GHS central subsidy.
                                    </p>
                                </div>
                                <a href="/projects/konark-a-plus-100kw-housing-society-solar-pune" class="btn-primary" style="padding: 10px 20px; font-size: 14px; text-decoration: none; align-self: center;">View 100kW Case Study &rarr;</a>
                            </div>
                            <figure class="area-photo-box" style="margin: 15px 0 0;">
                                <img src="/assets/projects/konark_society_rooftop_100kw.jpg" alt="100kW Rooftop Solar Installation at Konark A Plus Housing Society Sopan Baug Pune" width="1280" height="720" loading="lazy" decoding="async">
                                <figcaption class="area-photo-caption">
                                    <i class="fas fa-bolt"></i> Real on-site installation: 100kW Konark A Plus Housing Society in Sopan Baug, Pune City
                                </figcaption>
                            </figure>
                        </div>

                        <!-- Frequently Asked Questions -->
                        <h2 style="font-size: 28px; margin: 40px 0 18px; color: var(--primary);">Frequently Asked Questions: Pune City Solar Installation</h2>
                        
                        <div class="faq-item">
                            <button type="button" class="faq-question">
                                <span>How much does a 3kW solar panel installation cost in Pune City after subsidy?</span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="faq-answer">
                                <p>A turnkey 3kW system in Pune City costs around ₹1,95,000 before government incentives. Under the PM Surya Ghar scheme, eligible domestic consumers receive a direct bank credit subsidy of ₹78,000, bringing your net cost down to ₹1,17,000 with a quick 2.8 to 3-year payback.</p>
                            </div>
                        </div>

                        <div class="faq-item">
                            <button type="button" class="faq-question">
                                <span>How does MSEDCL net metering work across Pune City wards?</span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="faq-answer">
                                <p>MSEDCL installs a bi-directional net meter that records units exported to the grid during sunny daytime hours and units imported at night. Surplus units are credited against your bill at the end of every billing cycle, dropping monthly electricity costs by 80% to 90%.</p>
                            </div>
                        </div>

                        <div class="faq-item">
                            <button type="button" class="faq-question">
                                <span>Can vintage bungalows in Kothrud, Deccan, or Camp install rooftop solar safely?</span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="faq-answer">
                                <p>Yes. Our structural engineers perform non-destructive concrete rebound hammer tests and utilize elevated galvanized framing with chemical anchoring and multi-layer elastomeric waterproofing sealant, ensuring zero roof leaks and preserving full terrace usability.</p>
                            </div>
                        </div>

                        <div class="faq-item">
                            <button type="button" class="faq-question">
                                <span>Do cooperative housing societies in Pune qualify for government subsidies?</span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="faq-answer">
                                <p>Yes. Group Housing Societies (GHS) and Resident Welfare Associations (RWAs) in Pune can receive ₹18,000 per kW up to 500 kW under PM Surya Ghar for common area services like elevators, parking lights, and water pressure pumping systems.</p>
                            </div>
                        </div>

                    </div>

                    <!-- Sidebar Form -->
                    <div class="sticky-desktop">
                        <div style="background: #f8f9fa; padding: 35px 30px; border-radius: 24px; border: 1px solid rgba(0,0,0,0.06); box-shadow: 0 10px 35px rgba(0,0,0,0.04);">
                            <h3 style="margin-bottom: 8px; font-size: 22px;">Book Pune City Roof Survey</h3>
                            <p style="font-size: 14px; color: #666; margin-bottom: 20px;">Our licensed solar engineers evaluate your terrace and power bills within 24-48 hours.</p>
                            <form id="area-form" action="https://formsubmit.co/egreensolution1@gmail.com" method="POST" style="display: grid; gap: 16px;">
                                <input type="hidden" name="_subject" value="New Service Area Lead - Pune City">
                                <input type="hidden" name="_template" value="table">
                                <input type="hidden" name="_captcha" value="false">
                                <input type="text" name="fullName" placeholder="Full Name" style="padding: 14px; border-radius: 10px; border: 1px solid #ddd; width: 100%;" required>
                                <input type="tel" name="phone" placeholder="Phone Number" style="padding: 14px; border-radius: 10px; border: 1px solid #ddd; width: 100%;" required>
                                <input type="text" name="location" placeholder="Pune Area (e.g. Kothrud, Aundh, Camp)" style="padding: 14px; border-radius: 10px; border: 1px solid #ddd; width: 100%;" required>
                                <textarea name="message" placeholder="Current Monthly Bill (Approx ₹)" style="padding: 14px; border-radius: 10px; border: 1px solid #ddd; width: 100%; height: 75px;"></textarea>
                                <button type="submit" class="btn-primary" style="width: 100%; justify-content: center; border: none; cursor: pointer; padding: 16px;">Schedule Free Survey <i class="fas fa-calendar-check"></i></button>
                            </form>
                        </div>

                        <div style="margin-top: 25px; background: #e8f5e9; padding: 22px; border-radius: 18px; border: 1px solid #c8e6c9;">
                            <h4 style="color: var(--primary); margin-bottom: 8px; font-size: 16px;"><i class="fas fa-certificate"></i> MNRE Empanelled Installer</h4>
                            <p style="font-size: 13px; line-height: 1.6; color: #2e7d32; margin: 0;">Authorized installer under PM Surya Ghar Muft Bijli Yojana with direct bank subsidy disbursement support across Pune & Maharashtra.</p>
                        </div>

                        <div style="margin-top: 20px; background: #fff; padding: 20px; border-radius: 18px; border: 1px solid #e2e8f0;">
                            <h4 style="font-size: 15px; margin-bottom: 10px; color: #0f172a;"><i class="fas fa-location-arrow" style="color: var(--primary);"></i> Nearby Service Corridors</h4>
                            <ul style="list-style: none; padding: 0; margin: 0; font-size: 13.5px; line-height: 2;">
                                <li><a href="/solar-panel-baner-bavdhan" style="color: #475569; text-decoration: none;"><i class="fas fa-chevron-right" style="font-size: 10px; color: var(--primary);"></i> Baner, Balewadi &amp; Bavdhan</a></li>
                                <li><a href="/solar-panel-pimpri-chinchwad" style="color: #475569; text-decoration: none;"><i class="fas fa-chevron-right" style="font-size: 10px; color: var(--primary);"></i> Pimpri Chinchwad (PCMC)</a></li>
                                <li><a href="/solar-panel-kiwale" style="color: #475569; text-decoration: none;"><i class="fas fa-chevron-right" style="font-size: 10px; color: var(--primary);"></i> Kiwale &amp; Ravet Corridor</a></li>
                                <li><a href="/areas" style="color: var(--primary); font-weight: 600; text-decoration: none;"><i class="fas fa-th-large"></i> View All 10 Pune Hubs &rarr;</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="section-padding bg-primary-gradient">
        <div class="container footer-grid">
            <div class="footer-col">
                <a href="/" class="logo" style="margin-bottom: 20px; display: block;">
                    <img src="/assets/logo.png" alt="E Green Solution - Certified Solar Panel Dealers Pune" decoding="async" loading="eager" width="160" height="55" style="fetchpriority: high;">
                </a>
                <p style="opacity: 0.8; line-height: 1.8; margin-bottom: 25px; font-size: 15px;">E Green Solution is a trusted rooftop solar engineering and EPC company based in Pune, delivering high-performance residential, commercial, and industrial solar power systems with end-to-end MSEDCL net metering and maintenance support.</p>
            </div>
            <div class="footer-col">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="/">Home</a></li>
                    <li><a href="/solar-guide">Solar 101</a></li>
                    <li><a href="/services">Services</a></li>
                    <li><a href="/blog">Blog</a></li>
                    <li><a href="/about">About Us</a></li>
                    <li><a href="/projects">Projects</a></li>
                    <li><a href="/calculator">Solar Calculator</a></li>
                    <li><a href="/privacy-policy">Privacy Policy</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h3>Contact Info</h3>
                <ul>
                    <li><i class="fas fa-phone"></i> <a href="tel:+917249187969" style="font-weight: 700;">+91 7249187969</a></li>
                    <li><i class="fab fa-whatsapp"></i> <a href="https://wa.me/917249187969" style="font-weight: 700;" target="_blank" rel="noopener noreferrer">WhatsApp Us</a></li>
                    <li><i class="fas fa-envelope"></i> <a href="mailto:egreensolution1@gmail.com" class="email-obfuscated">egreensolution1@gmail.com</a></li>
                    <li>
                        <i class="fas fa-map-marker-alt"></i>
                        <address style="display:inline; font-style:normal;" itemscope itemtype="https://schema.org/LocalBusiness">
                            <span itemprop="name" style="display:none;">E Green Solution</span>
                            <span itemprop="streetAddress" style="display:none;">Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi</span>
                            <span itemprop="addressLocality">Pune</span>, <span itemprop="addressRegion">Maharashtra</span>
                            <meta itemprop="postalCode" content="411043">
                            <meta itemprop="telephone" content="+917249187969">
                        </address>
                    </li>
                </ul>
            </div>
            <div class="footer-col">
                <h3>Service Areas</h3>
                <ul>
                    <li><a href="/solar-panel-pune"><i class="fas fa-map-marker-alt"></i> Pune City</a></li>
                    <li><a href="/solar-panel-chakan"><i class="fas fa-industry"></i> Chakan MIDC</a></li>
                    <li><a href="/solar-panel-pimpri-chinchwad"><i class="fas fa-city"></i> PCMC Area</a></li>
                    <li><a href="/solar-panel-baner-bavdhan"><i class="fas fa-home"></i> Baner & Bavdhan</a></li>
                    <li><a href="/solar-panel-lonavala"><i class="fas fa-mountain"></i> Lonavala</a></li>
                    <li><a href="/areas"><i class="fas fa-plus-circle"></i> View All Areas</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h3>Solar Solutions</h3>
                <ul>
                    <li><a href="/residential-solar"><i class="fas fa-home"></i> Residential Solar</a></li>
                    <li><a href="/industrial-solar"><i class="fas fa-industry"></i> Industrial Solar</a></li>
                    <li><a href="/solar-subsidy"><i class="fas fa-file-invoice-dollar"></i> Solar Subsidy</a></li>
                    <li><a href="/solar-panel-cleaning-pune"><i class="fas fa-broom"></i> Panel Cleaning</a></li>
                    <li><a href="/solar-amc-pune"><i class="fas fa-file-contract"></i> Solar AMC Contracts</a></li>
                    <li><a href="/solar-repair-maintenance-pune"><i class="fas fa-tools"></i> Plant Maintenance</a></li>
                    <li><a href="/solar-inverter-repair-pune"><i class="fas fa-bolt"></i> Inverter Repair</a></li>
                    <li><a href="/solar-net-meter-msedcl-pune"><i class="fas fa-tachometer-alt"></i> Net Meter Testing</a></li>
                    <li><a href="/solar-plant-revamping-repowering"><i class="fas fa-sync-alt"></i> Solar Repowering</a></li>
                </ul>
            </div>
        </div>
        <div class="container footer-bottom">
            &copy; 2026 E Green Solution. All Rights Reserved. &nbsp; | &nbsp; <a href="/privacy-policy" style="color: inherit; text-decoration: none; opacity: 0.8;">Privacy Policy</a> &nbsp; | &nbsp; Designed with <i class="fas fa-heart" style="color: #ff4d4d;"></i> for a greener future.
        </div>
    </footer>

    <div class="fab-container" role="complementary" aria-label="Quick Contact Buttons">
        <a href="https://wa.me/917249187969?text=Hi, I'm interested in Pune City solar rooftop installation."
            class="fab whatsapp" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">
            <i class="fab fa-whatsapp"></i>
        </a>
        <a href="tel:+917249187969" class="fab call" aria-label="Call E Green Solution">
            <i class="fas fa-phone"></i>
        </a>
    </div>

    <nav class="mobile-bottom-nav" aria-label="Mobile Bottom Navigation">
        <a href="/" class="bottom-nav-item active">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="/services" class="bottom-nav-item">
            <i class="fas fa-tools"></i>
            <span>Services</span>
        </a>
        <a href="/calculator" class="bottom-nav-item">
            <i class="fas fa-calculator"></i>
            <span>Calc</span>
        </a>
        <a href="/solar-subsidy" class="bottom-nav-item">
            <i class="fas fa-file-invoice-dollar"></i>
            <span>Subsidy</span>
        </a>
        <a href="https://wa.me/917249187969" class="bottom-nav-item" target="_blank">
            <i class="fab fa-whatsapp"></i>
            <span>WhatsApp</span>
        </a>
    </nav>

    <script src="/js/main.js"></script>
    <script>
        document.querySelectorAll('.faq-question').forEach(button => {
            button.addEventListener('click', () => {
                const answer = button.nextElementSibling;
                const isOpen = answer.style.display === 'block';
                document.querySelectorAll('.faq-answer').forEach(a => a.style.display = 'none');
                document.querySelectorAll('.faq-question i').forEach(icon => icon.classList.replace('fa-chevron-up', 'fa-chevron-down'));
                if (!isOpen) {
                    answer.style.display = 'block';
                    button.querySelector('i').classList.replace('fa-chevron-down', 'fa-chevron-up');
                }
            });
        });
    </script>
</body>
</html>
`;

fs.writeFileSync(filePath, htmlContent, 'utf8');
console.log('Successfully updated solar-panel-pune.html');
