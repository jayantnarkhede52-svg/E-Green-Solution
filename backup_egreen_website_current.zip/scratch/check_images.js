const fs = require('fs');
const path = require('path');

const imgDir = path.join(__dirname, '..', 'assets');
const files = fs.readdirSync(imgDir).filter(f => f.startsWith('IMG-20260326-WA') || f.startsWith('Projects_egreen'));

console.log('Project images:');
const pDir = path.join(__dirname, '..', 'assets', 'Projects_egreen');
if (fs.existsSync(pDir)) {
  fs.readdirSync(pDir).forEach(f => {
    const stat = fs.statSync(path.join(pDir, f));
    console.log(`Projects_egreen/${f}: ${stat.size} bytes`);
  });
}
