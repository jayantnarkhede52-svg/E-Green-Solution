const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const files = fs.readdirSync(rootDir).filter(f => f.endsWith('.html'));

console.log('=== Checking /blog links in root HTML files ===');
for (const file of files) {
    const content = fs.readFileSync(path.join(rootDir, file), 'utf8');
    const hasBlog = content.includes('href="/blog"');
    console.log(`${file}: ${hasBlog ? 'HAS /blog' : 'NO /blog'}`);
}
