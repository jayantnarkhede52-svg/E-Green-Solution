const http = require('http');

const urls = [
    'http://localhost:3000/solar-panel-cleaning-pune',
    'http://localhost:3000/solar-amc-pune',
    'http://localhost:3000/solar-repair-maintenance-pune',
    'http://localhost:3000/solar-inverter-repair-pune',
    'http://localhost:3000/solar-net-meter-msedcl-pune',
    'http://localhost:3000/solar-plant-revamping-repowering',
    'http://localhost:3000/services',
    'http://localhost:3000/residential-solar',
    'http://localhost:3000/industrial-solar',
    'http://localhost:3000/solar-subsidy',
    'http://localhost:3000/solar-guide',
    'http://localhost:3000/'
];

async function checkUrl(u) {
    return new Promise((resolve) => {
        http.get(u, (res) => {
            resolve({ url: u, status: res.statusCode });
        }).on('error', (err) => {
            resolve({ url: u, error: err.message });
        });
    });
}

(async () => {
    console.log('Testing URLs on localhost:3000:');
    let allOk = true;
    for (const u of urls) {
        const result = await checkUrl(u);
        console.log(`${result.status === 200 ? '✓' : '✗'} ${result.url} -> ${result.status || result.error}`);
        if (result.status !== 200) allOk = false;
    }
    if (allOk) {
        console.log('\nALL 12 TESTED ROUTES RESPONDED WITH HTTP 200 OK!');
    }
})();
