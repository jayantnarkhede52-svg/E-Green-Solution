const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const blogDir = path.join(rootDir, 'blog');

const files = fs.readdirSync(rootDir).filter(f => f.endsWith('.html') && f !== 'solar-hero.html').map(f => path.join(rootDir, f));
const blogFiles = fs.readdirSync(blogDir).filter(f => f.endsWith('.html')).map(f => path.join(blogDir, f));

const allFiles = [...files, ...blogFiles];

const standardFavicon = `    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/favicon.png">
    <link rel="apple-touch-icon" href="/assets/logo.png">`;

let updatedCount = 0;

for (const filePath of allFiles) {
    let content = fs.readFileSync(filePath, 'utf8');
    const original = content;

    // Check if it already has all 3
    const has32 = content.includes('sizes="32x32"') && content.includes('/assets/favicon.png');
    const has16 = content.includes('sizes="16x16"') && content.includes('/assets/favicon.png');
    const hasApple = content.includes('rel="apple-touch-icon"') && content.includes('/assets/logo.png');

    if (has32 && has16 && hasApple) {
        // Already fully standardized
        continue;
    }

    // If it has single <link rel="icon"...>, replace it
    if (/<link[^>]*rel=["'](?:icon|shortcut icon)["'][^>]*>/i.test(content)) {
        content = content.replace(/(?:<!--\s*Favicon\s*-->\s*)?<link[^>]*rel=["'](?:icon|shortcut icon|apple-touch-icon)["'][^>]*>(?:\s*<link[^>]*rel=["'](?:icon|shortcut icon|apple-touch-icon)["'][^>]*>)*/i, standardFavicon);
    } else {
        // Insert before </head>
        content = content.replace('</head>', `${standardFavicon}\n</head>`);
    }

    if (content !== original) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Standardized favicon in: ${path.relative(rootDir, filePath)}`);
        updatedCount++;
    }
}

console.log(`Total files with standardized favicons: ${updatedCount}`);
