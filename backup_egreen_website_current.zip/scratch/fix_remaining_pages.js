const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

const files = [
    'solar-panel-baner-bavdhan.html',
    'solar-panel-bhosari-pcmc.html',
    'solar-panel-chakan.html'
];

files.forEach(f => {
    const p = path.join(ROOT, f);
    let content = fs.readFileSync(p, 'utf8');

    content = content.replace(/"streetAddress":\s*"[^"]+"/g, '"streetAddress": "Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi"');
    content = content.replace(/"addressLocality":\s*"[^"]+"/g, '"addressLocality": "Pune"');
    content = content.replace(/"postalCode":\s*"[^"]+"/g, '"postalCode": "411043"');
    content = content.replace(/"latitude":\s*[\d\.]+,\s*"longitude":\s*[\d\.]+/g, '"latitude": 18.5204,\n        "longitude": 73.8567');

    fs.writeFileSync(p, content, 'utf8');
    console.log(`✅ Standardized address in ${f}`);
});
