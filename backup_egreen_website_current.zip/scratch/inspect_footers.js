const fs = require('fs');

const files = fs.readdirSync('.').filter(f => f.endsWith('.html'));

files.forEach(f => {
  const content = fs.readFileSync(f, 'utf8');
  const footerMatch = content.match(/<footer[\s\S]*?<div class=["']footer-col["']>([\s\S]*?)<\/div>/i);
  if (footerMatch) {
    const text = footerMatch[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    console.log(`[${f}]: ${text.slice(0, 160)}...`);
  }
});
