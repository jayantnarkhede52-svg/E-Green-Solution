import re

with open('c:/work/E GREEN WEBSITE/projects/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update video-spotlight
old_video = '''            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 40px; margin-bottom: 20px;">
                <div class="glass-element" style="border-radius: 24px; overflow: hidden; aspect-ratio: 16/9; box-shadow: var(--card-shadow);">
                    <video width="100%" height="100%" controls muted playsinline preload="metadata" poster="/assets/Projects_egreen/IMG-20260331-WA0019.jpg" style="object-fit: cover; display: block;" aria-label="Eagle Burgmann 200kW Industrial Rooftop Solar Video">
                        <source src="/assets/projects/video1.mp4" type="video/mp4">
                        Video walkthrough of our 200kW industrial solar installation at Eagle Burgmann India, Pune.
                    </video>
                </div>
                <div class="glass-element" style="border-radius: 24px; overflow: hidden; aspect-ratio: 16/9; box-shadow: var(--card-shadow);">
                    <video width="100%" height="100%" controls muted playsinline preload="metadata" poster="/assets/Projects_egreen/IMG-20260331-WA0013.jpg" style="object-fit: cover; display: block;" aria-label="Bhagawati Industries 140kW Solar Installation Video">
                        <source src="/assets/projects/video2.mp4" type="video/mp4">
                        Video walkthrough of our 140kW high-capacity solar plant at Bhagawati Industries, Pune.
                    </video>
                </div>
            </div>'''

new_video = '''            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 30px; margin-bottom: 20px;">
                <div class="glass-element" style="border-radius: 24px; overflow: hidden; aspect-ratio: 16/9; box-shadow: var(--card-shadow);">
                    <video width="100%" height="100%" controls muted playsinline preload="metadata" poster="/assets/projects/konark_society_rooftop_100kw.jpg" style="object-fit: cover; display: block;" aria-label="Konark A Plus 100kW Housing Society Solar Video">
                        <source src="/assets/projects/konark_society_walkthrough.mp4" type="video/mp4">
                        Video walkthrough of our 100kW rooftop solar plant at Konark A Plus Housing Society, Sopan Baug, Pune.
                    </video>
                </div>
                <div class="glass-element" style="border-radius: 24px; overflow: hidden; aspect-ratio: 16/9; box-shadow: var(--card-shadow);">
                    <video width="100%" height="100%" controls muted playsinline preload="metadata" poster="/assets/Projects_egreen/IMG-20260331-WA0019.jpg" style="object-fit: cover; display: block;" aria-label="Eagle Burgmann 200kW Industrial Rooftop Solar Video">
                        <source src="/assets/projects/video1.mp4" type="video/mp4">
                        Video walkthrough of our 200kW industrial solar installation at Eagle Burgmann India, Pune.
                    </video>
                </div>
                <div class="glass-element" style="border-radius: 24px; overflow: hidden; aspect-ratio: 16/9; box-shadow: var(--card-shadow);">
                    <video width="100%" height="100%" controls muted playsinline preload="metadata" poster="/assets/Projects_egreen/IMG-20260331-WA0013.jpg" style="object-fit: cover; display: block;" aria-label="Bhagawati Industries 140kW Solar Installation Video">
                        <source src="/assets/projects/video2.mp4" type="video/mp4">
                        Video walkthrough of our 140kW high-capacity solar plant at Bhagawati Industries, Pune.
                    </video>
                </div>
            </div>'''

# 2. Add Konark card to project-grid
old_grid = '<div class="project-grid">'
new_grid = '''<div class="project-grid">
                <!-- Featured Case Study: Konark A Plus Housing Society -->
                <a href="/projects/konark-a-plus-100kw-housing-society-solar-pune" class="project-card animate-reveal" style="text-decoration: none; color: inherit; display: block; position: relative; border: 2px solid #2e7d32; border-radius: 20px; overflow: hidden;">
                    <span style="position: absolute; top: 15px; left: 15px; background: #2e7d32; color: #fff; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; z-index: 2; box-shadow: 0 4px 10px rgba(0,0,0,0.2);"><i class="fas fa-star"></i> Featured Society Case Study</span>
                    <img src="/assets/projects/konark_society_rooftop_100kw.jpg" alt="Konark A Plus Housing Society - 100kW Solar Installation Pune" loading="lazy">
                    <div class="project-overlay">
                        <h3>Konark A Plus Society, Sopan Baug</h3>
                        <p><i class="fas fa-building"></i> 100 kW Housing Society EPC</p>
                        <p style="font-size: 13px; opacity: 0.9; margin-top: 4px;"><i class="fas fa-chart-line"></i> ₹3.2L → ₹32k/mo | 90% Bill Slash | Read Case Study &rarr;</p>
                    </div>
                </a>'''

# 3. Make Eagle Burgmann card link to case study
old_eagle = '''                <!-- Project 06 -->
                <div class="project-card animate-reveal">
                    <img src="/assets/Projects_egreen/IMG-20260331-WA0019.jpg" alt="Eagle Burgmann India - 200KW Industrial Solar EPC Pune" loading="lazy">
                    <div class="project-overlay">
                        <h3>Eagle Burgmann India</h3>
                        <p><i class="fas fa-industry"></i> 200 kW Flagship Industrial EPC</p>
                        <p style="font-size: 13px; opacity: 0.9; margin-top: 4px;"><i class="fas fa-bolt"></i> 11kV HT Substation Sync</p>
                    </div>
                </div>'''

new_eagle = '''                <!-- Project 06: Eagle Burgmann Case Study -->
                <a href="/projects/eagle-burgmann-200kw-solar-pune" class="project-card animate-reveal" style="text-decoration: none; color: inherit; display: block;">
                    <img src="/assets/Projects_egreen/IMG-20260331-WA0019.jpg" alt="Eagle Burgmann India - 200KW Industrial Solar EPC Pune" loading="lazy">
                    <div class="project-overlay">
                        <h3>Eagle Burgmann India</h3>
                        <p><i class="fas fa-industry"></i> 200 kW Flagship Industrial EPC</p>
                        <p style="font-size: 13px; opacity: 0.9; margin-top: 4px;"><i class="fas fa-bolt"></i> 11kV HT Substation Sync | Read Case Study &rarr;</p>
                    </div>
                </a>'''

assert old_video in content, "old_video not found"
assert old_grid in content, "old_grid not found"
assert old_eagle in content, "old_eagle not found"

content = content.replace(old_video, new_video, 1)
content = content.replace(old_grid, new_grid, 1)
content = content.replace(old_eagle, new_eagle, 1)

with open('c:/work/E GREEN WEBSITE/projects/index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("SUCCESS: projects/index.html updated successfully!")
