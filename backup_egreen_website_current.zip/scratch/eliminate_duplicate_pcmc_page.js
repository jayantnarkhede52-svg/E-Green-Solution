const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

// 1. Overwrite solar-panel-pimpri-chinchwad.html with pimpri-chinchwad.html (adjusted for canonical URL)
const pcmcSourcePath = path.join(ROOT, 'pimpri-chinchwad.html');
const targetPath = path.join(ROOT, 'solar-panel-pimpri-chinchwad.html');

let pcmcContent = fs.readFileSync(pcmcSourcePath, 'utf8');

// Replace all canonical references
pcmcContent = pcmcContent.replace(
    /https:\/\/egreensolution\.in\/pimpri-chinchwad/g,
    'https://egreensolution.in/solar-panel-pimpri-chinchwad'
);
pcmcContent = pcmcContent.replace(
    /<input type="hidden" name="_page" value="pimpri-chinchwad">/g,
    '<input type="hidden" name="_page" value="solar-panel-pimpri-chinchwad">'
);

// Write to solar-panel-pimpri-chinchwad.html
fs.writeFileSync(targetPath, pcmcContent, 'utf8');
console.log('✅ solar-panel-pimpri-chinchwad.html updated with rich content and correct canonical.');

// 2. Delete pimpri-chinchwad.html
if (fs.existsSync(pcmcSourcePath)) {
    fs.unlinkSync(pcmcSourcePath);
    console.log('✅ pimpri-chinchwad.html deleted (eliminated duplicate page).');
}

// 3. Update server.js to add 301 redirect
const serverJsPath = path.join(ROOT, 'server.js');
let serverContent = fs.readFileSync(serverJsPath, 'utf8');

const redirectCode = `    // 301 Redirect for duplicate PCMC page to canonical /solar-panel-pimpri-chinchwad
    if (parsedUrl.pathname === '/pimpri-chinchwad' || parsedUrl.pathname === '/pimpri-chinchwad.html') {
        res.writeHead(301, { 'Location': '/solar-panel-pimpri-chinchwad' });
        res.end();
        return;
    }

    // 301 Redirect for legacy /areas/* paths to /areas hub`;

serverContent = serverContent.replace(
    '    // 301 Redirect for legacy /areas/* paths to /areas hub',
    redirectCode
);
fs.writeFileSync(serverJsPath, serverContent, 'utf8');
console.log('✅ server.js updated with 301 redirect from /pimpri-chinchwad to /solar-panel-pimpri-chinchwad.');

// 4. Update vercel.json
const vercelPath = path.join(ROOT, 'vercel.json');
let vercelContent = fs.readFileSync(vercelPath, 'utf8');
let vercelJson = JSON.parse(vercelContent);

if (!vercelJson.redirects) {
    vercelJson.redirects = [];
}
// Add redirect if not already present
if (!vercelJson.redirects.some(r => r.source === '/pimpri-chinchwad')) {
    vercelJson.redirects.unshift({
        source: '/pimpri-chinchwad',
        destination: '/solar-panel-pimpri-chinchwad',
        permanent: true
    });
}
fs.writeFileSync(vercelPath, JSON.stringify(vercelJson, null, 2), 'utf8');
console.log('✅ vercel.json updated with 301 redirect.');

// 5. Update sitemap.xml - Remove /pimpri-chinchwad entry
const sitemapPath = path.join(ROOT, 'sitemap.xml');
let sitemapContent = fs.readFileSync(sitemapPath, 'utf8');

const sitemapEntryRegex = /\s*<url>\s*<loc>https:\/\/egreensolution\.in\/pimpri-chinchwad<\/loc>[\s\S]*?<\/url>/g;
sitemapContent = sitemapContent.replace(sitemapEntryRegex, '');
fs.writeFileSync(sitemapPath, sitemapContent, 'utf8');
console.log('✅ sitemap.xml updated (removed /pimpri-chinchwad).');

// 6. Update areas.html
const areasPath = path.join(ROOT, 'areas.html');
let areasContent = fs.readFileSync(areasPath, 'utf8');
areasContent = areasContent.replace(
    /<div style="display: flex; gap: 12px; flex-wrap: wrap; margin-top: auto;">[\s\S]*?<\/div>/,
    '<a href="/solar-panel-pimpri-chinchwad" class="area-link">Explore PCMC Solar Solutions <i class="fas fa-arrow-right"></i></a>'
);
fs.writeFileSync(areasPath, areasContent, 'utf8');
console.log('✅ areas.html updated link to /solar-panel-pimpri-chinchwad.');

// 7. Update index.html footer
const indexPath = path.join(ROOT, 'index.html');
let indexContent = fs.readFileSync(indexPath, 'utf8');
indexContent = indexContent.replace(
    /\s*<li><a href="\/pimpri-chinchwad"><i class="fas fa-building"><\/i> Pimpri Chinchwad Hub<\/a><\/li>/g,
    ''
);
fs.writeFileSync(indexPath, indexContent, 'utf8');
console.log('✅ index.html footer cleaned.');

// 8. Update llms.txt & llms-full.txt
const llmsPath = path.join(ROOT, 'llms.txt');
let llmsContent = fs.readFileSync(llmsPath, 'utf8');
llmsContent = llmsContent.replace(
    /- \*\*Pimpri Chinchwad \(PCMC\) Municipal Authority\*\*: https:\/\/egreensolution\.in\/pimpri-chinchwad\n/g,
    ''
);
fs.writeFileSync(llmsPath, llmsContent, 'utf8');

const llmsFullPath = path.join(ROOT, 'llms-full.txt');
let llmsFullContent = fs.readFileSync(llmsFullPath, 'utf8');
llmsFullContent = llmsFullContent.replace(
    /- Pimpri Chinchwad \(PCMC\) Municipal Authority Hub: https:\/\/egreensolution\.in\/pimpri-chinchwad\n/g,
    ''
);
fs.writeFileSync(llmsFullPath, llmsFullContent, 'utf8');
console.log('✅ llms.txt & llms-full.txt updated.');

console.log('\n--- SINGLE PCMC PAGE COMPLETE ---');
