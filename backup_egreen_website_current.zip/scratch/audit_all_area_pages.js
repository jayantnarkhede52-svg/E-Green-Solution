const fs = require('fs');

const areaPages = [
  'solar-panel-pune.html',
  'solar-panel-chakan.html',
  'solar-panel-pimpri-chinchwad.html',
  'solar-panel-baner-bavdhan.html',
  'solar-panel-bhosari-pcmc.html',
  'solar-panel-kiwale.html',
  'solar-panel-lonavala.html'
];

console.log('=== AUDITING ALL 7 REGIONAL AREA PAGES ===\n');

areaPages.forEach(file => {
  if (!fs.existsSync(file)) {
    console.log(`File NOT FOUND: ${file}`);
    return;
  }

  const html = fs.readFileSync(file, 'utf8');
  console.log(`\n--------------------------------------------------`);
  console.log(`FILE: ${file} (${html.length} bytes)`);

  // Title
  const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
  const title = titleMatch ? titleMatch[1].replace(/&amp;/g, '&') : 'MISSING';
  console.log(`Title (${title.length} chars): "${title}"`);

  // Description
  const descMatch = html.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i);
  const desc = descMatch ? descMatch[1].replace(/&amp;/g, '&') : 'MISSING';
  console.log(`Description (${desc.length} chars): "${desc}"`);

  // Canonical
  const canMatch = html.match(/<link\s+rel=["']canonical["']\s+href=["']([^"']+)["']/i);
  console.log(`Canonical: ${canMatch ? canMatch[1] : 'MISSING'}`);

  // OpenGraph
  const ogTitle = html.match(/property=["']og:title["']/i);
  console.log(`OpenGraph: ${ogTitle ? 'YES' : 'MISSING'}`);

  // Twitter
  const twCard = html.match(/name=["']twitter:card["']|property=["']twitter:card["']/i);
  console.log(`Twitter: ${twCard ? 'YES' : 'MISSING'}`);

  // Geo
  const geoTag = html.match(/name=["']geo\.region["']/i);
  console.log(`Geo Tags: ${geoTag ? 'YES' : 'MISSING'}`);

  // Schema count & validation
  const schemas = [...html.matchAll(/<script\s+type=["']application\/ld\+json["']>([\s\S]*?)<\/script>/gi)];
  console.log(`JSON-LD Schemas: ${schemas.length}`);
  schemas.forEach((s, idx) => {
    try {
      const parsed = JSON.parse(s[1].trim());
      console.log(`   Schema #${idx+1} [${parsed['@type']}] Valid JSON: ✓`);
    } catch(e) {
      console.log(`   Schema #${idx+1} ERROR: ${e.message}`);
    }
  });

  // Headings
  const h1s = [...html.matchAll(/<h1[^>]*>([\s\S]*?)<\/h1>/gi)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
  console.log(`H1 (${h1s.length}): "${h1s.join(' | ')}"`);

  const h2s = [...html.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/gi)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
  console.log(`H2s (${h2s.length}): ${h2s.slice(0, 4).join(' | ')}${h2s.length > 4 ? ' ...' : ''}`);

  // Non-clean links
  const dirtyLinks = [...html.matchAll(/href=["']([^"']+\.html)["']/gi)].map(m => m[1]);
  if (dirtyLinks.length > 0) {
    console.log(`⚠ Non-clean .html links (${dirtyLinks.length}):`, dirtyLinks);
  } else {
    console.log(`Clean URLs: ✓ (0 .html links)`);
  }

  // Word count
  const text = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                   .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
                   .replace(/<[^>]+>/g, ' ')
                   .replace(/\s+/g, ' ')
                   .trim();
  const words = text.split(/\s+/).length;
  console.log(`Visible Words: ${words}`);
});
