const fs = require('fs');
const path = require('path');

const sampleFiles = ['index.html', 'services.html', 'about.html', 'contact.html', 'projects.html', 'calculator.html', 'solar-subsidy.html', 'solar-guide.html'];

for (const file of sampleFiles) {
    const content = fs.readFileSync(path.join('c:\\work\\E GREEN WEBSITE', file), 'utf8');
    console.log(`\n=================== ${file} ===================`);
    
    // Look for nav-links or nav ul
    const navMatch = content.match(/<nav[^>]*>[\s\S]*?<\/nav>/i) || content.match(/<ul[^>]*class=["'][^"']*nav[^"']*["'][^>]*>[\s\S]*?<\/ul>/i);
    if (navMatch) {
        console.log('--- NAV SAMPLE (first 300 chars) ---');
        console.log(navMatch[0].slice(0, 400));
    }

    // Look for Quick Links
    const quickLinksMatch = content.match(/<h3>Quick Links<\/h3>[\s\S]*?<\/ul>/i);
    if (quickLinksMatch) {
        console.log('--- QUICK LINKS ---');
        console.log(quickLinksMatch[0]);
    }
}
