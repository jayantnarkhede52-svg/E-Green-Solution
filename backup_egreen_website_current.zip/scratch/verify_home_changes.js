const http = require('http');

http.get('http://localhost:3000/', (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
        console.log(`[STATUS] HTTP ${res.statusCode}`);
        
        // 1. Check if "Explore Your Solar Power Plant" exists
        const hasExplore = data.includes('Explore Your Solar Power Plant');
        console.log(`[CHECK 1] "Explore Your Solar Power Plant" present? ${hasExplore ? 'FAIL (Still present)' : 'PASS (Successfully removed)'}`);

        // 2. Check if .services-grid-3col is in the HTML
        const hasGrid3Col = data.includes('services-grid services-grid-3col');
        console.log(`[CHECK 2] "services-grid-3col" class present? ${hasGrid3Col ? 'PASS' : 'FAIL'}`);

        // 3. Count service cards in #services-section
        const cardsMatch = data.match(/class="service-card"/g);
        console.log(`[CHECK 3] Total service-card elements on home page: ${cardsMatch ? cardsMatch.length : 0} (Expected 6 in services + 4 in process = 10)`);

        // 4. Verify all 6 service buttons are present
        const buttons = [
            'Explore Residential',
            'Explore Commercial',
            'Explore Industrial',
            'Explore Water Heaters',
            'View Solar AMC Plans',
            'Explore Cleaning & Repair'
        ];
        buttons.forEach(btn => {
            const hasBtn = data.includes(btn);
            console.log(`  - Button "${btn}": ${hasBtn ? 'PASS' : 'FAIL'}`);
        });

        // 5. Check if process section still exists and has 4 steps
        const hasProcess = data.includes('4 Simple Steps for Solar Panel Installations in Pune');
        console.log(`[CHECK 4] Process section intact? ${hasProcess ? 'PASS' : 'FAIL'}`);
    });
}).on('error', err => {
    console.error('Request failed:', err.message);
});
