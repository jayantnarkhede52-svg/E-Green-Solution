with open('c:/work/E GREEN WEBSITE/solar-subsidy.html', 'r', encoding='utf-8') as f:
    content = f.read()

target_table = '''                        <tr>
                            <td>3 kW and above</td>
                            <td>₹78,000 (Maximum)</td>
                        </tr>
                    </tbody>'''

replacement_table = '''                        <tr>
                            <td>3 kW and above</td>
                            <td>₹78,000 (Maximum)</td>
                        </tr>
                        <tr style="background: #eef7ee;">
                            <td><strong>Group Housing Societies (GHS / RWAs)</strong><br><small style="color: #666;">For common facilities: Lifts, Water Pumps, Lighting, EV Charging</small></td>
                            <td><strong style="color: #2e7d32;">₹18,00,000 for 100kW</strong><br>(₹18,000 per kW up to 500kW)</td>
                        </tr>
                    </tbody>'''

society_box = '''            <!-- Society Subsidy Spotlight -->
            <div style="background: #f8fafc; border: 2px solid #2e7d32; border-radius: 16px; padding: 25px 30px; margin-top: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
                <div>
                    <span style="background: #2e7d32; color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700;"><i class="fas fa-building"></i> Housing Society Subsidy in Action</span>
                    <h3 style="font-size: 20px; color: #0f172a; margin: 10px 0 6px;">Konark A Plus Housing Society: ₹18 Lakhs Subsidy Received</h3>
                    <p style="color: #475569; font-size: 15px; margin: 0; max-width: 650px;">See our verified case study where a 100kW rooftop plant slashed a ₹3.2+ Lakh monthly light bill down by 90% in Sopan Baug, Pune.</p>
                </div>
                <a href="/projects/konark-a-plus-100kw-housing-society-solar-pune" class="btn-primary" style="text-decoration: none; padding: 12px 24px; font-weight: 700; white-space: nowrap;">
                    View 100kW Case Study &rarr;
                </a>
            </div>
'''

if target_table in content:
    content = content.replace(target_table, replacement_table, 1)
    content = content.replace('            <div style="margin-top: 50px;">\n                <h2>How to Apply for Solar Subsidy in Pune?</h2>', society_box + '\n            <div style="margin-top: 50px;">\n                <h2>How to Apply for Solar Subsidy in Pune?</h2>', 1)
    with open('c:/work/E GREEN WEBSITE/solar-subsidy.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print("SUCCESS: solar-subsidy.html updated")
else:
    print("TARGET NOT FOUND in solar-subsidy.html")
