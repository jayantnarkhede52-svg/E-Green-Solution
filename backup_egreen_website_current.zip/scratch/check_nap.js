const fs = require('fs');

console.log('--- INSPECTING ADDRESSES, PHONES, AND CONTACT INFO ---');

const files = fs.readdirSync('.').filter(f => f.endsWith('.html'));

files.forEach(f => {
  const content = fs.readFileSync(f, 'utf8');
  console.log(`\n[${f}]:`);

  // Address
  const addrMatches = [...content.matchAll(/<i class=["']fas fa-map-marker-alt["']><\/i>([\s\S]*?)<\/li>/gi)];
  addrMatches.forEach(m => console.log('  Address text:', m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()));

  // Schema address
  const schemaAddrs = [...content.matchAll(/"streetAddress":\s*"([^"]+)"/gi)];
  schemaAddrs.forEach(m => console.log('  Schema streetAddress:', m[1]));

  // Phone numbers
  const phones = [...content.matchAll(/tel:([^"'>\s]+)/gi)];
  const uniquePhones = [...new Set(phones.map(m => m[1]))];
  console.log('  Phones in tel: links:', uniquePhones);
});
