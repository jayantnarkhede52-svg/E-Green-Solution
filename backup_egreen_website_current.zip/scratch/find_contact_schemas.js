const fs = require('fs');
const content = fs.readFileSync('contact.html', 'utf8');
const regex = /<script type="application\/ld\+json">([\s\S]*?)<\/script>/gi;
let m;
while ((m = regex.exec(content)) !== null) {
    console.log('--- FOUND SCHEMA ---');
    console.log(m[1].trim());
}
