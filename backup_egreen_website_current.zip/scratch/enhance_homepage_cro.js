const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const indexPath = path.join(rootDir, 'index.html');
let content = fs.readFileSync(indexPath, 'utf8');

// 1. Hero text highlight
content = content.replace(
  '<p class="hero-desc">Welcome to E Green Solution — trusted <strong>solar panel dealers in Pune</strong> delivering high-efficiency rooftop solar systems for homes, housing societies, and businesses. As authorized Tier-1 solar dealers (550W–600W mono PERC &amp; TOPCon modules), we empower 200+ homes and MIDC enterprises with PM Surya Ghar subsidy support, seamless MSEDCL net metering, and comprehensive long-term warranties.</p>',
  '<p class="hero-desc">Welcome to E Green Solution — trusted <span class="highlight-mark">solar panel dealers in Pune</span> delivering high-efficiency rooftop solar systems for homes, housing societies, and businesses. Empowering <span class="highlight-green">200+ commissioned rooftops</span> and MIDC enterprises with PM Surya Ghar subsidy up to <span class="highlight-mark">₹78,000</span>, <span class="accent-underline">seamless MSEDCL net metering</span>, and comprehensive 25-year performance warranties.</p>'
);

// 2. Service Cards text highlights
content = content.replace(
  '<p>Stop worrying about high power bills. Our residential solar panel installations in Pune slash monthly MSEDCL bills by up to 90% with ₹78,000 PM Surya Ghar subsidy.</p>',
  '<p>Stop worrying about high power bills. Our residential solar panel installations in Pune slash monthly MSEDCL bills by <span class="highlight-green">up to 90%</span> with <span class="highlight-mark">₹78,000 PM Surya Ghar subsidy</span>.</p>'
);

content = content.replace(
  '<p>Turn your office or hospital roof into a profit center. We help Pune businesses achieve fast 3-year ROI and 40% tax depreciation with high-yield commercial solar plants.</p>',
  '<p>Turn your office or hospital roof into a profit center. We help Pune businesses achieve fast <span class="highlight-green">3-year ROI</span> and <span class="highlight-mark">40% tax depreciation</span> with high-yield commercial solar plants.</p>'
);

content = content.replace(
  '<p>Heavy-duty turnkey EPC installations for Chakan, Bhosari, and Talegaon MIDC manufacturing plants with Tier-1 Vikram Solar panels and seamless HT grid sync.</p>',
  '<p>Heavy-duty turnkey EPC installations for Chakan, Bhosari, and Talegaon MIDC manufacturing plants with <span class="highlight-mark">Tier-1 panels</span> and <span class="accent-underline">seamless HT grid sync</span>.</p>'
);

content = content.replace(
  '<p>High-efficiency ETC and FPC solar water heating systems and commercial solar thermal solutions for residences, hotels, and hostels without recurring power costs.</p>',
  '<p>High-efficiency ETC and FPC solar water heating systems with <span class="highlight-mark">scale-resistant inner tanks</span> and <span class="accent-underline">zero recurring power costs</span>.</p>'
);

content = content.replace(
  '<p>Quarterly electrical checkups, earth resistance testing (&lt;5 ohms), thermal imaging scans, and rapid emergency breakdown support for Pune societies and factories.</p>',
  '<p>Quarterly electrical checkups, earth resistance testing, <span class="highlight-mark">thermal imaging scans</span>, and <span class="accent-underline">rapid emergency breakdown support</span>.</p>'
);

content = content.replace(
  '<p>Pure demineralized RO water washing restoring up to 25% yield, on-site inverter troubleshooting, and MSEDCL net meter testing liaisoning across Pune &amp; PCMC.</p>',
  '<p>Pure demineralized RO water washing <span class="highlight-green">restoring up to 25% yield</span> and <span class="highlight-mark">on-site inverter troubleshooting</span> across Pune &amp; PCMC.</p>'
);

fs.writeFileSync(indexPath, content, 'utf8');
console.log('Successfully enhanced homepage text highlighting and underlines!');
