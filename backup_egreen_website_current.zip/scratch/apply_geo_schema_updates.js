const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

// 1. UPDATE index.html
function updateIndex() {
    const indexPath = path.join(ROOT, 'index.html');
    let content = fs.readFileSync(indexPath, 'utf8');

    // Schema replacement in index.html
    const schemaTarget = /"@context":\s*"https:\/\/schema\.org",\s*"@type":\s*\["LocalBusiness",\s*"HomeAndConstructionBusiness"\],[\s\S]*?"aggregateRating":\s*\{[\s\S]*?"bestRating":\s*"5"\s*\}/;

    const enrichedSchema = `"@context": "https://schema.org",
      "@type": ["LocalBusiness", "SolarEnergyContractor", "HomeAndConstructionBusiness"],
      "name": "E Green Solution - Solar Panel Dealers Pune & Solar Panel Installations",
      "alternateName": ["E-Green Solution", "E Green Solar Pune", "Egreen Solution", "E Green Solution PCMC"],
      "image": "https://egreensolution.in/assets/logo.png",
      "@id": "https://egreensolution.in/#localbusiness",
      "url": "https://egreensolution.in/",
      "telephone": "+917249187969",
      "email": "info@egreensolution.in",
      "priceRange": "₹₹ - ₹₹₹",
      "sameAs": [
        "https://www.wikidata.org/wiki/Q1538",
        "https://www.wikidata.org/wiki/Q371194"
      ],
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi",
        "addressLocality": "Pune",
        "addressRegion": "Maharashtra",
        "postalCode": "411043",
        "addressCountry": "IN"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 18.5204,
        "longitude": 73.8567
      },
      "department": [
        {
          "@type": ["LocalBusiness", "SolarEnergyContractor"],
          "name": "E Green Solution - Pimpri Chinchwad Office",
          "url": "https://egreensolution.in/pimpri-chinchwad",
          "telephone": "+917249187969",
          "email": "info@egreensolution.in",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Shop No. 02, Ground Floor, Nisarg Vihar, Near D-Mart, Ravet",
            "addressLocality": "Pimpri Chinchwad",
            "addressRegion": "Maharashtra",
            "postalCode": "412101",
            "addressCountry": "IN"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": 18.6448,
            "longitude": 73.7408
          }
        }
      ],
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
          "opens": "09:00",
          "closes": "19:00"
        }
      ],
      "knowsAbout": [
        "Rooftop Solar PV Installation",
        "PM Surya Ghar Muft Bijli Yojana Subsidy",
        "MSEDCL Net Metering Approval",
        "Commercial and Industrial Solar EPC",
        "Vikram Solar Monocrystalline & TOPCon Panels",
        "Bifacial Solar Module Systems",
        "Solar Panel Cleaning and Preventive AMC",
        "Solar Inverter Repair and Testing"
      ],
      "areaServed": [
        {
          "@type": "City",
          "name": "Pune",
          "sameAs": "https://www.wikidata.org/wiki/Q1538"
        },
        {
          "@type": "City",
          "name": "Pimpri-Chinchwad",
          "sameAs": "https://www.wikidata.org/wiki/Q371194"
        },
        "Baner", "Hinjewadi", "Wakad", "Kothrud", "Aundh",
        "Kharadi", "Viman Nagar", "Hadapsar", "Magarpatta", "Kalyani Nagar",
        "Ravet", "Nigdi", "Akurdi", "Chinchwad", "Pimpri",
        "Chakan", "Talegaon", "Bhosari",
        "Koregaon Park", "Katraj", "Kondhwa", "Undri", "Wagholi",
        "Pimple Saudagar", "Balewadi", "Pashan", "Sus", "Shivajinagar",
        "Lohegaon", "Dhanori", "Moshi", "Ambegaon", "Narhe"
      ],
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.9",
        "reviewCount": "128",
        "bestRating": "5"
      }`;

    if (schemaTarget.test(content)) {
        content = content.replace(schemaTarget, enrichedSchema);
        console.log('✅ index.html schema updated successfully.');
    } else {
        console.warn('⚠️ Could not match schemaTarget in index.html');
    }

    // Add pimpri-chinchwad link in Service Areas footer if not present
    if (!content.includes('href="/pimpri-chinchwad"')) {
        content = content.replace(
            '<li><a href="/solar-panel-pimpri-chinchwad"><i class="fas fa-city"></i> PCMC Area</a></li>',
            '<li><a href="/solar-panel-pimpri-chinchwad"><i class="fas fa-city"></i> PCMC Area</a></li>\n                    <li><a href="/pimpri-chinchwad"><i class="fas fa-building"></i> Pimpri Chinchwad Hub</a></li>'
        );
        console.log('✅ index.html footer link added for /pimpri-chinchwad.');
    }

    fs.writeFileSync(indexPath, content, 'utf8');
}

// 2. UPDATE about.html
function updateAbout() {
    const aboutPath = path.join(ROOT, 'about.html');
    let content = fs.readFileSync(aboutPath, 'utf8');

    // Fix canonical
    content = content.replace(
        '<link rel="canonical" href="https://egreensolution.in/about.html">',
        '<link rel="canonical" href="https://egreensolution.in/about">'
    );

    // Geo metadata check
    if (!content.includes('<meta name="geo.region"')) {
        const geoMeta = `
    <!-- Geo Targeting Metadata for GEO & Local Search -->
    <meta name="geo.region" content="IN-MH">
    <meta name="geo.placename" content="Pune, Maharashtra, India">
    <meta name="geo.position" content="18.5204;73.8567">
    <meta name="ICBM" content="18.5204, 73.8567">`;
        content = content.replace('</title>', '</title>' + geoMeta);
        console.log('✅ about.html geo metadata added.');
    }

    // Add Organization/LocalBusiness Schema before BreadcrumbList
    if (!content.includes('"@id": "https://egreensolution.in/#organization"')) {
        const orgSchema = `    <!-- Linked Data Knowledge Graph Schema (GEO, AIO & AEO) -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": ["LocalBusiness", "SolarEnergyContractor"],
          "@id": "https://egreensolution.in/#organization",
          "name": "E Green Solution",
          "alternateName": "E Green Solar Pune",
          "url": "https://egreensolution.in/",
          "logo": "https://egreensolution.in/assets/logo.png",
          "telephone": "+917249187969",
          "email": "info@egreensolution.in",
          "priceRange": "₹₹ - ₹₹₹",
          "sameAs": [
            "https://www.wikidata.org/wiki/Q1538",
            "https://www.wikidata.org/wiki/Q371194",
            "https://www.wikidata.org/wiki/Q1191"
          ],
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi",
            "addressLocality": "Pune",
            "addressRegion": "Maharashtra",
            "postalCode": "411043",
            "addressCountry": "IN"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": 18.5204,
            "longitude": 73.8567
          },
          "knowsAbout": [
            "Rooftop Solar EPC",
            "PM Surya Ghar Subsidy",
            "Vikram Solar Modules",
            "MSEDCL Net Metering",
            "Commercial Solar Engineering"
          ]
        },
`;
        content = content.replace(
            '    <script type="application/ld+json">\n    {\n      "@context": "https://schema.org",\n      "@type": "BreadcrumbList"',
            orgSchema + '        {\n          "@type": "BreadcrumbList"'
        );
        content = content.replace(
            '      }]\n    }\n    </script>',
            '      }]\n        }\n      ]\n    }\n    </script>'
        );
        console.log('✅ about.html schema enriched with Knowledge Graph.');
    }

    fs.writeFileSync(aboutPath, content, 'utf8');
}

// 3. UPDATE contact.html
function updateContact() {
    const contactPath = path.join(ROOT, 'contact.html');
    let content = fs.readFileSync(contactPath, 'utf8');

    // Geo metadata
    if (!content.includes('<meta name="geo.region"')) {
        const geoMeta = `
    <!-- Geo Targeting Metadata for GEO & Local Search -->
    <meta name="geo.region" content="IN-MH">
    <meta name="geo.placename" content="Pune, Maharashtra, India">
    <meta name="geo.position" content="18.5204;73.8567">
    <meta name="ICBM" content="18.5204, 73.8567">`;
        content = content.replace('</title>', '</title>' + geoMeta);
        console.log('✅ contact.html geo metadata added.');
    }

    // Add LocalBusiness Schema to contact.html
    if (!content.includes('"@id": "https://egreensolution.in/#contact-business"')) {
        const contactSchema = `    <!-- LocalBusiness Linked Data Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": ["LocalBusiness", "SolarEnergyContractor"],
          "@id": "https://egreensolution.in/#contact-business",
          "name": "E Green Solution",
          "url": "https://egreensolution.in/contact",
          "logo": "https://egreensolution.in/assets/logo.png",
          "telephone": "+917249187969",
          "email": "info@egreensolution.in",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi",
            "addressLocality": "Pune",
            "addressRegion": "Maharashtra",
            "postalCode": "411043",
            "addressCountry": "IN"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": 18.5204,
            "longitude": 73.8567
          },
          "department": [
            {
              "@type": "LocalBusiness",
              "name": "E Green Solution Pimpri Chinchwad",
              "telephone": "+917249187969",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "Shop No. 02, Ground Floor, Nisarg Vihar, Near D-Mart, Ravet",
                "addressLocality": "Pimpri Chinchwad",
                "addressRegion": "Maharashtra",
                "postalCode": "412101",
                "addressCountry": "IN"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 18.6448,
                "longitude": 73.7408
              }
            }
          ]
        },
`;
        content = content.replace(
            '    <script type="application/ld+json">\n    {\n      "@context": "https://schema.org",\n      "@type": "BreadcrumbList"',
            contactSchema + '        {\n          "@type": "BreadcrumbList"'
        );
        content = content.replace(
            '      }]\n    }\n    </script>',
            '      }]\n        }\n      ]\n    }\n    </script>'
        );
        console.log('✅ contact.html schema enriched with Multi-Office LocalBusiness.');
    }

    // Add PCMC Ravet Office to the Visit Us section in contact.html
    if (!content.includes('Nisarg Vihar, Near D-Mart, Ravet')) {
        const pcmcHtml = `                            <div style="margin-bottom: 16px;">
                                <span style="display: block; font-size: 13px; font-weight: 700; text-transform: uppercase; color: var(--accent); letter-spacing: 0.5px; margin-bottom: 2px;">PCMC / Ravet Office</span>
                                <p style="font-weight: 600; font-size: 15px; line-height: 1.4; color: #fff;">Shop No. 02, Ground Floor, Nisarg Vihar,<br>Near D-Mart, Ravet, PCMC - 412101</p>
                            </div>
                            `;
        content = content.replace(
            '<div style="margin-bottom: 16px;">\n                                <span style="display: block; font-size: 13px; font-weight: 700; text-transform: uppercase; color: var(--accent); letter-spacing: 0.5px; margin-bottom: 2px;">Pune Office</span>',
            pcmcHtml + '<div style="margin-bottom: 16px;">\n                                <span style="display: block; font-size: 13px; font-weight: 700; text-transform: uppercase; color: var(--accent); letter-spacing: 0.5px; margin-bottom: 2px;">Pune Office</span>'
        );
        console.log('✅ contact.html visit us panel updated with PCMC / Ravet Office.');
    }

    fs.writeFileSync(contactPath, content, 'utf8');
}

// 4. UPDATE areas.html
function updateAreas() {
    const areasPath = path.join(ROOT, 'areas.html');
    let content = fs.readFileSync(areasPath, 'utf8');

    // Schema Wikidata entities
    if (!content.includes('https://www.wikidata.org/wiki/Q371194')) {
        content = content.replace(
            '{ "@type": "City", "name": "Pune" },\n        { "@type": "City", "name": "Pimpri-Chinchwad" },',
            '{\n          "@type": "City",\n          "name": "Pune",\n          "sameAs": "https://www.wikidata.org/wiki/Q1538"\n        },\n        {\n          "@type": "City",\n          "name": "Pimpri-Chinchwad",\n          "sameAs": "https://www.wikidata.org/wiki/Q371194"\n        },'
        );
        console.log('✅ areas.html schema enriched with Wikidata entities.');
    }

    // Card 3 link to /pimpri-chinchwad as dedicated authority page
    if (content.includes('Explore PCMC Solar Solutions')) {
        content = content.replace(
            '<a href="/solar-panel-pimpri-chinchwad" class="area-link">Explore PCMC Solar Solutions <i class="fas fa-arrow-right"></i></a>',
            `<div style="display: flex; gap: 12px; flex-wrap: wrap; margin-top: auto;">
                        <a href="/pimpri-chinchwad" class="area-link" style="color: #166534; font-weight: 800;">PCMC Authority Hub <i class="fas fa-landmark"></i></a>
                        <a href="/solar-panel-pimpri-chinchwad" class="area-link">Installation Services <i class="fas fa-arrow-right"></i></a>
                    </div>`
        );
        console.log('✅ areas.html Card 3 updated with link to /pimpri-chinchwad.');
    }

    fs.writeFileSync(areasPath, content, 'utf8');
}

updateIndex();
updateAbout();
updateContact();
updateAreas();
console.log('All GEO schema and content updates applied.');
