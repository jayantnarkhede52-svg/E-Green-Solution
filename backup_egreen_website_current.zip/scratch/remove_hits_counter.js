const fs = require('fs');

const files = fs.readdirSync('.').filter(f => f.endsWith('.html'));

console.log('--- REMOVING VISITOR-COUNTER & HITS.SH ACROSS ALL FILES ---');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  let modified = false;

  // Pattern 1: <div class="visitor-counter" ...> ... </div>
  const counterRegex = /<div class=["']visitor-counter["'][^>]*>[\s\S]*?<\/div>/gi;
  if (counterRegex.test(content)) {
    content = content.replace(counterRegex, '');
    modified = true;
    console.log(`✓ Removed visitor-counter block from ${file}`);
  }

  // Pattern 2: Any stray hits.sh references
  if (content.includes('hits.sh')) {
    content = content.replace(/<img[^>]*src=["']https:\/\/hits\.sh[^"']*["'][^>]*>/gi, '');
    modified = true;
    console.log(`✓ Removed stray hits.sh img from ${file}`);
  }

  if (modified) {
    fs.writeFileSync(file, content, 'utf8');
  }
});

console.log('\n--- VERIFYING NO HITS.SH REMAINS ---');
files.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  if (content.includes('hits.sh')) {
    console.log(`⚠ WARNING: hits.sh still in ${file}`);
  }
});
console.log('Hits.sh check complete.');
