with open('c:/work/E GREEN WEBSITE/residential-solar.html', 'r', encoding='utf-8') as f:
    content = f.read()

target = '    <!-- FAQ Section -->'

spotlight = '''    <!-- Housing Society Featured Case Study Spotlight -->
    <section style="background: #0f172a; color: #fff; padding: 60px 0;">
        <div class="container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 40px; align-items: center;">
            <div>
                <span style="background: #2e7d32; color: #fff; padding: 5px 14px; border-radius: 20px; font-size: 13px; font-weight: 700; display: inline-block; margin-bottom: 15px;"><i class="fas fa-building"></i> Featured Housing Society Case Study</span>
                <h2 style="font-size: 32px; color: #fff; margin-bottom: 15px; line-height: 1.3;">Konark A Plus Housing Society - 100kW Solar Installation</h2>
                <p style="color: #cbd5e1; font-size: 16px; line-height: 1.7; margin-bottom: 20px;">
                    See how a premier housing society in Sopan Baug, Pune slashed their monthly MSEDCL electricity bill from ₹3.2+ Lakhs down to ~₹32,000 for common lifts, pumps, and lighting with ₹18 Lakhs central PM Surya Ghar subsidy support.
                </p>
                <div style="display: flex; gap: 15px; flex-wrap: wrap; margin-bottom: 25px;">
                    <div style="background: rgba(255,255,255,0.08); padding: 10px 18px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.15);">
                        <strong style="color: #4ade80; font-size: 20px; display: block;">90%</strong>
                        <span style="font-size: 12px; color: #94a3b8;">Bill Reduction</span>
                    </div>
                    <div style="background: rgba(255,255,255,0.08); padding: 10px 18px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.15);">
                        <strong style="color: #fbc02d; font-size: 20px; display: block;">₹18 Lakhs</strong>
                        <span style="font-size: 12px; color: #94a3b8;">GHS Subsidy</span>
                    </div>
                    <div style="background: rgba(255,255,255,0.08); padding: 10px 18px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.15);">
                        <strong style="color: #38bdf8; font-size: 20px; display: block;">&lt; 3 Years</strong>
                        <span style="font-size: 12px; color: #94a3b8;">Full Payback</span>
                    </div>
                </div>
                <a href="/projects/konark-a-plus-100kw-housing-society-solar-pune" class="btn-primary" style="display: inline-flex; align-items: center; gap: 10px; padding: 12px 26px; font-weight: 700; text-decoration: none;">
                    Read Full 100kW Society Case Study <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            <div>
                <img src="/assets/projects/konark_society_rooftop_100kw.jpg" alt="100kW Rooftop Solar Konark A Plus Housing Society Pune" style="width: 100%; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.4);" loading="lazy">
            </div>
        </div>
    </section>

    <!-- FAQ Section -->'''

if target in content:
    content = content.replace(target, spotlight, 1)
    with open('c:/work/E GREEN WEBSITE/residential-solar.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print("SUCCESS: residential-solar.html updated")
else:
    print("TARGET NOT FOUND")
