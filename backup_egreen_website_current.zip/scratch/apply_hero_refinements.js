const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

// 1. Update css/style.css
const cssPath = path.join(ROOT, 'css', 'style.css');
let cssContent = fs.readFileSync(cssPath, 'utf8');

const oldHighlightBlock = /\/\* 1\. Text Highlighting, Marker & Underline Accents \*\/[\s\S]*?\.trust-pill \{/;

const newHighlightBlock = `/* 1. Text Highlighting, Marker & Underline Accents */
.highlight-mark {
    background: linear-gradient(120deg, rgba(245, 166, 35, 0.14) 0%, rgba(255, 213, 126, 0.22) 100%);
    padding: 2px 8px;
    border-radius: 6px;
    box-decoration-break: clone;
    -webkit-box-decoration-break: clone;
    font-weight: 700;
    color: #b45309;
    border-bottom: 2px solid rgba(245, 166, 35, 0.6);
    transition: all 0.25s ease;
}

.highlight-green {
    background: linear-gradient(120deg, rgba(34, 197, 94, 0.14) 0%, rgba(74, 222, 128, 0.22) 100%);
    padding: 2px 8px;
    border-radius: 6px;
    box-decoration-break: clone;
    -webkit-box-decoration-break: clone;
    font-weight: 700;
    color: #166534;
    border-bottom: 2px solid rgba(34, 197, 94, 0.6);
    transition: all 0.25s ease;
}

.accent-underline {
    text-decoration: none;
    position: relative;
    background-image: linear-gradient(to right, #F5A623, #22c55e);
    background-position: bottom left;
    background-repeat: no-repeat;
    background-size: 100% 2.5px;
    padding-bottom: 2px;
    font-weight: 700;
}

/* Modern Dark Hero Accents (Homepage .hero, Service/Blog .hero-split, Header .page-header) */
.hero .highlight-mark,
.hero-split .highlight-mark,
.page-header .highlight-mark {
    background: rgba(251, 191, 36, 0.12) !important;
    color: #fde047 !important;
    border: 1px solid rgba(251, 191, 36, 0.35) !important;
    border-bottom: 2px solid #f59e0b !important;
    text-shadow: 0 0 10px rgba(251, 191, 36, 0.25) !important;
    box-shadow: 0 0 14px rgba(245, 166, 35, 0.12) !important;
}

.hero .highlight-green,
.hero-split .highlight-green,
.page-header .highlight-green {
    background: rgba(74, 222, 128, 0.12) !important;
    color: #4ade80 !important;
    border: 1px solid rgba(74, 222, 128, 0.35) !important;
    border-bottom: 2px solid #22c55e !important;
    text-shadow: 0 0 10px rgba(74, 222, 128, 0.25) !important;
    box-shadow: 0 0 14px rgba(74, 222, 128, 0.12) !important;
}

.hero .accent-underline,
.hero-split .accent-underline,
.page-header .accent-underline {
    color: #ffffff !important;
    background-image: linear-gradient(90deg, #f59e0b 0%, #4ade80 100%) !important;
}

.trust-pill {`;

if (oldHighlightBlock.test(cssContent)) {
    cssContent = cssContent.replace(oldHighlightBlock, newHighlightBlock);
    fs.writeFileSync(cssPath, cssContent, 'utf8');
    console.log('✅ css/style.css updated with radiant dark hero accents.');
} else {
    console.warn('⚠️ Could not match oldHighlightBlock in css/style.css');
}

// 2. Update index.html hero styles
const indexPath = path.join(ROOT, 'index.html');
let indexContent = fs.readFileSync(indexPath, 'utf8');

// Update eyebrow
const oldEyebrow = /\.eyebrow \{[\s\S]*?\.eyebrow::before \{[\s\S]*?background: var\(--gold\);\s*\}/;
const newEyebrow = `.eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: #4ade80;
        background: rgba(74, 222, 128, 0.08);
        border: 1px solid rgba(74, 222, 128, 0.25);
        padding: 6px 16px;
        border-radius: 30px;
        margin-bottom: 22px;
        box-shadow: 0 0 18px rgba(74, 222, 128, 0.1);
        opacity: 0;
        animation: fadeUp 0.7s 0.2s forwards;
      }
      .eyebrow::before {
        content: '';
        display: block;
        width: 7px; height: 7px;
        border-radius: 50%;
        background: #4ade80;
        box-shadow: 0 0 8px #4ade80;
      }`;

if (oldEyebrow.test(indexContent)) {
    indexContent = indexContent.replace(oldEyebrow, newEyebrow);
    console.log('✅ index.html eyebrow updated to glowing green badge.');
} else {
    console.warn('⚠️ Could not match oldEyebrow in index.html');
}

// Update h1.hero-title span
const oldSpan = /h1\.hero-title span \{\s*color: var\(--gold\);\s*-webkit-text-stroke: 0px;\s*\}/;
const newSpan = `h1.hero-title span {
        background: linear-gradient(135deg, #FFB800 0%, #FFA000 45%, #4ADE80 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        display: inline-block;
        filter: drop-shadow(0 2px 16px rgba(255, 184, 0, 0.25));
        -webkit-text-stroke: 0px;
      }`;

if (oldSpan.test(indexContent)) {
    indexContent = indexContent.replace(oldSpan, newSpan);
    console.log('✅ index.html hero title span updated to solar gold-to-green energy gradient.');
} else {
    console.warn('⚠️ Could not match oldSpan in index.html');
}

// Update .hero-desc
const oldDesc = /\.hero-desc \{\s*font-size: 15px;\s*line-height: 1\.75;\s*color: var\(--muted\);\s*max-width: 400px;\s*margin-bottom: 60px;\s*font-weight: 300;\s*opacity: 0;\s*animation: fadeUp 0\.7s 0\.5s forwards;\s*\}/;
const newDesc = `.hero-desc {
        font-size: 16px;
        line-height: 1.85;
        color: rgba(240, 238, 232, 0.85);
        max-width: 530px;
        margin-bottom: 45px;
        font-weight: 300;
        opacity: 0;
        animation: fadeUp 0.7s 0.5s forwards;
      }`;

if (oldDesc.test(indexContent)) {
    indexContent = indexContent.replace(oldDesc, newDesc);
    console.log('✅ index.html hero-desc updated with spacious max-width and enhanced readability.');
} else {
    console.warn('⚠️ Could not match oldDesc in index.html');
}

fs.writeFileSync(indexPath, indexContent, 'utf8');
console.log('--- HERO REFINEMENT COMPLETE ---');
