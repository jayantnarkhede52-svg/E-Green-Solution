const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const blogDir = path.join(rootDir, 'blog');

const files = fs.readdirSync(rootDir).filter(f => f.endsWith('.html') && f !== 'solar-hero.html').map(f => path.join(rootDir, f));
const blogFiles = fs.readdirSync(blogDir).filter(f => f.endsWith('.html')).map(f => path.join(blogDir, f));

const allFiles = [...files, ...blogFiles];

console.log('=== Checking Services link occurrences ===');
for (const filePath of allFiles) {
    const rel = path.relative(rootDir, filePath);
    const content = fs.readFileSync(filePath, 'utf8');
    const matches = content.match(/<li[^>]*>[\s\S]*?<a[^>]*href="\/services"[^>]*>Services<\/a>[\s\S]*?<\/li>/gi);
    console.log(`${rel}: ${matches ? matches.length : 0} occurrences`);
}
