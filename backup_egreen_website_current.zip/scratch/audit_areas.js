const fs = require('fs');

const html = fs.readFileSync('areas.html', 'utf8');

console.log('=== COMPREHENSIVE AREAS.HTML SEO AUDIT ===\n');
console.log('File size:', html.length, 'bytes');

// Title
const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
const title = titleMatch ? titleMatch[1].replace(/&amp;/g, '&') : '';
console.log('Title:', title, '| Length:', title.length, title.length >= 50 && title.length <= 65 ? '✓ (OPTIMAL)' : '⚠');

// Meta description
const descMatch = html.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i);
const desc = descMatch ? descMatch[1].replace(/&amp;/g, '&') : '';
console.log('Description:', desc, '| Length:', desc.length, desc.length >= 140 && desc.length <= 160 ? '✓ (OPTIMAL)' : '⚠');

// Canonical
const canMatch = html.match(/<link\s+rel=["']canonical["']\s+href=["']([^"']+)["']/i);
console.log('Canonical:', canMatch ? canMatch[1] : 'MISSING', canMatch && canMatch[1] === 'https://egreensolution.in/areas' ? '✓' : '⚠');

// OpenGraph
const ogTitle = html.match(/property=["']og:title["']/i);
const ogDesc = html.match(/property=["']og:description["']/i);
const ogImg = html.match(/property=["']og:image["']/i);
console.log('OpenGraph tags:', ogTitle && ogDesc && ogImg ? '✓ PRESENT' : 'MISSING');

// Twitter
const twitterCard = html.match(/name=["']twitter:card["']/i);
const twitterTitle = html.match(/name=["']twitter:title["']/i);
console.log('Twitter Cards:', twitterCard && twitterTitle ? '✓ PRESENT' : 'MISSING');

// Geo tags
const geoTag = html.match(/name=["']geo\.region["']/i);
console.log('Geo tags:', geoTag ? '✓ PRESENT' : 'MISSING');

// JSON-LD Schemas validation
console.log('\n--- JSON-LD STRUCTURED DATA AUDIT ---');
const jsonLdMatches = [...html.matchAll(/<script\s+type=["']application\/ld\+json["']>([\s\S]*?)<\/script>/gi)];
console.log('Found', jsonLdMatches.length, 'JSON-LD schema blocks:');

let allSchemasValid = true;
jsonLdMatches.forEach((m, idx) => {
  try {
    const parsed = JSON.parse(m[1].trim());
    console.log(`  [Schema #${idx + 1}] Type: ${parsed['@type']} | Valid JSON: ✓`);
  } catch (err) {
    allSchemasValid = false;
    console.error(`  [Schema #${idx + 1}] Syntax Error: ${err.message}`);
  }
});

// Headings
console.log('\n--- HEADING HIERARCHY ---');
const h1s = [...html.matchAll(/<h1[^>]*>([\s\S]*?)<\/h1>/gi)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
console.log('H1 (Should be exactly 1):', h1s.length, '->', h1s);

const h2s = [...html.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/gi)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
console.log(`H2s (${h2s.length} sections):`);
h2s.forEach((h, i) => console.log(`  ${i+1}. ${h}`));

// Cannibalization check:
// index.html owns: "solar panel dealers pune", "solar panel installations pune"
// areas.html must NOT spam those head terms as main headings/titles, but can contextual link to index.html
console.log('\n--- KEYWORD CANNIBALIZATION SAFEGUARDS ---');
const headTerm1 = (html.match(/solar panel dealers pune/gi) || []).length;
const headTerm2 = (html.match(/solar panel installations pune/gi) || []).length;
console.log('Head Term 1 ("solar panel dealers pune") occurrences in areas.html:', headTerm1, '(Should be 0 exact in body copy to avoid competing with index.html)');
console.log('Head Term 2 ("solar panel installations pune") occurrences in areas.html:', headTerm2, '(Should be 0 exact in body copy to avoid competing with index.html)');

// Check canonical links to index.html
const homeLinks = [...html.matchAll(/<a\s+[^>]*href=["']\/["'][^>]*>([\s\S]*?)<\/a>/gi)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
console.log('Contextual links pointing to homepage (passing equity):', homeLinks.filter(t => t.toLowerCase().includes('solar')));

// Target keywords for areas.html
console.log('\n--- TARGET AREA KEYWORDS ---');
const targetKws = [
  'solar panel installation service areas',
  'service areas in pune',
  'service areas',
  'rooftop solar',
  'pune & pcmc',
  'pcmc',
  'chakan',
  'bhosari',
  'baner',
  'hinjewadi',
  'wakad',
  'kharadi',
  'kothrud',
  'hadapsar',
  'lonavala',
  'kiwale',
  'msedcl'
];

targetKws.forEach(kw => {
  const count = (html.match(new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi')) || []).length;
  console.log(`  "${kw}": ${count}`);
});

// Non-clean URLs check
const htmlLinks = [...html.matchAll(/href=["']([^"']+\.html)["']/gi)].map(m => m[1]);
console.log('\nNon-clean .html links:', htmlLinks.length === 0 ? '✓ 0 found (Clean routing)' : htmlLinks);

// Word count
const text = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                 .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
                 .replace(/<[^>]+>/g, ' ')
                 .replace(/\s+/g, ' ')
                 .trim();
const words = text.split(/\s+/).length;
console.log('\nTotal visible words:', words, words >= 1000 ? '✓ (STRONG TOPICAL DEPTH)' : '⚠ (THIN)');
