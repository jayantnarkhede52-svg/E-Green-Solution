const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const blogDir = path.join(rootDir, 'blog');

// Exact metadata map from pages 9 & 10 of the Audit PDF
const metadataMap = {
  'index.html': {
    title: 'Solar Panel Dealers Pune | Rooftop Solar - E Green Solution',
    h1: 'Solar Panel Dealers in Pune <br><span>&amp; Rooftop Solar Engineering</span>',
    description: 'Looking for solar panel dealers in Pune? E Green Solution supplies and installs rooftop solar for homes, societies and businesses with end-to-end MSEDCL support.'
  },
  'solar-panel-pune.html': {
    title: 'Solar Panel Installation Pune | Rooftop Solar - E Green Solution',
    h1: 'Solar Panel Installation in Pune',
    description: 'Get rooftop solar panel installation in Pune with site survey, system design, MSEDCL net-metering support and residential or commercial options.'
  },
  'services.html': {
    title: 'Solar Services Pune | EPC, AMC & Repair - E Green Solution',
    h1: 'Solar Services in Pune',
    description: 'Comprehensive solar services in Pune including residential rooftop installations, commercial & industrial EPC, solar AMC, inverter repair, and panel cleaning.'
  },
  'residential-solar.html': {
    title: 'Solar Panels for Home Pune | Residential Rooftop Solar',
    h1: 'Solar Panels for Home in Pune',
    description: 'Install rooftop solar for your Pune home or housing society. Compare 3kW, 5kW and larger systems, subsidy support, savings and installation process.'
  },
  'commercial-solar-pune.html': {
    title: 'Commercial Solar Installation Pune | E Green Solution',
    h1: 'Commercial Solar Installation in Pune',
    description: 'Commercial solar installation in Pune for offices, hospitals, hotels, malls and institutions. Get a site assessment, savings estimate and EPC proposal.'
  },
  'industrial-solar.html': {
    title: 'Industrial Solar Installation Pune | Factory Solar EPC',
    h1: 'Industrial Solar Installation & EPC in Pune',
    description: 'Industrial solar EPC in Pune for factories, warehouses and MIDC units. System design, engineering, compliance support, monitoring and maintenance.'
  },
  'solar-subsidy.html': {
    title: 'Solar Subsidy Pune 2026 | PM Surya Ghar Guide',
    h1: 'Solar Subsidy in Pune - PM Surya Ghar Guide',
    description: 'Understand PM Surya Ghar solar subsidy in Pune, current residential subsidy slabs, eligibility, MSEDCL steps and the application process.'
  },
  'calculator.html': {
    title: 'Solar Calculator Pune | Savings, ROI & System Size',
    h1: 'Solar Savings & ROI Calculator',
    description: 'Estimate your rooftop solar generation, monthly electricity bill savings, government subsidy, and payback period with our Pune solar calculator.'
  },
  'projects.html': {
    title: 'Solar Projects Pune | Rooftop & Industrial Case Studies',
    h1: 'Solar Projects & Case Studies in Pune',
    description: 'Explore E Green Solution solar projects in Pune and Maharashtra, including residential, commercial and industrial rooftop installations and case studies.'
  },
  'areas.html': {
    title: 'Solar Installation Service Areas Pune & PCMC',
    h1: 'Solar Installation Service Areas in Pune & PCMC',
    description: 'Explore E Green Solution rooftop solar installation service areas across Pune, PCMC, Chakan, Bhosari, Baner, Wakad, and Maharashtra.'
  },
  'solar-panel-cleaning-pune.html': {
    title: 'Solar Panel Cleaning Pune | Rooftop & Industrial Service',
    h1: 'Solar Panel Cleaning Services in Pune',
    description: 'Professional solar panel cleaning in Pune for homes, societies and industrial plants using safe low-TDS water and generation checks.'
  },
  'solar-amc-pune.html': {
    title: 'Solar AMC Pune | Annual Solar Maintenance Contracts',
    h1: 'Solar AMC Contractors in Pune',
    description: 'Solar AMC in Pune with preventive inspections, electrical checks, cleaning options and breakdown support for residential, commercial and industrial plants.'
  },
  'solar-repair-maintenance-pune.html': {
    title: 'Solar Panel Repair Pune | Plant Maintenance & Fault Service',
    h1: 'Solar Panel Repair & Maintenance in Pune',
    description: 'Prompt on-site solar panel and system repair services in Pune. Fault detection, wiring restoration, junction box replacement, and generation troubleshooting.'
  },
  'solar-inverter-repair-pune.html': {
    title: 'Solar Inverter Repair Pune | Growatt, Sungrow, Solis & More',
    h1: 'Solar Inverter Repair in Pune',
    description: 'Expert solar inverter repair and troubleshooting in Pune for Growatt, Solis, Sungrow, Fronius, Havells, and Polycab grid-tie and hybrid inverters.'
  },
  'solar-net-meter-msedcl-pune.html': {
    title: 'MSEDCL Solar Net Meter Pune | Testing & Replacement',
    h1: 'MSEDCL Solar Net Meter Testing & Replacement',
    description: 'Fast-track MSEDCL solar net meter testing, sanctioned load replacement, and billing issue resolution in Pune and PCMC.'
  },
  'solar-plant-revamping-repowering.html': {
    title: 'Solar Plant Repowering Maharashtra | Revamping & Upgrade',
    h1: 'Solar Plant Revamping & Repowering',
    description: 'Revamping and repowering older solar power plants across Maharashtra. Upgrade degraded panels with high-efficiency TOPCon/Bifacial modules and modern inverters.'
  },
  'solar-panel-chakan.html': {
    title: 'Solar Panel Installation Chakan MIDC | Factory Solar EPC',
    h1: 'Solar Panel Installation in Chakan MIDC',
    description: 'Industrial rooftop solar panel installation in Chakan MIDC. Turnkey factory solar EPC, CEIG approvals, and 40% depreciation benefits.'
  },
  'solar-panel-pimpri-chinchwad.html': {
    title: 'Solar Panel Installation Pimpri Chinchwad | PCMC',
    h1: 'Solar Panel Installation in Pimpri Chinchwad',
    description: 'Top rooftop solar panel installation in Pimpri Chinchwad (PCMC) for homes, societies, and commercial businesses with MSEDCL net metering.'
  },
  'solar-panel-baner-bavdhan.html': {
    title: 'Solar Panel Installation Baner & Bavdhan | Pune',
    h1: 'Solar Panel Installation in Baner & Bavdhan',
    description: 'Rooftop solar installation for villas, penthouses and societies in Baner & Bavdhan. Elevated solar structures and PM Surya Ghar subsidy support.'
  },
  'solar-panel-bhosari-pcmc.html': {
    title: 'Industrial Solar Bhosari MIDC | Factory Rooftop EPC',
    h1: 'Industrial Solar Installation in Bhosari MIDC',
    description: 'Turnkey industrial rooftop solar installation in Bhosari MIDC and PCMC industrial area. Non-penetrative clamp mounting for factories and workshops.'
  },
  'solar-panel-kiwale.html': {
    title: 'Solar Panel Installation Kiwale & Ravet | Pune',
    h1: 'Solar Panel Installation in Kiwale & Ravet',
    description: 'Residential rooftop solar installation in Kiwale, Ravet and Mamurdi. High-efficiency mono PERC panels with PM Surya Ghar subsidy assistance.'
  },
  'solar-panel-lonavala.html': {
    title: 'Solar Panel Installation Lonavala | Villas, Resorts & Hybrid',
    h1: 'Solar Panel Installation in Lonavala & Khandala',
    description: 'Hybrid rooftop solar system installation with battery backup for luxury villas, second homes, and resorts in Lonavala and Khandala.'
  },
  'solar-water-heater-pune.html': {
    title: 'Solar Water Heater Pune | ETC & FPC Installation & Dealers',
    h1: 'Solar Water Heater Dealers & Installation in Pune',
    description: 'Energy-efficient solar water heater installation in Pune for homes, apartments, hostels and hotels. ETC and FPC systems with high-density PUF insulation.'
  }
};

// 1. Read index.html and update it
let indexContent = fs.readFileSync(path.join(rootDir, 'index.html'), 'utf8');

// Title & Meta Description in index.html
indexContent = indexContent.replace(/<title>[\s\S]*?<\/title>/i, `<title>${metadataMap['index.html'].title}</title>`);
indexContent = indexContent.replace(/<meta\s+name=["']description["']\s+content=["'][\s\S]*?["']/i, `<meta name="description" content="${metadataMap['index.html'].description}"`);

// H1 in index.html
indexContent = indexContent.replace(/<h1 class=["']hero-title["']>[\s\S]*?<\/h1>/i, `<h1 class="hero-title">${metadataMap['index.html'].h1}</h1>`);

// Hero intro in index.html - clean up keyword repetition
indexContent = indexContent.replace(
  /<p class=["']hero-desc["']>[\s\S]*?<\/p>/i,
  `<p class="hero-desc">Welcome to E Green Solution — trusted <strong>solar panel dealers in Pune</strong> delivering high-efficiency rooftop solar systems for homes, housing societies, and businesses. As authorized Tier-1 solar dealers (550W–600W mono PERC &amp; TOPCon modules), we empower 200+ homes and MIDC enterprises with PM Surya Ghar subsidy support, seamless MSEDCL net metering, and comprehensive long-term warranties.</p>`
);

// Standardize Navbar dropdown in index.html
// 1) Point Commercial Solar to /commercial-solar-pune
// 2) Add Solar Water Heaters to dropdown and mobile menu
const oldCommercialDropdownItem = `<a href="/industrial-solar" class="dropdown-item">
                                    <div class="item-icon amber"><i class="fas fa-building"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Commercial Solar</span>
                                        <span class="item-desc">Offices, Hospitals &amp; Malls</span>
                                    </div>
                                </a>`;

const newCommercialDropdownItem = `<a href="/commercial-solar-pune" class="dropdown-item">
                                    <div class="item-icon amber"><i class="fas fa-building"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Commercial Solar</span>
                                        <span class="item-desc">Offices, Hospitals &amp; Malls</span>
                                    </div>
                                </a>`;

const waterHeaterDropdownItem = `
                                <a href="/solar-water-heater-pune" class="dropdown-item">
                                    <div class="item-icon red"><i class="fas fa-water"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Solar Water Heaters</span>
                                        <span class="item-desc">ETC &amp; FPC Water Heating</span>
                                    </div>
                                </a>`;

if (indexContent.includes('/industrial-solar" class="dropdown-item">\n                                    <div class="item-icon amber">')) {
  indexContent = indexContent.replace(
    '/industrial-solar" class="dropdown-item">\n                                    <div class="item-icon amber">',
    '/commercial-solar-pune" class="dropdown-item">\n                                    <div class="item-icon amber">'
  );
}

// Add water heater dropdown item if not present
if (!indexContent.includes('/solar-water-heater-pune')) {
  indexContent = indexContent.replace(
    '<a href="/solar-subsidy" class="dropdown-item">',
    waterHeaterDropdownItem + '\n                                <a href="/solar-subsidy" class="dropdown-item">'
  );
}

// Update Mobile menu for commercial & water heater
if (indexContent.includes('<li><a href="/industrial-solar"><i class="fas fa-building" style="color: #f57f17;"></i> <span>Commercial Solar Plants</span></a></li>')) {
  indexContent = indexContent.replace(
    '<li><a href="/industrial-solar"><i class="fas fa-building" style="color: #f57f17;"></i> <span>Commercial Solar Plants</span></a></li>',
    '<li><a href="/commercial-solar-pune"><i class="fas fa-building" style="color: #f57f17;"></i> <span>Commercial Solar</span></a></li>\n                        <li><a href="/solar-water-heater-pune"><i class="fas fa-water" style="color: #d32f2f;"></i> <span>Solar Water Heaters</span></a></li>'
  );
}

// Update Footer description in index.html (remove boilerplate)
const oldFooterSentenceRegex = /<p style=["']opacity:\s*0\.8;\s*line-height:\s*1\.8;\s*margin-bottom:\s*25px;\s*font-size:\s*15px;["']>[\s\S]*?<\/p>/i;
const newFooterParagraph = `<p style="opacity: 0.8; line-height: 1.8; margin-bottom: 25px; font-size: 15px;">E Green Solution is a trusted rooftop solar engineering and EPC company based in Pune, delivering high-performance residential, commercial, and industrial solar power systems with end-to-end MSEDCL net metering and maintenance support.</p>`;

indexContent = indexContent.replace(oldFooterSentenceRegex, newFooterParagraph);

// Update Footer Solar Services column in index.html
const oldFooterServicesRegex = /<div class=["']footer-col["']>\s*<h3>Solar Services<\/h3>[\s\S]*?<\/ul>\s*<\/div>/i;
const newFooterServices = `<div class="footer-col">
                <h3>Solar Services</h3>
                <ul class="area-tags">
                    <li><a href="/residential-solar"><i class="fas fa-home"></i> Residential Solar</a></li>
                    <li><a href="/commercial-solar-pune"><i class="fas fa-building"></i> Commercial Solar</a></li>
                    <li><a href="/industrial-solar"><i class="fas fa-industry"></i> Industrial Solar EPC</a></li>
                    <li><a href="/solar-water-heater-pune"><i class="fas fa-water"></i> Solar Water Heaters</a></li>
                    <li><a href="/solar-subsidy"><i class="fas fa-file-invoice-dollar"></i> PM Surya Ghar</a></li>
                    <li><a href="/solar-panel-cleaning-pune"><i class="fas fa-broom"></i> Panel Cleaning</a></li>
                    <li><a href="/solar-amc-pune"><i class="fas fa-shield-alt"></i> Solar AMC Plans</a></li>
                    <li><a href="/solar-inverter-repair-pune"><i class="fas fa-microchip"></i> Inverter Repair</a></li>
                    <li><a href="/solar-net-meter-msedcl-pune"><i class="fas fa-bolt"></i> Net Meter Testing</a></li>
                    <li><a href="/solar-plant-revamping-repowering"><i class="fas fa-sync-alt"></i> Plant Repowering</a></li>
                </ul>
            </div>`;

indexContent = indexContent.replace(oldFooterServicesRegex, newFooterServices);

// Save updated index.html
fs.writeFileSync(path.join(rootDir, 'index.html'), indexContent, 'utf8');
console.log('Updated index.html with new H1, Title, Meta Description, Navbar & Footer!');

// Extract standardized navbar and footer blocks from index.html for replication
const navRegex = /<nav\s+id=["']navbar["'][\s\S]*?<\/nav>/i;
const navMatch = indexContent.match(navRegex);
const subpageNav = navMatch[0].replace('<nav id="navbar"', '<nav id="navbar" class="scrolled"');

const footerRegex = /<footer\s+class=["']section-padding\s+bg-primary-gradient["'][\s\S]*?<\/nav>/i;
const footerMatch = indexContent.match(footerRegex);
const standardFooterBlock = footerMatch[0];

// Target files to update
const rootFiles = fs.readdirSync(rootDir).filter(f => f.endsWith('.html') && f !== 'index.html' && f !== 'solar-hero.html').map(f => path.join(rootDir, f));
const blogFiles = fs.existsSync(blogDir) ? fs.readdirSync(blogDir).filter(f => f.endsWith('.html')).map(f => path.join(blogDir, f)) : [];
const projectFiles = fs.existsSync(path.join(rootDir, 'projects')) ? fs.readdirSync(path.join(rootDir, 'projects')).filter(f => f.endsWith('.html')).map(f => path.join(rootDir, 'projects', f)) : [];

const allFiles = [...rootFiles, ...blogFiles, ...projectFiles];

console.log(`Processing ${allFiles.length} subpages...`);

for (const filePath of allFiles) {
  const filename = path.basename(filePath);
  let content = fs.readFileSync(filePath, 'utf8');

  // 1. Standardize 1,500+ proof numbers
  content = content.replace(/1,500\+\s*commissioned\s*rooftops/gi, '200+ commissioned rooftops');
  content = content.replace(/1,500\+\s*successful\s*installations/gi, '200+ successful installations');
  content = content.replace(/1,500\+\s*commissioned\s*installations/gi, '200+ commissioned installations');

  // 2. Standardize Navigation
  if (/<header class=["']header["']>[\s\S]*?<\/header>/i.test(content)) {
    content = content.replace(/<header class=["']header["']>[\s\S]*?<\/header>/i, subpageNav);
  } else if (/<nav\s+id=["']navbar["'][\s\S]*?<\/nav>/i.test(content)) {
    content = content.replace(/<nav\s+id=["']navbar["'][\s\S]*?<\/nav>/i, subpageNav);
  }

  // 3. Standardize Footer + Floating Buttons + Mobile Bottom Nav
  const footerStartIdx = content.indexOf('<footer');
  if (footerStartIdx !== -1) {
    const scriptMatch = content.slice(footerStartIdx).match(/<script/i);
    if (scriptMatch) {
      const footerEndIdx = footerStartIdx + scriptMatch.index;
      content = content.slice(0, footerStartIdx) + standardFooterBlock + '\n\n    ' + content.slice(footerEndIdx);
    }
  }

  // 4. Enforce Metadata (Title, H1, Meta Description) if defined in map
  if (metadataMap[filename]) {
    const meta = metadataMap[filename];
    
    // Title
    content = content.replace(/<title>[\s\S]*?<\/title>/i, `<title>${meta.title}</title>`);

    // Description
    if (/<meta\s+name=["']description["']/i.test(content)) {
      content = content.replace(/<meta\s+name=["']description["']\s+content=["'][\s\S]*?["']/i, `<meta name="description" content="${meta.description}"`);
    }

    // H1
    if (/<h1[^>]*>[\s\S]*?<\/h1>/i.test(content)) {
      content = content.replace(/<h1([^>]*)>[\s\S]*?<\/h1>/i, `<h1$1>${meta.h1}</h1>`);
    }
  }

  // Save changes
  fs.writeFileSync(filePath, content, 'utf8');
}

console.log('All files successfully updated with standardized navbar, footer, metadata, and proof numbers!');
