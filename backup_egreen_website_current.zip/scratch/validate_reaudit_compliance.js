const http = require('http');
const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');

// 1. Read sitemap.xml
const sitemapXml = fs.readFileSync(path.join(rootDir, 'sitemap.xml'), 'utf8');
const urlMatches = [...sitemapXml.matchAll(/<loc>https:\/\/egreensolution\.in([^<]*)<\/loc>/g)];
const paths = urlMatches.map(m => m[1] === '' ? '/' : m[1]);

console.log(`Starting Validation of ${paths.length} Sitemap URLs on http://localhost:3000...\n`);

function fetchUrl(pathname) {
  return new Promise((resolve) => {
    http.get('http://localhost:3000' + pathname, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({ path: pathname, status: res.statusCode, body: data });
      });
    }).on('error', (err) => {
      resolve({ path: pathname, status: 500, error: err.message });
    });
  });
}

async function runValidation() {
  const titles = new Map();
  const h1s = new Map();
  let errors = 0;

  for (const p of paths) {
    const res = await fetchUrl(p);
    if (res.status !== 200) {
      console.error(`❌ HTTP Error: ${p} returned ${res.status}`);
      errors++;
      continue;
    }

    const html = res.body;

    // Check Title
    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].trim() : 'MISSING';
    if (titles.has(title)) {
      console.warn(`⚠️ Duplicate Title found: "${title}" on ${p} and ${titles.get(title)}`);
      errors++;
    } else {
      titles.set(title, p);
    }

    // Check H1
    const h1Match = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    const h1 = h1Match ? h1Match[1].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim() : 'MISSING';
    if (h1 === 'MISSING') {
      console.error(`❌ Missing H1 on ${p}`);
      errors++;
    } else if (h1s.has(h1)) {
      console.warn(`⚠️ Duplicate H1 found: "${h1}" on ${p} and ${h1s.get(h1)}`);
      errors++;
    } else {
      h1s.set(h1, p);
    }

    // Check IEC 61215 claim
    if (html.includes('IEC 61215')) {
      console.error(`❌ Prohibited IEC 61215 claim found on ${p}`);
      errors++;
    }

    // Check 1500+ claim
    if (/1,500\+\s*(commissioned|successful)/i.test(html)) {
      console.error(`❌ Discrepant 1,500+ installations claim found on ${p}`);
      errors++;
    }

    // Check Canonical
    const canonicalMatch = html.match(/<link\s+rel=["']canonical["']\s+href=["']([^"']+)["']/i);
    if (!canonicalMatch) {
      console.warn(`⚠️ Missing canonical on ${p}`);
      errors++;
    }
  }

  console.log(`\n=== VALIDATION SUMMARY ===`);
  console.log(`Total URLs Audited: ${paths.length}`);
  console.log(`Total Unique Titles: ${titles.size}`);
  console.log(`Total Unique H1s: ${h1s.size}`);
  console.log(`Total Errors/Warnings: ${errors}`);

  if (errors === 0) {
    console.log(`\n🎉 PERFECT SCORE! All pages passed Definition of Done with 0 errors!`);
  } else {
    process.exit(1);
  }
}

runValidation();
