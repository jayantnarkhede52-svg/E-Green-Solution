const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const blogDir = path.join(rootDir, 'blog');

const files = fs.readdirSync(rootDir).filter(f => f.endsWith('.html') && f !== 'solar-hero.html').map(f => path.join(rootDir, f));
const blogFiles = fs.readdirSync(blogDir).filter(f => f.endsWith('.html')).map(f => path.join(blogDir, f));

const allFiles = [...files, ...blogFiles];

const desktopDropdownHtml = `                <li class="nav-item-dropdown">
                    <a href="/services" class="dropdown-trigger">Services <i class="fas fa-chevron-down nav-arrow"></i></a>
                    <div class="nav-dropdown-menu">
                        <div class="dropdown-inner">
                            <div class="dropdown-col">
                                <span class="dropdown-heading"><i class="fas fa-solar-panel"></i> Solar Installations</span>
                                <a href="/residential-solar" class="dropdown-item">
                                    <div class="item-icon green"><i class="fas fa-home"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Residential Solar</span>
                                        <span class="item-desc">Rooftops &amp; Housing Societies</span>
                                    </div>
                                </a>
                                <a href="/industrial-solar" class="dropdown-item">
                                    <div class="item-icon amber"><i class="fas fa-building"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Commercial Solar</span>
                                        <span class="item-desc">Offices, Hospitals &amp; Malls</span>
                                    </div>
                                </a>
                                <a href="/industrial-solar" class="dropdown-item">
                                    <div class="item-icon blue"><i class="fas fa-industry"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Industrial Solar EPC</span>
                                        <span class="item-desc">MIDC Chakan, Bhosari &amp; Talegaon</span>
                                    </div>
                                </a>
                                <a href="/solar-subsidy" class="dropdown-item">
                                    <div class="item-icon gold"><i class="fas fa-file-invoice-dollar"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">PM Surya Ghar Subsidy</span>
                                        <span class="item-desc">Save up to ₹78,000 Direct Credit</span>
                                    </div>
                                </a>
                            </div>
                            <div class="dropdown-col">
                                <span class="dropdown-heading"><i class="fas fa-tools"></i> Plant Care &amp; Maintenance</span>
                                <a href="/solar-panel-cleaning-pune" class="dropdown-item">
                                    <div class="item-icon teal"><i class="fas fa-broom"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Solar Panel Cleaning</span>
                                        <span class="item-desc">RO Water Wash (+25% Yield)</span>
                                    </div>
                                </a>
                                <a href="/solar-amc-pune" class="dropdown-item">
                                    <div class="item-icon emerald"><i class="fas fa-file-contract"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Solar AMC Contracts</span>
                                        <span class="item-desc">Quarterly Audits &amp; Rapid SLA</span>
                                    </div>
                                </a>
                                <a href="/solar-repair-maintenance-pune" class="dropdown-item">
                                    <div class="item-icon red"><i class="fas fa-wrench"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Maintenance &amp; Repair</span>
                                        <span class="item-desc">Breakdown Fixes &amp; Fault Testing</span>
                                    </div>
                                </a>
                                <a href="/solar-inverter-repair-pune" class="dropdown-item">
                                    <div class="item-icon orange"><i class="fas fa-bolt"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Solar Inverter Repair</span>
                                        <span class="item-desc">Growatt, Sungrow, Solis, Fronius</span>
                                    </div>
                                </a>
                                <a href="/solar-net-meter-msedcl-pune" class="dropdown-item">
                                    <div class="item-icon purple"><i class="fas fa-tachometer-alt"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Net Meter Testing</span>
                                        <span class="item-desc">MSEDCL Replacement &amp; Credit Sync</span>
                                    </div>
                                </a>
                                <a href="/solar-plant-revamping-repowering" class="dropdown-item">
                                    <div class="item-icon cyan"><i class="fas fa-sync-alt"></i></div>
                                    <div class="item-text">
                                        <span class="item-title">Revamping &amp; Repowering</span>
                                        <span class="item-desc">Double Yield on Existing Sheds</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="dropdown-footer-link">
                            <span>Explore our complete range of turnkey engineering solutions</span>
                            <a href="/services">View All Solar Services &rarr;</a>
                        </div>
                    </div>
                </li>`;

const mobileDropdownHtml = `                <li class="mobile-dropdown-item">
                    <div class="mobile-dropdown-header">
                        <a href="/services" class="mobile-dropdown-link">Services</a>
                        <button type="button" class="mobile-dropdown-toggle" aria-label="Toggle Services Menu">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <ul class="mobile-submenu">
                        <li><a href="/residential-solar"><i class="fas fa-home" style="color: #2e7d32;"></i> <span>Residential Rooftop Solar</span></a></li>
                        <li><a href="/industrial-solar"><i class="fas fa-building" style="color: #f57f17;"></i> <span>Commercial Solar Plants</span></a></li>
                        <li><a href="/industrial-solar"><i class="fas fa-industry" style="color: #0288d1;"></i> <span>Industrial Solar EPC (MIDC)</span></a></li>
                        <li><a href="/solar-subsidy"><i class="fas fa-file-invoice-dollar" style="color: #b78103;"></i> <span>PM Surya Ghar Subsidy</span></a></li>
                        <li><a href="/solar-panel-cleaning-pune"><i class="fas fa-broom" style="color: #00897b;"></i> <span>Solar Panel Cleaning</span></a></li>
                        <li><a href="/solar-amc-pune"><i class="fas fa-file-contract" style="color: #1b5e20;"></i> <span>Solar AMC Contracts</span></a></li>
                        <li><a href="/solar-repair-maintenance-pune"><i class="fas fa-wrench" style="color: #c62828;"></i> <span>Plant Maintenance &amp; Repair</span></a></li>
                        <li><a href="/solar-inverter-repair-pune"><i class="fas fa-bolt" style="color: #e65100;"></i> <span>Solar Inverter Repair</span></a></li>
                        <li><a href="/solar-net-meter-msedcl-pune"><i class="fas fa-tachometer-alt" style="color: #6a1b9a;"></i> <span>Net Meter Testing</span></a></li>
                        <li><a href="/solar-plant-revamping-repowering"><i class="fas fa-sync-alt" style="color: #00796b;"></i> <span>Plant Revamping &amp; Repowering</span></a></li>
                        <li class="mobile-submenu-all"><a href="/services"><i class="fas fa-th-large"></i> <span>All Services Overview &rarr;</span></a></li>
                    </ul>
                </li>`;

let updatedCount = 0;

for (const filePath of allFiles) {
    let content = fs.readFileSync(filePath, 'utf8');
    const original = content;

    // 1. In desktop nav: replace <li><a href="/services"...>Services</a></li> inside .nav-links or .nav-menu
    // Note: Do not touch Quick Links in footer!
    content = content.replace(/(<ul[^>]*class=["'](?:nav-links|nav-menu)["'][^>]*>[\s\S]*?)<li><a\s+href="\/services"[^>]*>Services<\/a><\/li>/i, (match, p1) => {
        return `${p1}${desktopDropdownHtml}`;
    });

    // Also handle blog files where desktop is <nav class="nav-menu">\s*<ul>
    content = content.replace(/(<nav[^>]*class=["']nav-menu["'][^>]*>\s*<ul>[\s\S]*?)<li><a\s+href="\/services"[^>]*>Services<\/a><\/li>/i, (match, p1) => {
        return `${p1}${desktopDropdownHtml}`;
    });

    // 2. In mobile nav: replace <li><a href="/services"...>Services</a></li> inside .mobile-nav-links
    content = content.replace(/(<ul[^>]*class=["']mobile-nav-links["'][^>]*>[\s\S]*?)<li><a\s+href="\/services"[^>]*>Services<\/a><\/li>/i, (match, p1) => {
        return `${p1}${mobileDropdownHtml}`;
    });

    if (content !== original) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Updated navbar in: ${path.relative(rootDir, filePath)}`);
        updatedCount++;
    } else {
        console.log(`No navbar change in: ${path.relative(rootDir, filePath)}`);
    }
}

console.log(`\nTotal files with updated navbar: ${updatedCount}`);
