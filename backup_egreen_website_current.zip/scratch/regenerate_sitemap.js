const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');

const coreUrls = [
  { loc: 'https://egreensolution.in/', priority: '1.0', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-panel-pune', priority: '0.95', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/services', priority: '0.9', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/residential-solar', priority: '0.9', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/commercial-solar-pune', priority: '0.9', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/industrial-solar', priority: '0.9', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-water-heater-pune', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-subsidy', priority: '0.9', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/calculator', priority: '0.85', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/projects', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/projects/eagle-burgmann-200kw-solar-pune', priority: '0.85', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/areas', priority: '0.9', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/about', priority: '0.8', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/contact', priority: '0.85', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/solar-guide', priority: '0.8', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/privacy-policy', priority: '0.3', changefreq: 'yearly' },

  // After-sales & Maintenance services
  { loc: 'https://egreensolution.in/solar-panel-cleaning-pune', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-amc-pune', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-repair-maintenance-pune', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-inverter-repair-pune', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-net-meter-msedcl-pune', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-plant-revamping-repowering', priority: '0.85', changefreq: 'weekly' },

  // Location Hubs
  { loc: 'https://egreensolution.in/solar-panel-chakan', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-panel-pimpri-chinchwad', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-panel-baner-bavdhan', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-panel-bhosari-pcmc', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-panel-kiwale', priority: '0.85', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/solar-panel-lonavala', priority: '0.85', changefreq: 'weekly' },

  // Blog Informational cluster
  { loc: 'https://egreensolution.in/blog', priority: '0.8', changefreq: 'weekly' },
  { loc: 'https://egreensolution.in/blog/bifacial-solar-panels-pune', priority: '0.75', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/blog/mono-perc-vs-topcon-solar-pune', priority: '0.75', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/blog/dcr-solar-panels-pune', priority: '0.75', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/blog/hybrid-solar-system-lithium-battery-pune', priority: '0.75', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/blog/enphase-microinverter-installers-pune', priority: '0.75', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/blog/on-grid-solar-inverter-dealers-pune', priority: '0.75', changefreq: 'monthly' },
  { loc: 'https://egreensolution.in/blog/elevated-rooftop-solar-structure-pune', priority: '0.75', changefreq: 'monthly' }
];

let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;

for (const entry of coreUrls) {
  xml += `  <url>\n    <loc>${entry.loc}</loc>\n    <lastmod>2026-09-29</lastmod>\n    <changefreq>${entry.changefreq}</changefreq>\n    <priority>${entry.priority}</priority>\n  </url>\n`;
}

xml += `</urlset>\n`;

fs.writeFileSync(path.join(rootDir, 'sitemap.xml'), xml, 'utf8');
console.log(`Generated sitemap.xml with ${coreUrls.length} clean, validated URLs!`);
