const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const cssPath = path.join(rootDir, 'css', 'style.css');
const jsPath = path.join(rootDir, 'js', 'main.js');
const servicesHtmlPath = path.join(rootDir, 'services.html');

// 1. Update CSS
console.log('=== 1. Updating css/style.css ===');
let css = fs.readFileSync(cssPath, 'utf8');

const navDropdownCss = `
/* === SERVICES MEGA DROPDOWN (Desktop) === */
.nav-links {
    display: flex;
    gap: 20px;
    align-items: center;
    list-style: none;
}

@media (min-width: 1400px) {
    .nav-links {
        gap: 28px;
    }
}

.nav-links a {
    text-decoration: none;
    color: rgba(255, 255, 255, 0.93);
    font-weight: 600;
    font-size: 15px;
    transition: 0.25s;
    letter-spacing: 0.2px;
    white-space: nowrap;
}

.nav-item-dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-trigger {
    display: inline-flex !important;
    align-items: center;
    gap: 6px;
    cursor: pointer;
}

.nav-arrow {
    font-size: 11px;
    transition: transform 0.25s ease;
    opacity: 0.8;
}

.nav-item-dropdown:hover .nav-arrow,
.nav-item-dropdown.open .nav-arrow {
    transform: rotate(180deg);
}

.nav-dropdown-menu {
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%) translateY(14px);
    width: 630px;
    background: #ffffff;
    border-radius: 20px;
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.16), 0 4px 15px rgba(0, 0, 0, 0.05);
    padding: 22px 24px 18px;
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    transition: all 0.25s cubic-bezier(0.165, 0.84, 0.44, 1);
    z-index: 10001;
    border-top: 3px solid var(--primary);
    border-left: 1px solid rgba(0,0,0,0.06);
    border-right: 1px solid rgba(0,0,0,0.06);
    border-bottom: 1px solid rgba(0,0,0,0.08);
}

.nav-item-dropdown::after {
    content: '';
    position: absolute;
    top: 100%;
    left: -15px;
    right: -15px;
    height: 18px;
    display: block;
}

.nav-item-dropdown:hover .nav-dropdown-menu,
.nav-item-dropdown:focus-within .nav-dropdown-menu,
.nav-item-dropdown.open .nav-dropdown-menu {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
    transform: translateX(-50%) translateY(4px);
}

.dropdown-inner {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.dropdown-col {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.dropdown-heading {
    font-size: 11.5px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #64748b;
    margin-bottom: 8px;
    padding-bottom: 6px;
    border-bottom: 1.5px solid #f1f5f9;
    display: flex;
    align-items: center;
    gap: 7px;
}

.dropdown-heading i {
    color: var(--primary);
    font-size: 13px;
}

.dropdown-item {
    display: flex !important;
    align-items: center;
    gap: 12px;
    padding: 8px 10px !important;
    border-radius: 12px;
    text-decoration: none;
    transition: all 0.2s ease !important;
    background: transparent;
}

.dropdown-item:hover {
    background: #f0fdf4 !important;
    transform: translateX(4px);
}

.dropdown-item .item-icon {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 15px;
    flex-shrink: 0;
    transition: transform 0.2s ease;
}

.dropdown-item:hover .item-icon {
    transform: scale(1.1);
}

.dropdown-item .item-icon.green   { background: #e8f5e9; color: #2e7d32; }
.dropdown-item .item-icon.amber   { background: #fff8e1; color: #f57f17; }
.dropdown-item .item-icon.blue    { background: #e1f5fe; color: #0288d1; }
.dropdown-item .item-icon.gold    { background: #fef3c7; color: #b45309; }
.dropdown-item .item-icon.teal    { background: #e0f2f1; color: #00796b; }
.dropdown-item .item-icon.emerald { background: #e8f5e9; color: #1b5e20; }
.dropdown-item .item-icon.red     { background: #ffebee; color: #c62828; }
.dropdown-item .item-icon.orange  { background: #fff3e0; color: #e65100; }
.dropdown-item .item-icon.purple  { background: #f3e5f5; color: #6a1b9a; }
.dropdown-item .item-icon.cyan    { background: #e0f7fa; color: #00838f; }

.dropdown-item .item-text {
    display: flex;
    flex-direction: column;
    text-align: left;
}

.dropdown-item .item-title {
    font-size: 14px;
    font-weight: 700;
    color: #1e293b !important;
    line-height: 1.25;
}

.dropdown-item:hover .item-title {
    color: var(--primary) !important;
}

.dropdown-item .item-desc {
    font-size: 11px;
    color: #64748b !important;
    line-height: 1.2;
    margin-top: 2px;
}

.dropdown-footer-link {
    margin-top: 14px;
    padding-top: 12px;
    border-top: 1px solid #f1f5f9;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12.5px;
    color: #64748b;
}

.dropdown-footer-link a {
    color: var(--primary) !important;
    font-weight: 700 !important;
    font-size: 13.5px !important;
    text-decoration: none;
    padding: 4px 10px !important;
    border-radius: 8px;
    transition: background 0.2s;
}

.dropdown-footer-link a:hover {
    background: #f0fdf4 !important;
    text-decoration: none !important;
}

/* === ENHANCED MOBILE DRAWER & ACCORDION === */
.mobile-menu {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    height: 100dvh;
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    z-index: 10005;
    display: none;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    padding: 70px 20px 40px;
}

.mobile-menu.active {
    display: flex;
}

.mobile-nav-links {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 4px;
    width: 100%;
    max-width: 380px;
    padding: 0;
}

.mobile-nav-links > li > a {
    color: var(--text-dark);
    text-decoration: none;
    font-size: 17px;
    font-weight: 600;
    display: block;
    padding: 11px 16px;
    border-radius: 12px;
    text-align: left;
    transition: all 0.2s ease;
    -webkit-tap-highlight-color: transparent;
}

.mobile-nav-links > li > a:hover,
.mobile-nav-links > li > a:active {
    background: #f1f5f9;
    color: var(--primary);
}

.mobile-dropdown-item {
    width: 100%;
    border-radius: 12px;
    transition: background 0.2s ease;
}

.mobile-dropdown-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    border-radius: 12px;
    padding: 0 4px;
}

.mobile-dropdown-header a {
    color: var(--text-dark);
    text-decoration: none;
    font-size: 17px;
    font-weight: 600;
    padding: 11px 12px;
    flex-grow: 1;
    text-align: left;
}

.mobile-dropdown-toggle {
    background: none;
    border: none;
    font-size: 16px;
    color: #64748b;
    padding: 10px 14px;
    cursor: pointer;
    border-radius: 8px;
    transition: transform 0.25s ease, background 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.mobile-dropdown-toggle:active {
    background: #e2e8f0;
}

.mobile-dropdown-item.open .mobile-dropdown-toggle {
    transform: rotate(180deg);
    color: var(--primary);
}

.mobile-submenu {
    list-style: none;
    display: none;
    flex-direction: column;
    gap: 4px;
    background: #f8fafc;
    border-radius: 14px;
    padding: 8px 10px;
    margin: 4px 6px 12px;
    border: 1px solid #e2e8f0;
}

.mobile-dropdown-item.open .mobile-submenu {
    display: flex;
}

.mobile-submenu li a {
    font-size: 14.5px !important;
    font-weight: 600 !important;
    padding: 9px 12px !important;
    display: flex !important;
    align-items: center;
    gap: 10px;
    border-radius: 8px;
    text-align: left;
    color: #334155 !important;
    text-decoration: none;
}

.mobile-submenu li a:hover,
.mobile-submenu li a:active {
    background: #e2e8f0;
    color: #1b5e20 !important;
}

.mobile-submenu-all a {
    color: #1b5e20 !important;
    font-weight: 700 !important;
    border-top: 1px dashed #cbd5e1;
    margin-top: 4px;
    padding-top: 10px !important;
}
`;

// Replace existing .nav-links block in style.css or append
if (!css.includes('.nav-item-dropdown')) {
    css += '\n' + navDropdownCss;
    console.log('[SUCCESS] Added nav-item-dropdown styles to css/style.css');
}

// Update hamburger breakpoint to 1080px
css = css.replace(/@media\s*\(\s*max-width:\s*768px\s*\)\s*\{([\s\S]*?)\.nav-links\s*\{\s*display:\s*none\s*!important;\s*\}\s*\.hamburger\s*\{\s*display:\s*flex\s*!important;\s*\}/i, (match, p1) => {
    return `@media (max-width: 1080px) {\n    .nav-links { display: none !important; }\n    .hamburger { display: flex !important; }\n}\n@media (max-width: 768px) {${p1}`;
});

fs.writeFileSync(cssPath, css, 'utf8');

// 2. Update js/main.js
console.log('\n=== 2. Updating js/main.js ===');
let js = fs.readFileSync(jsPath, 'utf8');

if (!js.includes('mobile-dropdown-toggle')) {
    const accordionJs = `
        // Mobile Dropdown Accordion Toggle
        mobileMenu.addEventListener('click', (e) => {
            const toggleBtn = e.target.closest('.mobile-dropdown-toggle');
            if (toggleBtn) {
                e.preventDefault();
                e.stopPropagation();
                const dropdownItem = toggleBtn.closest('.mobile-dropdown-item');
                if (dropdownItem) {
                    dropdownItem.classList.toggle('open');
                }
            }
        });
`;
    js = js.replace(/hamburger\.addEventListener\('click'/, accordionJs + '\n        hamburger.addEventListener(\'click\'');
    fs.writeFileSync(jsPath, js, 'utf8');
    console.log('[SUCCESS] Added mobile accordion handler to js/main.js');
}

// 3. Update services.html images
console.log('\n=== 3. Updating services.html images ===');
let servicesHtml = fs.readFileSync(servicesHtmlPath, 'utf8');

// Row 1 - Residential
servicesHtml = servicesHtml.replace(
    /<img[^>]*src="[^"]*residential_solar\.png"[^>]*>/i,
    `<img src="/assets/services/residential_solar_pune.jpg" alt="Realistic Indian Residential Rooftop Solar Installation Pune Maharashtra" width="600" height="400" loading="lazy" style="border-radius: 20px; box-shadow: 0 16px 40px rgba(0,0,0,0.12); width: 100%; height: auto; object-fit: cover;">`
);

// Row 2 - Commercial
servicesHtml = servicesHtml.replace(
    /<img[^>]*src="[^"]*commercial_solar\.png"[^>]*>/i,
    `<img src="/assets/services/commercial_solar_pune.jpg" alt="Commercial Rooftop Solar Power Plant Cyber City Pune" width="600" height="400" loading="lazy" style="border-radius: 20px; box-shadow: 0 16px 40px rgba(0,0,0,0.12); width: 100%; height: auto; object-fit: cover;">`
);

// Row 3 - Industrial
servicesHtml = servicesHtml.replace(
    /<img[^>]*src="[^"]*industrial_solar\.png"[^>]*>/i,
    `<img src="/assets/projects/eagle_burgmann.png" alt="Industrial Solar EPC Plant Chakan MIDC Pune - Eagle Burgmann 200kW Project" width="600" height="400" loading="lazy" style="border-radius: 20px; box-shadow: 0 16px 40px rgba(0,0,0,0.12); width: 100%; height: auto; object-fit: cover;">`
);

// Row 4 - Solar Water Heater
servicesHtml = servicesHtml.replace(
    /<img[^>]*src="[^"]*solar heater\.jpeg"[^>]*>/i,
    `<img src="/assets/Projects_egreen/solar heater.jpeg" alt="Solar Water Heater Installation Pune Maharashtra" width="600" height="400" loading="lazy" style="border-radius: 20px; box-shadow: 0 16px 40px rgba(0,0,0,0.12); width: 100%; height: auto; object-fit: cover;">`
);

fs.writeFileSync(servicesHtmlPath, servicesHtml, 'utf8');
console.log('[SUCCESS] Updated service images in services.html with realistic project photos');

console.log('\nFinished CSS, JS, and services.html updates.');
