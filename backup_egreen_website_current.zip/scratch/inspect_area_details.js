const fs = require('fs');

const files = [
  'solar-panel-pune.html',
  'solar-panel-pimpri-chinchwad.html',
  'solar-panel-baner-bavdhan.html',
  'solar-panel-bhosari-pcmc.html',
  'solar-panel-chakan.html',
  'solar-panel-kiwale.html',
  'solar-panel-lonavala.html'
];

files.forEach(file => {
  console.log(`\n================== ${file} ==================`);
  const html = fs.readFileSync(file, 'utf8');

  // Find schemas
  const schemas = [...html.matchAll(/<script\s+type=["']application\/ld\+json["']>([\s\S]*?)<\/script>/gi)];
  console.log(`Schemas (${schemas.length}):`);
  schemas.forEach((s, idx) => {
    try {
      const obj = JSON.parse(s[1].trim());
      console.log(`  [${idx+1}] @type: ${obj['@type']} | name: ${obj.name || obj.headline || 'N/A'}`);
    } catch(e) {
      console.log(`  [${idx+1}] PARSE ERROR: ${e.message}`);
    }
  });

  // Find main structure
  const mainMatch = html.match(/<main[^>]*>([\s\S]*?)<\/main>/i);
  if (mainMatch) {
    const mainHtml = mainMatch[1];
    const sections = [...mainHtml.matchAll(/<section[^>]*id=["']([^"']*)["'][^>]*>/gi)].map(m => m[1]);
    console.log(`Sections in <main>: ${sections.join(', ')}`);
  } else {
    console.log('NO <main> tag found!');
  }

  // Find all headings
  const headings = [...html.matchAll(/<(h[1-3])[^>]*>([\s\S]*?)<\/\1>/gi)].map(m => `  ${m[1].toUpperCase()}: ${m[2].replace(/<[^>]+>/g, '').trim()}`);
  console.log('Headings:');
  console.log(headings.slice(0, 15).join('\n'));
});
