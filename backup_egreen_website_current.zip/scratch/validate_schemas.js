const fs = require('fs');

const files = [
    'solar-panel-cleaning-pune.html',
    'solar-amc-pune.html',
    'solar-repair-maintenance-pune.html',
    'solar-inverter-repair-pune.html',
    'solar-net-meter-msedcl-pune.html',
    'solar-plant-revamping-repowering.html',
    'services.html'
];

let totalSchemas = 0;
let errors = 0;

files.forEach(f => {
    const html = fs.readFileSync(f, 'utf8');
    const regex = /<script\s+type=["']application\/ld\+json["']>([\s\S]*?)<\/script>/gi;
    let match;
    let idx = 0;
    while ((match = regex.exec(html)) !== null) {
        idx++;
        totalSchemas++;
        try {
            JSON.parse(match[1].trim());
        } catch (e) {
            console.error(`✗ Schema JSON parse error in ${f} (schema #${idx}): ${e.message}`);
            errors++;
        }
    }
});

if (errors === 0) {
    console.log(`✓ All ${totalSchemas} JSON-LD schemas parsed with 100% validity!`);
} else {
    console.error(`Found ${errors} schema errors.`);
}
