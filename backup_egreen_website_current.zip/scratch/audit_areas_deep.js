const fs = require('fs');
const path = require('path');

const areaPages = [
  'areas.html',
  'solar-panel-pune.html',
  'solar-panel-pimpri-chinchwad.html',
  'solar-panel-baner-bavdhan.html',
  'solar-panel-bhosari-pcmc.html',
  'solar-panel-chakan.html',
  'solar-panel-kiwale.html',
  'solar-panel-lonavala.html'
];

console.log('================================================================');
console.log('BEYOND SEO TECHNICAL AUDIT - REGIONAL & AREA LANDING PAGES');
console.log('================================================================\n');

const pageData = [];

areaPages.forEach(file => {
  const fullPath = path.join(__dirname, '..', file);
  if (!fs.existsSync(fullPath)) {
    console.log(`[FILE MISSING] ${file}`);
    return;
  }

  const html = fs.readFileSync(fullPath, 'utf8');

  // Title
  const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
  const title = titleMatch ? titleMatch[1].replace(/&amp;/g, '&') : '';

  // Meta Description
  const descMatch = html.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i);
  const desc = descMatch ? descMatch[1].replace(/&amp;/g, '&') : '';

  // Canonical
  const canMatch = html.match(/<link\s+rel=["']canonical["']\s+href=["']([^"']+)["']/i);
  const canonical = canMatch ? canMatch[1] : '';

  // Open Graph
  const ogTitle = (html.match(/<meta\s+property=["']og:title["']\s+content=["']([^"']+)["']/i) || [])[1];
  const ogImg = (html.match(/<meta\s+property=["']og:image["']\s+content=["']([^"']+)["']/i) || [])[1];

  // Headings
  const h1s = [...html.matchAll(/<h1[^>]*>([\s\S]*?)<\/h1>/gi)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
  const h2s = [...html.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/gi)].map(m => m[1].replace(/<[^>]+>/g, '').trim());
  const h3s = [...html.matchAll(/<h3[^>]*>([\s\S]*?)<\/h3>/gi)].map(m => m[1].replace(/<[^>]+>/g, '').trim());

  // Images
  const imgMatches = [...html.matchAll(/<img\s+([^>]+)>/gi)];
  const images = imgMatches.map(m => {
    const raw = m[1];
    const src = (raw.match(/src=["']([^"']+)["']/i) || ['', ''])[1];
    const alt = (raw.match(/alt=["']([^"']+)["']/i) || ['', ''])[1];
    const loading = (raw.match(/loading=["']([^"']+)["']/i) || ['', ''])[1];
    const width = (raw.match(/width=["']([^"']+)["']/i) || ['', ''])[1];
    const height = (raw.match(/height=["']([^"']+)["']/i) || ['', ''])[1];
    return { src, alt, loading, width, height };
  });

  // JSON-LD Schemas
  const schemas = [...html.matchAll(/<script\s+type=["']application\/ld\+json["']>([\s\S]*?)<\/script>/gi)].map(m => {
    try {
      return JSON.parse(m[1].trim());
    } catch(e) {
      return { error: e.message };
    }
  });

  // Clean visible text
  const cleanText = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
                        .replace(/<[^>]+>/g, ' ')
                        .replace(/\s+/g, ' ')
                        .trim();
  const words = cleanText.split(/\s+/).filter(Boolean);

  // Check internal links
  const hrefs = [...html.matchAll(/href=["']([^"'#]+)["']/gi)].map(m => m[1]);
  const htmlExtensions = hrefs.filter(h => h.endsWith('.html'));

  pageData.push({
    file,
    title,
    titleLen: title.length,
    desc,
    descLen: desc.length,
    canonical,
    ogTitle,
    ogImg,
    h1s,
    h2s,
    h3s,
    images,
    schemas,
    wordCount: words.length,
    htmlExtensions,
    cleanText
  });
});

// Compare content overlap / duplication between pages
console.log('--- PAGE OVERVIEWS ---');
pageData.forEach(p => {
  console.log(`\nPAGE: ${p.file}`);
  console.log(`  Title (${p.titleLen} chars): "${p.title}"`);
  console.log(`  Description (${p.descLen} chars): "${p.desc}"`);
  console.log(`  Canonical: ${p.canonical}`);
  console.log(`  H1 count: ${p.h1s.length} -> "${p.h1s.join(' | ')}"`);
  console.log(`  H2 count: ${p.h2s.length} | H3 count: ${p.h3s.length}`);
  console.log(`  Total Images: ${p.images.length}`);
  p.images.forEach(img => {
    console.log(`    - src: ${img.src} | alt: "${img.alt}" | lazy: ${img.loading || 'no'} | dimensions: ${img.width}x${img.height}`);
  });
  console.log(`  JSON-LD Schemas: ${p.schemas.length} (${p.schemas.map(s => s['@type'] || s.error).join(', ')})`);
  console.log(`  Word count: ${p.wordCount}`);
  if (p.htmlExtensions.length > 0) {
    console.log(`  [WARN] Non-clean .html links found: ${p.htmlExtensions.length}`);
  }
});

// Similarity matrix
console.log('\n--- TEXT SIMILARITY / DUPLICATION MATRIX (Jaccard Similarity of 3-grams) ---');
function get3Grams(text) {
  const words = text.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(Boolean);
  const grams = new Set();
  for (let i = 0; i < words.length - 2; i++) {
    grams.add(`${words[i]} ${words[i+1]} ${words[i+2]}`);
  }
  return grams;
}

for (let i = 0; i < pageData.length; i++) {
  const gramsA = get3Grams(pageData[i].cleanText);
  for (let j = i + 1; j < pageData.length; j++) {
    const gramsB = get3Grams(pageData[j].cleanText);
    let intersection = 0;
    for (const g of gramsA) {
      if (gramsB.has(g)) intersection++;
    }
    const union = gramsA.size + gramsB.size - intersection;
    const similarity = ((intersection / union) * 100).toFixed(1);
    if (similarity > 20) {
      console.log(`  HIGH OVERLAP: ${pageData[i].file} <-> ${pageData[j].file}: ${similarity}% 3-gram overlap!`);
    } else {
      console.log(`  ${pageData[i].file} <-> ${pageData[j].file}: ${similarity}%`);
    }
  }
}
