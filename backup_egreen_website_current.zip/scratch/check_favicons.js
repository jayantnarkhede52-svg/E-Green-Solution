const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const files = fs.readdirSync(rootDir).filter(f => f.endsWith('.html'));
const blogFiles = fs.readdirSync(path.join(rootDir, 'blog')).filter(f => f.endsWith('.html'));

console.log('=== CHECKING FAVICONS IN ROOT HTML FILES ===');
for (const file of files) {
    const content = fs.readFileSync(path.join(rootDir, file), 'utf8');
    const faviconMatches = content.match(/<link[^>]*rel=["'](?:icon|shortcut icon|apple-touch-icon)["'][^>]*>/gi);
    console.log(`${file}: ${faviconMatches ? faviconMatches.join(' | ') : 'NO FAVICON FOUND'}`);
}

console.log('\n=== CHECKING FAVICONS IN BLOG HTML FILES ===');
for (const file of blogFiles) {
    const content = fs.readFileSync(path.join(rootDir, 'blog', file), 'utf8');
    const faviconMatches = content.match(/<link[^>]*rel=["'](?:icon|shortcut icon|apple-touch-icon)["'][^>]*>/gi);
    console.log(`${file}: ${faviconMatches ? faviconMatches.join(' | ') : 'NO FAVICON FOUND'}`);
}
