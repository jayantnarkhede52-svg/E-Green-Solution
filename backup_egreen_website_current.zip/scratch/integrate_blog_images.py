import os, re

BASE_DIR = r'c:\work\E GREEN WEBSITE'
BLOG_DIR = os.path.join(BASE_DIR, 'blog')

BLOGS_INFO = [
    {
        'file': 'bifacial-solar-panels-pune.html',
        'img': '/assets/blog/bifacial_solar_panels_pune.jpg',
        'alt': 'Bifacial Solar Panels Installation on Rooftop in Pune',
        'caption': 'On-site field snapshot: Dual-glass bifacial solar panel array mounted over light reflective concrete terrace floor in Pune.',
        'article_tag': '<article class="article-content">'
    },
    {
        'file': 'mono-perc-vs-topcon-solar-pune.html',
        'img': '/assets/blog/mono_perc_vs_topcon_pune.jpg',
        'alt': 'Mono PERC vs TOPCon Solar Panel Inspection in Pune',
        'caption': 'On-site inspection: Technician checking monocrystalline half-cut cells and silver busbar contact lines on a terrace in Pune.',
        'article_tag': '<article class="article-content">'
    },
    {
        'file': 'dcr-solar-panels-pune.html',
        'img': '/assets/blog/dcr_solar_panels_pune.jpg',
        'alt': 'DCR Solar Panel Made in India Nameplate and Junction Box',
        'caption': 'On-site verification: DCR solar module junction box and Made in India ALMM specification plate inspected for PM Surya Ghar subsidy.',
        'article_tag': '<article class="article-content">'
    },
    {
        'file': 'hybrid-solar-system-lithium-battery-pune.html',
        'img': '/assets/blog/hybrid_solar_lithium_battery_pune.jpg',
        'alt': 'Hybrid Solar Inverter with Lithium Battery Storage in Pune',
        'caption': 'On-site installation: Wall-mounted hybrid solar inverter connected to a LiFePO4 lithium battery backup unit in a Pune home.',
        'article_tag': '<article class="article-content">'
    },
    {
        'file': 'enphase-microinverter-installers-pune.html',
        'img': '/assets/blog/enphase_microinverter_pune.jpg',
        'alt': 'Enphase Microinverter Bolted to Rooftop Solar Mounting Rail',
        'caption': 'On-site installation: Enphase microinverter unit secured beneath module rail with heavy-duty trunk cabling on an Indian rooftop.',
        'article_tag': '<article class="article-content">'
    },
    {
        'file': 'on-grid-solar-inverter-dealers-pune.html',
        'img': '/assets/blog/on_grid_solar_inverter_pune.jpg',
        'alt': 'On-Grid Solar String Inverter with DC Isolator Switch in Pune',
        'caption': 'On-site installation: Weather-protected on-grid string inverter with live LCD power generation meter and DC isolator switch.',
        'article_tag': '<article class="article-content">'
    },
    {
        'file': 'elevated-rooftop-solar-structure-pune.html',
        'img': '/assets/blog/elevated_rooftop_solar_structure_pune.jpg',
        'alt': 'Elevated Rooftop Solar Pergola with Usable Terrace Space in Pune',
        'caption': 'On-site terrace: 9-foot elevated galvanized solar structure providing cool shaded sitting and recreation area for residents underneath.',
        'article_tag': '<article class="blog-content">'
    }
]

# 1. Update blog/index.html
index_path = os.path.join(BLOG_DIR, 'index.html')
with open(index_path, 'r', encoding='utf-8') as f:
    index_content = f.read()

# Add CSS for .blog-thumb
thumb_css = '''
        .blog-thumb { width: 100%; aspect-ratio: 16 / 9; overflow: hidden; background: #0b1320; display: block; position: relative; }
        .blog-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform 0.4s ease; }
        .blog-card:hover .blog-thumb img { transform: scale(1.04); }
'''
if '.blog-thumb' not in index_content:
    index_content = index_content.replace('    </style>', thumb_css + '    </style>', 1)

# Add thumbnails to each blog card
for info in BLOGS_INFO:
    slug = info['file'].replace('.html', '')
    url_pattern = f'/blog/{slug}'
    
    # Target: <article class="blog-card">\n                <div class="blog-card-body">
    # We want to insert the <a href="..." class="blog-thumb">...</a> right before <div class="blog-card-body">
    # Locate article for this slug
    article_re = re.compile(
        rf'(<article class="blog-card">\s*)(<div class="blog-card-body">\s*<div>\s*<span class="blog-tag">[^<]*</span>\s*<h2 class="blog-title"><a href="{url_pattern}")',
        re.MULTILINE
    )
    
    thumb_html = rf'\1<a href="{url_pattern}" class="blog-thumb" aria-label="{info["alt"]}">\n                    <img src="{info["img"]}" alt="{info["alt"]}" loading="lazy">\n                </a>\n                \2'
    
    new_index_content, count = article_re.subn(thumb_html, index_content)
    if count > 0:
        index_content = new_index_content
        print(f"Updated index card for {info['file']}")
    else:
        print(f"WARNING: Could not match card for {info['file']}")

with open(index_path, 'w', encoding='utf-8') as f:
    f.write(index_content)
print("Updated blog/index.html successfully!")

# 2. Update each blog HTML file
for info in BLOGS_INFO:
    blog_file_path = os.path.join(BLOG_DIR, info['file'])
    with open(blog_file_path, 'r', encoding='utf-8') as f:
        blog_content = f.read()

    # Check if image box already inserted
    if info['img'] not in blog_content:
        figure_html = f'''{info['article_tag']}
            <!-- Featured Blog Image (Real On-Site Snapshot) -->
            <figure class="blog-featured-image-box" style="margin: 0 0 35px; border-radius: 16px; overflow: hidden; box-shadow: 0 8px 25px rgba(0,0,0,0.07); border: 1px solid #e2e8f0; background: #fff;">
                <img src="{info['img']}" alt="{info['alt']}" style="width: 100%; aspect-ratio: 16 / 9; object-fit: cover; display: block;" loading="eager">
                <figcaption style="padding: 12px 18px; font-size: 13.5px; color: #64748b; background: #f8fafc; border-top: 1px solid #f1f5f9; display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-camera" style="color: var(--primary, #2e7d32);"></i> {info['caption']}
                </figcaption>
            </figure>'''
        
        if info['article_tag'] in blog_content:
            blog_content = blog_content.replace(info['article_tag'], figure_html, 1)
            print(f"Inserted featured image into {info['file']}")
        else:
            print(f"ERROR: Article tag not found in {info['file']}")

    # Update Open Graph / Twitter image if present
    full_img_url = f"https://egreensolution.in{info['img']}"
    blog_content = re.sub(r'<meta property="og:image" content="[^"]*">', f'<meta property="og:image" content="{full_img_url}">', blog_content)
    blog_content = re.sub(r'<meta (property|name)="twitter:image" content="[^"]*">', f'<meta name="twitter:image" content="{full_img_url}">', blog_content)

    with open(blog_file_path, 'w', encoding='utf-8') as f:
        f.write(blog_content)

print("ALL BLOGS UPDATED SUCCESSFULLY!")
