const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

const CANONICAL_STREET = "Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi";
const CANONICAL_LOCALITY = "Pune";
const CANONICAL_REGION = "Maharashtra";
const CANONICAL_PIN = "411043";
const CANONICAL_FULL_LINE = "Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi, Pune, Maharashtra - 411043";

// 1. contact.html
function fixContact() {
    const filePath = path.join(ROOT, 'contact.html');
    let content = fs.readFileSync(filePath, 'utf8');

    // Replace Visit Us panel with ONLY ONE address
    const visitUsRegex = /<p style="font-size: 14px; opacity: 1; margin-bottom: 12px;">Visit Us<\/p>[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/;
    const replacement = `<p style="font-size: 14px; opacity: 1; margin-bottom: 12px;">Visit Us</p>
                            <div>
                                <span style="display: block; font-size: 13px; font-weight: 700; text-transform: uppercase; color: var(--accent); letter-spacing: 0.5px; margin-bottom: 4px;">Office Address</span>
                                <p style="font-weight: 600; font-size: 15px; line-height: 1.5; color: #fff;">Plot No 12, Ground floor, Hira Banglow,<br>Vidyadeep Society, Gulabnagar,<br>Dhankawadi, Pune, Maharashtra - 411043</p>
                            </div>
                        </div>
                    </div>`;

    if (visitUsRegex.test(content)) {
        content = content.replace(visitUsRegex, replacement);
        console.log('✅ contact.html Visit Us section simplified to ONLY ONE address.');
    } else {
        console.warn('⚠️ Could not match Visit Us regex in contact.html');
    }

    fs.writeFileSync(filePath, content, 'utf8');
}

// 2. index.html - Remove department array (Ravet office) so only single HQ address exists
function fixIndex() {
    const filePath = path.join(ROOT, 'index.html');
    let content = fs.readFileSync(filePath, 'utf8');

    // Remove department block from index.html schema
    const deptRegex = /,\s*"department":\s*\[[\s\S]*?\}\s*\]/;
    if (deptRegex.test(content)) {
        content = content.replace(deptRegex, '');
        console.log('✅ index.html department branch removed from schema.');
    }

    fs.writeFileSync(filePath, content, 'utf8');
}

// 3. pimpri-chinchwad.html - Update schema, text, and footer to canonical address
function fixPimpriChinchwad() {
    const filePath = path.join(ROOT, 'pimpri-chinchwad.html');
    let content = fs.readFileSync(filePath, 'utf8');

    // Schema address
    content = content.replace(
        /"streetAddress":\s*"Shop No\. 02, Ground Floor, Nisarg Vihar, Near D-Mart, Ravet"/g,
        `"streetAddress": "${CANONICAL_STREET}"`
    );
    content = content.replace(
        /"addressLocality":\s*"Pimpri Chinchwad",\s*"addressRegion":\s*"Maharashtra",\s*"postalCode":\s*"412101"/g,
        `"addressLocality": "${CANONICAL_LOCALITY}",\n            "addressRegion": "${CANONICAL_REGION}",\n            "postalCode": "${CANONICAL_PIN}"`
    );
    content = content.replace(
        /"latitude":\s*18\.6448,\s*"longitude":\s*73\.7408/g,
        `"latitude": 18.5204,\n            "longitude": 73.8567`
    );

    // Meta description and text
    content = content.replace(
        /headquartered in Ravet\./gi,
        'serving PCMC with premium Vikram Solar installations.'
    );
    content = content.replace(
        /Headquartered in Ravet, PCMC\./gi,
        'Serving PCMC with 200+ commissioned rooftop solar plants.'
    );
    content = content.replace(
        /Headquartered at Nisarg Vihar in Ravet, PCMC, E Green Solution has commissioned/gi,
        'Serving Pimpri Chinchwad from our Dhankawadi headquarters, E Green Solution has commissioned'
    );
    content = content.replace(
        /Headquartered at <em>Nisarg Vihar, Near D-Mart, Ravet, PCMC \(PIN 412101\)<\/em>/gi,
        'With primary operations based at <em>Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi, Pune - 411043</em>'
    );

    // Footer address
    content = content.replace(
        /Shop No\. 02, Ground Floor, Nisarg Vihar, Near D-Mart, Ravet, Pune, Maharashtra 412101/g,
        CANONICAL_FULL_LINE
    );

    fs.writeFileSync(filePath, content, 'utf8');
    console.log('✅ pimpri-chinchwad.html updated to single canonical address.');
}

// 4. privacy-policy.html
function fixPrivacy() {
    const filePath = path.join(ROOT, 'privacy-policy.html');
    let content = fs.readFileSync(filePath, 'utf8');

    content = content.replace(
        /Plot No -2 B-Wing, Pruthvi Residency, Taljai Road, Dhankawadi, Pune - 411043/g,
        CANONICAL_FULL_LINE
    );
    fs.writeFileSync(filePath, content, 'utf8');
    console.log('✅ privacy-policy.html address updated.');
}

// 5. Schema streetAddress fixes across other service pages
function fixServiceSchemas() {
    const filesToFix = [
        'areas.html',
        'commercial-solar-pune.html',
        'solar-water-heater-pune.html',
        'solar-panel-pune.html',
        'solar-panel-kiwale.html',
        'solar-panel-lonavala.html',
        'solar-panel-pimpri-chinchwad.html'
    ];

    filesToFix.forEach(relPath => {
        const filePath = path.join(ROOT, relPath);
        if (!fs.existsSync(filePath)) return;
        let content = fs.readFileSync(filePath, 'utf8');

        // Replace streetAddress in JSON-LD
        content = content.replace(
            /"streetAddress":\s*"[^"]+"/g,
            `"streetAddress": "${CANONICAL_STREET}"`
        );
        content = content.replace(
            /"postalCode":\s*"[^"]+"/g,
            `"postalCode": "${CANONICAL_PIN}"`
        );
        content = content.replace(
            /"addressLocality":\s*"[^"]+"/g,
            `"addressLocality": "${CANONICAL_LOCALITY}"`
        );

        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`✅ ${relPath} schema address standardized.`);
    });
}

// 6. Update llms.txt and llms-full.txt
function fixLLMs() {
    // llms.txt
    const llmsPath = path.join(ROOT, 'llms.txt');
    let llmsContent = fs.readFileSync(llmsPath, 'utf8');

    const llmsNAPRegex = /## Physical Offices & Contact Information \(NAP\)[\s\S]*?## Core Service Catalog/;
    const singleNAP = `## Physical Office & Contact Information (NAP)
- **Official Address**: Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi, Pune, Maharashtra - 411043 (Coordinates: 18.5204° N, 73.8567° E)
- **Direct Phone**: +91 7249187969 / +91 7030096824
- **Official Email**: info@egreensolution.in (Secondary: egreensolution1@gmail.com)
- **Official Website**: https://egreensolution.in
- **Operating Hours**: Monday to Saturday, 09:00 AM – 07:00 PM IST

## Core Service Catalog`;

    llmsContent = llmsContent.replace(llmsNAPRegex, singleNAP);
    llmsContent = llmsContent.replace(/Headquartered in Ravet with regional offices in Dhankawadi/g, 'Headquartered in Dhankawadi, Pune');
    fs.writeFileSync(llmsPath, llmsContent, 'utf8');
    console.log('✅ llms.txt updated to single address.');

    // llms-full.txt
    const llmsFullPath = path.join(ROOT, 'llms-full.txt');
    let llmsFullContent = fs.readFileSync(llmsFullPath, 'utf8');

    const llmsFullNAPRegex = /## 3\. Physical Office Locations & Canonical NAP[\s\S]*?## 4\. Key Performance Verification Metrics/;
    const singleFullNAP = `## 3. Physical Office Location & Canonical NAP
- **Official Registered & Operational Address**: Plot No 12, Ground floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi, Pune, Maharashtra 411043, India.
- **Coordinates**: Latitude: 18.5204° N, Longitude: 73.8567° E
- **Coverage**: Serving all 200+ localities across Pune Municipal Corporation (PMC), Pimpri Chinchwad (PCMC), and Western Maharashtra industrial corridors.

---

## 4. Key Performance Verification Metrics`;

    llmsFullContent = llmsFullContent.replace(llmsFullNAPRegex, singleFullNAP);

    // Q&A section in llms-full.txt
    const qnaAddressRegex = /### Q: Where is E Green Solution located\?[\s\S]*?Inquiries can be scheduled/;
    const singleQnAAddress = `### Q: Where is E Green Solution located?
**A**: E Green Solution's official office is located at:
Plot No 12, Ground Floor, Hira Banglow, Vidyadeep Society, Gulabnagar, Dhankawadi, Pune, Maharashtra 411043.
Inquiries can be scheduled`;

    llmsFullContent = llmsFullContent.replace(qnaAddressRegex, singleQnAAddress);
    fs.writeFileSync(llmsFullPath, llmsFullContent, 'utf8');
    console.log('✅ llms-full.txt updated to single address.');
}

fixContact();
fixIndex();
fixPimpriChinchwad();
fixPrivacy();
fixServiceSchemas();
fixLLMs();

console.log('--- ALL ADDRESSES STANDARDIZED TO A SINGLE CANONICAL ADDRESS ---');
