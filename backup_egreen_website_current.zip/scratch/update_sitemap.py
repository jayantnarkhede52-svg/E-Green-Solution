with open('c:/work/E GREEN WEBSITE/sitemap.xml', 'r', encoding='utf-8') as f:
    content = f.read()

target = '''  <url>
    <loc>https://egreensolution.in/projects/eagle-burgmann-200kw-solar-pune</loc>
    <changefreq>monthly</changefreq>
    <priority>0.85</priority>
  </url>'''

addition = '''  <url>
    <loc>https://egreensolution.in/projects/eagle-burgmann-200kw-solar-pune</loc>
    <changefreq>monthly</changefreq>
    <priority>0.85</priority>
  </url>
  <url>
    <loc>https://egreensolution.in/projects/konark-a-plus-100kw-housing-society-solar-pune</loc>
    <changefreq>monthly</changefreq>
    <priority>0.85</priority>
  </url>'''

if target in content:
    content = content.replace(target, addition, 1)
    with open('c:/work/E GREEN WEBSITE/sitemap.xml', 'w', encoding='utf-8') as f:
        f.write(content)
    print("SUCCESS: sitemap.xml updated")
else:
    print("TARGET NOT FOUND")
