const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');

const heroConfigs = {
  // --- Service Pages ---
  'services.html': {
    eyebrow: 'Full-Lifecycle Solar EPC &amp; O&amp;M',
    title: 'Solar Services in Pune',
    desc: 'Complete rooftop solar engineering, procurement, and construction from <span class="highlight-mark">residential homes</span> to <span class="highlight-mark">MIDC factories</span>. Backed by <span class="accent-underline">25-year performance warranties</span> and rapid breakdown support.',
    chips: ['Residential & Commercial EPC', 'PM Surya Ghar Subsidy', 'Solar AMC & Cleaning', 'Inverter & Meter Testing'],
    rating: '⭐ 4.9/5 Rating (200+ Commissioned Rooftops)',
    subject: 'New Solar Services Inquiry - Pune',
    pageName: 'services',
    reqLabel: 'Required Service',
    options: ['Residential Rooftop Solar', 'Commercial Solar EPC', 'Industrial MIDC Solar', 'Solar Water Heaters', 'Solar AMC & Maintenance', 'Solar Panel Cleaning', 'Inverter Repair'],
    btnText: 'Get Free Services Quote',
    replaceRegex: /<header\s+class=["']page-header["'][\s\S]*?<\/header>/i
  },
  'residential-solar.html': {
    eyebrow: 'PM Surya Ghar Registered EPC',
    title: 'Solar Panels for Home in Pune',
    desc: 'Slash monthly electricity bills by up to <span class="highlight-mark">90%</span>. Get direct bank transfer subsidy up to <span class="highlight-mark">₹78,000</span> under PM Surya Ghar Muft Bijli Yojana with <span class="accent-underline">seamless MSEDCL net metering</span>.',
    chips: ['₹78,000 Direct Subsidy Support', '25-Year Performance Warranty', '3kW, 5kW & 10kW Systems', '3.2-Year Estimated Payback'],
    rating: '⭐ 4.9/5 Rating (200+ Homes Powered)',
    subject: 'New Residential Solar Inquiry - Pune',
    pageName: 'residential-solar',
    reqLabel: 'Home System Size',
    options: ['3 kW (Best for 2-3 BHK)', '5 kW (Bungalow / 4 BHK)', '10 kW+ (Large Villa / Society)', 'Housing Society Common Meter'],
    btnText: 'Claim PM Surya Ghar Subsidy',
    replaceRegex: /<header\s+class=["']hero-residential["'][\s\S]*?<\/header>/i
  },
  'commercial-solar-pune.html': {
    eyebrow: 'MSEDCL Commercial Solar EPC',
    title: 'Commercial Solar Installation in Pune',
    desc: 'Replace expensive commercial tariffs (<span class="highlight-mark">₹11–₹14+/kWh</span>) with zero-cost daytime solar power. Benefit from <span class="highlight-mark">40% accelerated depreciation</span> under Section 32 and <span class="accent-underline">under 3.2-year capital payback</span>.',
    chips: ['Offices, Hospitals, Hotels & Malls', '40% Section 32 Tax Depreciation*', 'Elevated Pergolas & Carports', 'MSEDCL HT/LT Net Metering'],
    rating: '⭐ 4.9/5 Rating (Commercial Rooftops in Pune)',
    subject: 'New Commercial Solar Inquiry - Pune',
    pageName: 'commercial-solar-pune',
    reqLabel: 'Commercial Facility Type',
    options: ['Corporate Office / IT Park', 'Hospital / Healthcare Facility', 'Hotel / Resort / Banquet', 'School / College / Institute', 'Shopping Mall / Showroom', 'Housing Society Common Meter'],
    btnText: 'Request Commercial Feasibility Study',
    replaceRegex: /<header\s+class=["']hero-commercial["'][\s\S]*?<\/header>/i
  },
  'industrial-solar.html': {
    eyebrow: 'Turnkey Industrial EPC &amp; CEIG Clearance',
    title: 'Industrial Solar Installation & EPC in Pune',
    desc: 'High-yield captive solar power plants for factories, machining workshops, and warehouses across <span class="highlight-mark">Chakan, Bhosari, and Talegaon MIDC</span>. Built with <span class="accent-underline">zero-penetration clamps</span> and CEIG approvals.',
    chips: ['Chakan, Bhosari & Talegaon MIDC', 'Non-Penetrative Standing Seam Clamps', '11kV/22kV/33kV HT Synchronization', '40% Section 32 Tax Benefits'],
    rating: '⭐ 4.9/5 Rating (2MW+ Industrial EPC Commissioned)',
    subject: 'New Industrial Solar Inquiry - Pune',
    pageName: 'industrial-solar',
    reqLabel: 'Factory Power Requirement',
    options: ['50 kW – 100 kW (SME Workshop)', '100 kW – 250 kW (Manufacturing Unit)', '250 kW – 1 MW+ (Heavy Industrial Plant)', 'Industrial Plant Revamping'],
    btnText: 'Request Industrial EPC Proposal',
    replaceRegex: /<header\s+class=["']hero-industrial["'][\s\S]*?<\/header>/i
  },
  'solar-water-heater-pune.html': {
    eyebrow: 'Solar Thermal Engineering',
    title: 'Solar Water Heater Dealers & Installation in Pune',
    desc: 'Cut bathroom water heating electricity by <span class="highlight-mark">80%</span>. Premium <span class="highlight-mark">ETC &amp; FPC solar water heaters</span> with high-density 50mm injected PUF insulation and <span class="accent-underline">scale-resistant inner tanks</span>.',
    chips: ['100 LPD to 5,000+ LPD Capacities', 'High-Density 50mm PUF Insulation', 'Pune Hard-Water Scale Resistant', 'Integrated Monsoon Heating Element'],
    rating: '⭐ 4.9/5 Rating (Residential & Commercial SWH)',
    subject: 'New Solar Water Heater Inquiry - Pune',
    pageName: 'solar-water-heater-pune',
    reqLabel: 'Daily Hot Water Demand',
    options: ['100 LPD (2-3 Persons)', '150 LPD (3-4 Persons)', '200 LPD (4-5 Persons) - Most Popular', '300 - 500 LPD (Villa / Joint Family)', '1,000L+ Commercial (Hotels / Hostels)'],
    btnText: 'Get Instant Water Heater Quote',
    replaceRegex: /<header\s+class=["']hero-water-heater["'][\s\S]*?<\/header>/i
  },
  'solar-subsidy.html': {
    eyebrow: 'Official PM Surya Ghar Scheme 2026',
    title: 'Solar Subsidy in Pune - PM Surya Ghar Guide',
    desc: 'Save up to <span class="highlight-mark">₹78,000</span> via direct bank transfer subsidy. We handle <span class="accent-underline">100% of National Portal documentation</span>, DISCOM technical feasibility approvals, and MSEDCL bi-directional net meter synchronization.',
    chips: ['₹30,000 for 1 kW System', '₹60,000 for 2 kW System', '₹78,000 for 3 kW+ Systems', 'Direct DBT to Homeowner Account'],
    rating: '⭐ 4.9/5 Rating (Guaranteed Subsidy Processing)',
    subject: 'New PM Surya Ghar Subsidy Inquiry - Pune',
    pageName: 'solar-subsidy',
    reqLabel: 'Sanctioned Load / System Sizing',
    options: ['1 kW System (₹30,000 Subsidy)', '2 kW System (₹60,000 Subsidy)', '3 kW+ System (₹78,000 Max Subsidy)', 'Housing Society Common Meter'],
    btnText: 'Check Subsidy Eligibility',
    replaceRegex: /<header[\s\S]*?<\/header>/i
  },
  'solar-panel-cleaning-pune.html': {
    eyebrow: 'Safe Low-TDS Scientific Cleaning',
    title: 'Solar Panel Cleaning Services in Pune',
    desc: 'Restore up to <span class="highlight-mark">25% lost generation</span> caused by urban dust, particulate soiling, and bird droppings. We use <span class="highlight-mark">low-TDS demineralized water</span> and <span class="accent-underline">ultra-soft scratch-free solar bristles</span>.',
    chips: ['Pure Low-TDS Demineralized Water', 'Ultra-Soft Scratch-Free Brushes', 'Early Morning Wash (No Thermal Shock)', 'Before & After Generation Checks'],
    rating: '⭐ 4.9/5 Rating (Commercial & Residential Washing)',
    subject: 'New Solar Panel Cleaning Inquiry - Pune',
    pageName: 'solar-panel-cleaning-pune',
    reqLabel: 'Plant Type & Size',
    options: ['Residential Rooftop (3kW - 10kW)', 'Housing Society Plant (10kW - 50kW)', 'Commercial Complex (50kW - 100kW)', 'Industrial Factory Plant (100kW+)'],
    btnText: 'Book Scientific Panel Cleaning',
    replaceRegex: /<header[\s\S]*?<\/header>/i
  },
  'solar-amc-pune.html': {
    eyebrow: 'Annual Maintenance Contracts (AMC)',
    title: 'Solar AMC Contractors in Pune',
    desc: 'Protect your 25-year solar investment with proactive quarterly preventive maintenance. Includes <span class="highlight-mark">thermographic drone scans</span>, string Voc/Isc electrical testing, and <span class="accent-underline">guaranteed 24-hour breakdown response</span>.',
    chips: ['Comprehensive & Non-Comprehensive AMC', 'Quarterly Thermal Hotspot Scanning', 'Inverter & Earthing Resistance Checks', '24-Hour Emergency Breakdown SLA'],
    rating: '⭐ 4.9/5 Rating (AMC Contracts Across Pune)',
    subject: 'New Solar AMC Contract Inquiry - Pune',
    pageName: 'solar-amc-pune',
    reqLabel: 'AMC Plant Capacity',
    options: ['Residential AMC (3kW - 10kW)', 'Society Common Meter AMC (10kW - 50kW)', 'Commercial Rooftop AMC (50kW - 250kW)', 'Industrial Solar Plant AMC (250kW+)'],
    btnText: 'Get Custom Solar AMC Plan',
    replaceRegex: /<header[\s\S]*?<\/header>/i
  },
  'solar-repair-maintenance-pune.html': {
    eyebrow: 'Emergency On-Site Solar Repairs',
    title: 'Solar Panel Repair & Maintenance in Pune',
    desc: 'Suffering from undergeneration, disconnected DC strings, tripped breakers, or storm damage? Our certified solar engineers arrive on-site within <span class="highlight-mark">4 to 24 hours</span> with <span class="accent-underline">advanced diagnostic equipment</span>.',
    chips: ['Rapid 4–24 Hour On-Site Dispatch', 'MC4 & DC Cable Insulation Testing', 'Bypass Diode & Junction Box Fixes', 'Earthing & Surge Arrester Restoration'],
    rating: '⭐ 4.9/5 Rating (Fast Breakdown Response)',
    subject: 'Emergency Solar Repair Request - Pune',
    pageName: 'solar-repair-maintenance-pune',
    reqLabel: 'Reported Issue',
    options: ['Total System Shutdown / Tripping', 'Undergeneration / Low Daily Output', 'Physical Damage / Cable Breakdown', 'Net Meter / DISCOM Fault'],
    btnText: 'Book Emergency Solar Repair',
    replaceRegex: /<header[\s\S]*?<\/header>/i
  },
  'solar-inverter-repair-pune.html': {
    eyebrow: 'Authorized Multi-Brand Diagnostics',
    title: 'Solar Inverter Repair in Pune',
    desc: 'Is your inverter displaying red error codes, grid-fault alarms, or failing to sync? Expert component-level repair for <span class="highlight-mark">Growatt, Solis, Sungrow, Fronius, Havells, and Polycab</span> with <span class="accent-underline">OEM replacement parts</span>.',
    chips: ['Growatt, Solis, Sungrow, Fronius & More', 'Component-Level Board Diagnostics', 'Grid Synchronization Error Resolution', 'On-Site Firmware & Relay Replacement'],
    rating: '⭐ 4.9/5 Rating (Component-Level Inverter Lab)',
    subject: 'Solar Inverter Repair Request - Pune',
    pageName: 'solar-inverter-repair-pune',
    reqLabel: 'Inverter Brand & Model',
    options: ['Growatt Inverter Error', 'Solis / Solax Inverter Error', 'Sungrow / Fronius Inverter Error', 'Microinverter / Other Brand Service'],
    btnText: 'Request Inverter Diagnosis',
    replaceRegex: /<header[\s\S]*?<\/header>/i
  },
  'solar-net-meter-msedcl-pune.html': {
    eyebrow: 'Turnkey Utility Liaison Support',
    title: 'MSEDCL Solar Net Meter Testing & Replacement',
    desc: 'Are your exported solar units missing from your monthly electricity bill? We provide end-to-end liaison for <span class="highlight-mark">MSEDCL testing lab clearance</span>, faulty bidirectional meter replacement, and <span class="accent-underline">retroactive billing credit adjustments</span>.',
    chips: ['MSEDCL Accredited Meter Testing Labs', 'Missing Export Units Credit Recovery', 'Sanctioned Load Solar Upgrades', 'Fast-Track Utility Coordination'],
    rating: '⭐ 4.9/5 Rating (Utility & Billing Clearance)',
    subject: 'MSEDCL Net Meter Assistance - Pune',
    pageName: 'solar-net-meter-msedcl-pune',
    reqLabel: 'Net Meter Issue Type',
    options: ['Export Units Not Showing on Bill', 'Faulty / Burnt Net Meter Replacement', 'Solar Load Sanction Enhancement', 'New Bidirectional Net Meter Setup'],
    btnText: 'Resolve MSEDCL Net Meter Issue',
    replaceRegex: /<header[\s\S]*?<\/header>/i
  },
  'solar-plant-revamping-repowering.html': {
    eyebrow: 'Asset Modernization & Capacity Expansion',
    title: 'Solar Plant Revamping & Repowering',
    desc: 'Generate up to <span class="highlight-mark">2.5× more electricity</span> on the exact same roof footprint. Replace aging 250W–330W polycrystalline modules with <span class="highlight-mark">580W+ Tier-1 TOPCon / Bifacial panels</span> and <span class="accent-underline">modern multi-MPPT inverters</span>.',
    chips: ['2× to 3× Generation on Existing Roofs', '40% Section 32 Tax Depreciation', '2.5 to 3.0 Year Payback Cycle', 'Structural Load & Cable Re-engineering'],
    rating: '⭐ 4.9/5 Rating (Plant Repowering Specialist)',
    subject: 'Solar Plant Repowering Inquiry - Maharashtra',
    pageName: 'solar-plant-revamping-repowering',
    reqLabel: 'Existing Plant Details',
    options: ['Repower 20kW – 50kW Commercial Shed', 'Repower 100kW – 250kW Industrial Plant', 'Inverter Upgrade / Technology Revamp', 'Comprehensive Plant Performance Audit'],
    btnText: 'Request Plant Repowering Audit',
    replaceRegex: /<header[\s\S]*?<\/header>/i
  },

  // --- Regional Service Landing Pages ---
  'solar-panel-pune.html': {
    eyebrow: 'Pune City Rooftop Solar Specialists',
    title: 'Solar Panel Installation in Pune',
    desc: 'Leading rooftop solar EPC for independent bungalows, housing societies, and businesses across Pune City. Get <span class="highlight-mark">₹78,000 PM Surya Ghar subsidy</span> and <span class="accent-underline">complete MSEDCL net metering</span>.',
    chips: ['Pune Citywide Site Survey', 'Tier-1 Mono PERC & TOPCon', 'MSEDCL Rasta Peth & Ganeshkhind Circles', '25-Year Performance Warranty'],
    rating: '⭐ 4.9/5 Rating (200+ Pune Installations)',
    subject: 'Pune City Solar Inquiry',
    pageName: 'solar-panel-pune',
    reqLabel: 'Property Type',
    options: ['Residential Rooftop Solar (3kW - 10kW)', 'Commercial Solar Installation', 'Society Common Meter Solar', 'Solar Maintenance & AMC'],
    btnText: 'Get Free Pune Solar Quote',
    replaceRegex: /<header\s+class=["']page-header["'][\s\S]*?<\/header>/i
  },
  'solar-panel-chakan.html': {
    eyebrow: 'Automotive & Heavy Engineering EPC',
    title: 'Solar Panel Installation in Chakan MIDC',
    desc: 'Turnkey industrial solar plants for factories, fabrication units, and logistics parks across <span class="highlight-mark">Chakan Phases 1 to 4</span>. Built with <span class="accent-underline">non-penetrative seam clamps</span> and 40% tax depreciation benefits.',
    chips: ['Chakan MIDC Phases 1, 2, 3, 4', 'Zero Roof Penetration Seam Clamps', '11kV/22kV HT Substation Sync', 'CEIG Clearances & Industrial AMC'],
    rating: '⭐ 4.9/5 Rating (Leading Chakan Industrial EPC)',
    subject: 'Chakan MIDC Solar Inquiry',
    pageName: 'solar-panel-chakan',
    reqLabel: 'Factory System Size',
    options: ['Factory Rooftop Solar (50kW - 250kW)', 'Mega Industrial Plant (250kW - 1MW+)', 'Industrial Solar AMC & Maintenance', 'Captive Solar Power Consultation'],
    btnText: 'Request Chakan MIDC Feasibility',
    replaceRegex: /<header\s+class=["']page-header["'][\s\S]*?<\/header>/i
  },
  'solar-panel-pimpri-chinchwad.html': {
    eyebrow: 'PCMC Residential & Commercial Hub',
    title: 'Solar Panel Installation in Pimpri Chinchwad',
    desc: 'High-efficiency rooftop solar installations for housing societies, bungalows, and commercial facilities across <span class="highlight-mark">PCMC</span>. Cut electricity bills by up to <span class="highlight-mark">90%</span> with <span class="accent-underline">PM Surya Ghar subsidy</span>.',
    chips: ['PCMC Municipal Corporation Approved', 'MSEDCL Bhosari & Pimpri Circles', '3kW to 10kW Residential Systems', 'Fast 48-Hour Mechanical Setup'],
    rating: '⭐ 4.9/5 Rating (PCMC Rooftop Solar)',
    subject: 'PCMC Solar Installation Inquiry',
    pageName: 'solar-panel-pimpri-chinchwad',
    reqLabel: 'PCMC Requirement',
    options: ['Residential Solar (3kW - 5kW)', 'Housing Society Common Meter Solar', 'Commercial Solar Installation', 'Solar Panel Cleaning & Maintenance'],
    btnText: 'Get PCMC Solar Quote',
    replaceRegex: /<header\s+class=["']page-header["'][\s\S]*?<\/header>/i
  },
  'solar-panel-baner-bavdhan.html': {
    eyebrow: 'Premium West Pune Architectural Solar',
    title: 'Solar Panel Installation in Baner & Bavdhan',
    desc: 'Custom architectural rooftop solar and <span class="highlight-mark">elevated pergolas</span> for luxury villas, row houses, and penthouses across <span class="highlight-mark">Baner, Bavdhan, Balewadi, and Pashan</span> with <span class="accent-underline">100% usable terrace retention</span>.',
    chips: ['Elevated Solar Gazebos & Pergolas', '100% Usable Terrace Area Retained', 'PM Surya Ghar ₹78,000 Subsidy', 'High-Density Bifacial Glass Modules'],
    rating: '⭐ 4.9/5 Rating (West Pune Luxury Homes)',
    subject: 'Baner & Bavdhan Solar Inquiry',
    pageName: 'solar-panel-baner-bavdhan',
    reqLabel: 'Terrace Structure Preference',
    options: ['Elevated Solar Pergola (Bungalow)', 'Standard Flush Rooftop Solar (3kW - 10kW)', 'Luxury Penthouse Hybrid System', 'Housing Society Solar System'],
    btnText: 'Book Baner & Bavdhan Site Survey',
    replaceRegex: /<header\s+class=["']page-header["'][\s\S]*?<\/header>/i
  },
  'solar-panel-bhosari-pcmc.html': {
    eyebrow: 'Fabrication & Machine Shop EPC',
    title: 'Industrial Solar Installation in Bhosari MIDC',
    desc: 'Engineered rooftop solar installations on trapezoidal metal sheets for machining workshops, plastic molders, and fabrication plants in <span class="highlight-mark">Bhosari MIDC & Moshi</span>. Maximize <span class="accent-underline">40% Section 32 tax savings</span>.',
    chips: ['Bhosari MIDC & Moshi Industrial Area', 'Non-Penetrative Metal Roof Clamps', '20kW to 250kW+ Commercial Range', 'Class-A Fire Rated Dual Earthing'],
    rating: '⭐ 4.9/5 Rating (Bhosari MIDC Industry Choice)',
    subject: 'Bhosari MIDC Solar Inquiry',
    pageName: 'solar-panel-bhosari-pcmc',
    reqLabel: 'Bhosari Plant Sizing',
    options: ['SME Workshop Solar (20kW - 50kW)', 'Industrial Shed EPC (50kW - 150kW)', 'Turnkey MIDC Plant (150kW+)', 'Solar Plant Maintenance & Cleaning'],
    btnText: 'Request Bhosari MIDC Survey',
    replaceRegex: /<header\s+class=["']page-header["'][\s\S]*?<\/header>/i
  },
  'solar-panel-kiwale.html': {
    eyebrow: 'Expressway Growth Corridor Specialists',
    title: 'Solar Panel Installation in Kiwale & Ravet',
    desc: 'Rooftop solar solutions for newly developed residential societies, row houses, and private bungalows along the <span class="highlight-mark">Pune-Mumbai Expressway</span> corridor in <span class="highlight-mark">Kiwale, Ravet, and Mamurdi</span>.',
    chips: ['High Solar Insolation (5.4 kWh/m²/day)', 'Fast-Track MSEDCL Net Metering', 'Direct DBT Subsidy up to ₹78,000', 'Local Ravet Office & Instant Support'],
    rating: '⭐ 4.9/5 Rating (Local Ravet / Kiwale Support)',
    subject: 'Kiwale & Ravet Solar Inquiry',
    pageName: 'solar-panel-kiwale',
    reqLabel: 'Kiwale / Ravet Requirement',
    options: ['Residential Solar 3kW (2-3 BHK)', 'Residential Solar 5kW (Row House)', 'Society Common Meter Solar', 'Solar Water Heater Combo'],
    btnText: 'Book Kiwale & Ravet Site Survey',
    replaceRegex: /<header\s+class=["']page-header["'][\s\S]*?<\/header>/i
  },
  'solar-panel-lonavala.html': {
    eyebrow: 'Resort & Luxury Villa Energy Solutions',
    title: 'Solar Panel Installation in Lonavala & Khandala',
    desc: 'Monsoon-rated on-grid and <span class="highlight-mark">hybrid solar battery systems</span> for vacation villas, second homes, and boutique resorts in <span class="highlight-mark">Lonavala and Khandala</span> with <span class="accent-underline">24/7 power independence</span>.',
    chips: ['Heavy Monsoon & Wind Load Engineering', 'Lithium Battery Hybrid Backup', 'Zero-Power Cut Remote Villa Living', 'Remote Cloud Monitoring from Pune/Mumbai'],
    rating: '⭐ 4.9/5 Rating (Luxury Villas & Resorts)',
    subject: 'Lonavala & Khandala Solar Inquiry',
    pageName: 'solar-panel-lonavala',
    reqLabel: 'Villa / Resort System Type',
    options: ['Hybrid Solar with Lithium Battery', 'On-Grid Luxury Villa Solar', 'Resort & Hotel Commercial Solar', 'Solar Water Heater for Cold Mornings'],
    btnText: 'Request Lonavala Villa Consultation',
    replaceRegex: /<header\s+class=["']page-header["'][\s\S]*?<\/header>/i
  },

  // --- Blog Pages ---
  'blog/index.html': {
    eyebrow: 'Technical Insights & Guides',
    title: 'Solar Insights, Technical Guides & Industry News',
    desc: 'In-depth analyses, equipment comparisons, PM Surya Ghar regulatory updates, and expert engineering guides from <span class="highlight-mark">certified solar professionals in Pune</span>.',
    chips: ['TOPCon vs PERC Physics', 'Bifacial Albedo Calculations', 'PM Surya Ghar DCR Rules', 'Inverter Sizing & Lithium Storage'],
    rating: '⭐ 4.9/5 Knowledge Rating (Pune Solar Hub)',
    subject: 'Solar Blog Consultation Request',
    pageName: 'blog-index',
    reqLabel: 'What is your solar project?',
    options: ['Residential Solar Consultation', 'Commercial Solar Sizing Assessment', 'Subsidy Guidance', 'General Engineering Inquiry'],
    btnText: 'Request Expert Solar Consultation',
    replaceRegex: /<header[\s\S]*?<\/header>/i
  },
  'blog/bifacial-solar-panels-pune.html': {
    eyebrow: 'Dual-Glass PV Technology',
    title: 'Bifacial Solar Panels in Pune: Boost Output by 25%',
    desc: 'Discover how dual-sided glass modules absorb front sunlight and ground albedo reflection to generate up to <span class="highlight-mark">25% more units</span> on <span class="accent-underline">Pune RCC terraces and industrial sheds</span>.',
    chips: ['Albedo Reflectance Calculations', '30-Year Extended Warranty Life', 'Elevated Structure Compatibility', 'Tier-1 Vikram & Adani Bifacial'],
    rating: '⭐ 4.9/5 Rating (Bifacial Technology Guide)',
    subject: 'Bifacial Solar Inquiry from Blog',
    pageName: 'bifacial-solar-panels-pune',
    reqLabel: 'Bifacial Project Interest',
    options: ['Bifacial Residential System (3kW-10kW)', 'Bifacial Industrial Rooftop (50kW+)', 'White Reflective Roof Coating Advice', 'Elevated Pergola with Bifacial'],
    btnText: 'Get Bifacial Solar Sizing Quote',
    replaceRegex: /<header\s+class=["']article-hero["'][\s\S]*?<\/header>/i
  },
  'blog/mono-perc-vs-topcon-solar-pune.html': {
    eyebrow: 'Next-Gen Cell Physics',
    title: 'Mono PERC vs. TOPCon Solar Panels in Pune',
    desc: 'Comparing the efficiency, temperature coefficient, and degradation rates of Mono PERC vs N-Type TOPCon cells. Learn why <span class="highlight-mark">TOPCon generates 5-7% more power</span> during <span class="accent-underline">hot 40°C Pune summers</span>.',
    chips: ['-0.30%/°C Temperature Coefficient', 'N-Type Zero LID Degradation', '22.5%+ Module Efficiency', 'Faster 3-Year Capital Payback'],
    rating: '⭐ 4.9/5 Rating (PV Cell Comparison Guide)',
    subject: 'TOPCon vs PERC Inquiry from Blog',
    pageName: 'mono-perc-vs-topcon-solar-pune',
    reqLabel: 'Panel Technology Preference',
    options: ['TOPCon Residential Rooftop System', 'Mono PERC Budget System', 'Commercial TOPCon Solar EPC', 'Comparison Sizing Sheet'],
    btnText: 'Request TOPCon Solar Sizing Quote',
    replaceRegex: /<header\s+class=["']article-hero["'][\s\S]*?<\/header>/i
  },
  'blog/dcr-solar-panels-pune.html': {
    eyebrow: 'PM Surya Ghar Compliance',
    title: 'DCR Solar Panels in Pune: The Mandatory Subsidy Rule',
    desc: 'Understand why <span class="highlight-mark">Domestic Content Requirement (DCR)</span> certified solar panels are legally mandatory to claim the <span class="highlight-mark">₹78,000 PM Surya Ghar subsidy</span> in Maharashtra.',
    chips: ['MNRE & ALMM Approved DCR Modules', 'Indian Manufactured Wafers & Cells', 'Mandatory for National Portal Subsidy', 'Tier-1 Vikram & Waaree DCR Stock'],
    rating: '⭐ 4.9/5 Rating (DCR Subsidy Compliance)',
    subject: 'DCR Solar Inquiry from Blog',
    pageName: 'dcr-solar-panels-pune',
    reqLabel: 'DCR Subsidy Sizing',
    options: ['3 kW DCR Subsidy Rooftop (Home)', '5 kW DCR Subsidy System (Villa)', 'Housing Society DCR Common Meter', 'DCR Subsidy Eligibility Check'],
    btnText: 'Claim DCR Subsidy Quotation',
    replaceRegex: /<header\s+class=["']article-hero["'][\s\S]*?<\/header>/i
  },
  'blog/hybrid-solar-system-lithium-battery-pune.html': {
    eyebrow: 'Energy Independence & Storage',
    title: 'Hybrid Solar System with Lithium Battery Pune',
    desc: 'Never suffer from power cuts again. High-voltage hybrid inverters paired with <span class="highlight-mark">LiFePO4 lithium batteries</span> provide <span class="accent-underline">seamless 10-millisecond backup</span> and grid-tied net metering.',
    chips: ['LiFePO4 6,000+ Cycle Battery Life', '10-Millisecond UPS Switching', 'MSEDCL Net Metering Synchronized', 'Zero Diesel Generator Fuel Costs'],
    rating: '⭐ 4.9/5 Rating (Lithium Storage Systems)',
    subject: 'Hybrid Battery Solar Inquiry from Blog',
    pageName: 'hybrid-solar-system-lithium-battery-pune',
    reqLabel: 'Hybrid Battery Size',
    options: ['Hybrid Solar 5kW + 5kWh Battery', 'Hybrid Solar 10kW + 10kWh Battery', 'Villa / Farmhouse Backup System', 'Commercial Hybrid Storage'],
    btnText: 'Get Hybrid Solar Battery Quote',
    replaceRegex: /<header\s+class=["']article-hero["'][\s\S]*?<\/header>/i
  },
  'blog/enphase-microinverter-installers-pune.html': {
    eyebrow: 'Module-Level Power Electronics',
    title: 'Enphase Microinverter Installers in Pune',
    desc: 'Eliminate string shading losses and fire hazards. Enphase microinverters convert power <span class="highlight-mark">panel-by-panel at safe 60V DC</span>, giving you <span class="accent-underline">independent per-panel monitoring</span>.',
    chips: ['Independent Per-Panel Optimization', 'Zero Single-Point System Failure', 'Safe 60V DC (Eliminates High-Voltage Arc)', '25-Year Manufacturer Warranty'],
    rating: '⭐ 4.9/5 Rating (Microinverter Specialist)',
    subject: 'Enphase Microinverter Inquiry from Blog',
    pageName: 'enphase-microinverter-installers-pune',
    reqLabel: 'Enphase Application',
    options: ['Enphase Residential System (3kW-10kW)', 'Complex / Multi-Directional Roof Setup', 'Microinverter Retrofit on Existing Solar', 'Technical Enphase Quotation'],
    btnText: 'Request Enphase Microinverter Quote',
    replaceRegex: /<header\s+class=["']article-hero["'][\s\S]*?<\/header>/i
  },
  'blog/on-grid-solar-inverter-dealers-pune.html': {
    eyebrow: 'Grid-Tied Power Electronics',
    title: 'On-Grid Solar Inverter Dealers in Pune',
    desc: 'A comprehensive buyer’s guide comparing <span class="highlight-mark">Growatt, Solis, Sungrow, Fronius, Havells, and Polycab</span> on-grid string inverters for Pune residential and commercial rooftops.',
    chips: ['98.6%+ Peak Conversion Efficiency', 'Multi-MPPT Dual String Architecture', 'Built-In Type-II Surge Protection', 'Real-Time WiFi & App Monitoring'],
    rating: '⭐ 4.9/5 Rating (Authorized Inverter Dealers)',
    subject: 'On-Grid Inverter Inquiry from Blog',
    pageName: 'on-grid-solar-inverter-dealers-pune',
    reqLabel: 'Inverter Capacity Range',
    options: ['Single Phase On-Grid Inverter (1kW-5kW)', 'Three Phase String Inverter (10kW-50kW)', 'Industrial Central/String Inverter (100kW+)', 'Inverter Replacement & Upgrade'],
    btnText: 'Get Inverter Pricing & Advice',
    replaceRegex: /<header\s+class=["']article-hero["'][\s\S]*?<\/header>/i
  },
  'blog/elevated-rooftop-solar-structure-pune.html': {
    eyebrow: 'Terrace Architecture & Usability',
    title: 'Elevated Rooftop Solar Structure Pune',
    desc: 'Preserve <span class="highlight-mark">100% of your terrace space</span> for yoga, stargazing, and family gatherings. Custom-engineered <span class="highlight-mark">solar pergolas (7–9.5 ft clearance)</span> that shade your top floor from 40°C heat.',
    chips: ['7.0 to 9.5 Ft Walking Clearance', '100% Terrace Living Area Preserved', 'Shields Top Floor (3°C–5°C Cooler)', 'Hot-Dip Galvanized & 150 km/h Wind Rated'],
    rating: '⭐ 4.9/5 Rating (Architectural Pergola Solar)',
    subject: 'Elevated Structure Inquiry from Blog',
    pageName: 'elevated-rooftop-solar-structure-pune',
    reqLabel: 'Terrace Pergola Type',
    options: ['Elevated Solar Gazebo / Pergola', 'High-Rise Terrace Canopy', 'Bungalow Walking Superstructure', 'Commercial Terrace Solar Pavilion'],
    btnText: 'Get Elevated Structure Design Quote',
    replaceRegex: /<section\s+style=["']background:\s*linear-gradient[\s\S]*?<\/section>/i
  },

  // --- Case Study Page ---
  'projects/eagle-burgmann-200kw-solar-pune.html': {
    eyebrow: 'Industrial Case Study Proof Asset',
    title: '200kW Industrial Rooftop Solar Project - Eagle Burgmann',
    desc: 'Turnkey industrial rooftop EPC executed for Eagle Burgmann India in Pune. Standing-seam <span class="highlight-mark">non-penetrative clamp mounting</span>, 11kV HT net metering, and <span class="accent-underline">₹22.5+ Lakhs annual power savings</span>.',
    chips: ['200.2 kWp DC Capacity', '~2,92,000 Annual kWh Units', 'Zero Roof Penetration Seam Clamps', '30-Day Turnkey Commissioning'],
    rating: '⭐ 4.9/5 Rating (Flagship Industrial EPC)',
    subject: 'Eagle Burgmann Case Study Consultation',
    pageName: 'eagle-burgmann-200kw-case-study',
    reqLabel: 'Industrial Project Inquiry',
    options: ['Industrial Solar Feasibility Audit', 'Factory Metal Roof Solar Assessment', 'HT Net Metering Consultation', 'Industrial Solar AMC & Maintenance'],
    btnText: 'Request Industrial Plant Audit',
    replaceRegex: /<header\s+class=["']hero-case-study["'][\s\S]*?<\/header>/i
  }
};

function generateSplitHeroHtml(config) {
  const chipsHtml = config.chips.map(chip => `
                    <div class="hero-feature-chip">
                        <i class="fas fa-check-circle"></i>
                        <span>${chip}</span>
                    </div>`).join('');

  const optionsHtml = config.options.map(opt => `
                                <option value="${opt}">${opt}</option>`).join('');

  return `    <!-- Top Split Hero Section with Quick Lead Form -->
    <header class="hero-split">
        <div class="container hero-split-grid">
            <!-- Left Column: High-Converting Headline, Highlights & Trust -->
            <div class="hero-split-left">
                <div class="hero-eyebrow-badge">
                    <i class="fas fa-bolt"></i>
                    <span>${config.eyebrow}</span>
                </div>
                <h1 class="hero-split-title">${config.title}</h1>
                <p class="hero-split-desc">${config.desc}</p>
                <div class="hero-feature-chips">${chipsHtml}
                </div>
                <div class="hero-trust-row">
                    <span>${config.rating}</span>
                    <span><i class="fas fa-shield-halved" style="color: #4ade80;"></i> MSEDCL Approved</span>
                    <span><i class="fas fa-award" style="color: #fbc02d;"></i> ISO 9001:2015</span>
                </div>
            </div>

            <!-- Right Column: Top High-Converting Quick Contact Form -->
            <div class="hero-split-right">
                <div class="hero-form-card">
                    <span class="form-badge-strip">FAST CALLBACK • 100% FREE SURVEY</span>
                    <h3>Get Instant Quote &amp; Advice</h3>
                    <div class="form-subtitle">Certified solar engineer callback within 15 minutes</div>
                    <form action="https://formspree.io/f/xbjnqkyw" method="POST" class="hero-quick-form">
                        <input type="hidden" name="_subject" value="${config.subject}">
                        <input type="hidden" name="_page" value="${config.pageName}">
                        
                        <div class="form-group-compact">
                            <label><i class="fas fa-user"></i> Full Name *</label>
                            <input type="text" name="name" required placeholder="Enter your full name">
                        </div>

                        <div class="form-group-compact">
                            <label><i class="fas fa-phone-alt"></i> Mobile / WhatsApp *</label>
                            <input type="tel" name="phone" required placeholder="Enter 10-digit mobile number">
                        </div>

                        <div class="form-row-2col">
                            <div class="form-group-compact">
                                <label><i class="fas fa-location-dot"></i> Area in Pune</label>
                                <input type="text" name="location" placeholder="e.g. Baner, Chakan">
                            </div>
                            <div class="form-group-compact">
                                <label><i class="fas fa-solar-panel"></i> ${config.reqLabel}</label>
                                <select name="requirement">${optionsHtml}
                                </select>
                            </div>
                        </div>

                        <button type="submit" class="btn-hero-form">
                            <span>${config.btnText}</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                        <div class="form-trust-footer">
                            <i class="fas fa-lock"></i> No Spam Guarantee • Direct Technical Assessment
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>`;
}

let updated = 0;

for (const [relPath, config] of Object.entries(heroConfigs)) {
  const fullPath = path.join(rootDir, relPath);
  if (!fs.existsSync(fullPath)) {
    console.warn(`File not found: ${relPath}`);
    continue;
  }

  let content = fs.readFileSync(fullPath, 'utf8');
  const splitHeroHtml = generateSplitHeroHtml(config);

  if (config.replaceRegex.test(content)) {
    content = content.replace(config.replaceRegex, splitHeroHtml);
    fs.writeFileSync(fullPath, content, 'utf8');
    console.log(`✅ Applied top split hero with form to: ${relPath}`);
    updated++;
  } else {
    console.warn(`⚠️ Regex match failed for: ${relPath}`);
  }
}

console.log(`\nSuccessfully injected top split hero with contact form into ${updated} pages!`);
