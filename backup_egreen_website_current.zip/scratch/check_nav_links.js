const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const files = fs.readdirSync(rootDir).filter(f => f.endsWith('.html'));

for (const file of files) {
    const content = fs.readFileSync(path.join(rootDir, file), 'utf8');
    const navMatch = content.match(/<ul\s+class=["'](?:mobile-)?nav-links["']>([\s\S]*?)<\/ul>/g);
    console.log(`\n=== ${file} ===`);
    if (navMatch) {
        navMatch.forEach(m => console.log(m.replace(/\s+/g, ' ').slice(0, 150)));
    } else {
        console.log('No nav-links found');
    }
}
