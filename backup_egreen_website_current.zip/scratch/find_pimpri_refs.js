const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const files = fs.readdirSync(ROOT).filter(f => f.endsWith('.html') || f.endsWith('.txt') || f.endsWith('.xml') || f.endsWith('.js'));
const blogFiles = fs.existsSync(path.join(ROOT, 'blog')) ? fs.readdirSync(path.join(ROOT, 'blog')).filter(f => f.endsWith('.html')).map(f => 'blog/' + f) : [];
const all = [...files, ...blogFiles];

const found = [];
all.forEach(file => {
    if (file === 'pimpri-chinchwad.html') return;
    const content = fs.readFileSync(path.join(ROOT, file), 'utf8');
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
        if (line.includes('/pimpri-chinchwad') && !line.includes('/solar-panel-pimpri-chinchwad')) {
            found.push(`${file}:${idx + 1} | ${line.trim()}`);
        }
    });
});

console.log('Total /pimpri-chinchwad (non-solar-panel) links:', found.length);
found.forEach(f => console.log(' ->', f));
