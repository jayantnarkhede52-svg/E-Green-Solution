const fs = require('fs');
const path = require('path');

function validateSeo(filePath) {
    const html = fs.readFileSync(filePath, 'utf8');
    const results = {
        passed: [],
        warnings: [],
        errors: []
    };

    // 1. Title Tag
    const titleMatch = html.match(/<title>([\s\S]*?)<\/title>/i);
    if (!titleMatch) {
        results.errors.push('Missing <title> tag');
    } else {
        const title = titleMatch[1].trim();
        const len = title.length;
        if (len < 30 || len > 65) {
            results.warnings.push(`Title length is ${len} chars (recommended: 45-65 chars): "${title}"`);
        } else {
            results.passed.push(`Title tag length optimal (${len} chars): "${title}"`);
        }

        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes('solar panel dealers pune') || (lowerTitle.includes('solar panel dealers') && lowerTitle.includes('pune'))) {
            results.passed.push('Title contains target keyword: "solar panel dealers pune"');
        } else {
            results.errors.push('Title missing keyword: "solar panel dealers pune"');
        }

        if (lowerTitle.includes('solar panel installations pune') || (lowerTitle.includes('solar panel installations') && lowerTitle.includes('pune')) || (lowerTitle.includes('solar installations') && lowerTitle.includes('pune'))) {
            results.passed.push('Title contains target keyword: "solar panel installations pune"');
        } else {
            results.errors.push('Title missing keyword: "solar panel installations pune"');
        }
    }

    // 2. Meta Description
    const descMatch = html.match(/<meta\s+name=["']description["']\s+content=["']([\s\S]*?)["']/i);
    if (!descMatch) {
        results.errors.push('Missing meta description');
    } else {
        const desc = descMatch[1].trim();
        const len = desc.length;
        if (len < 120 || len > 165) {
            results.warnings.push(`Meta description length is ${len} chars (recommended: 140-165 chars)`);
        } else {
            results.passed.push(`Meta description length optimal (${len} chars)`);
        }

        const lowerDesc = desc.toLowerCase();
        if (lowerDesc.includes('solar panel dealers pune') || (lowerDesc.includes('solar panel dealers') && lowerDesc.includes('pune'))) {
            results.passed.push('Meta description contains: "solar panel dealers pune"');
        } else {
            results.warnings.push('Meta description should include "solar panel dealers pune"');
        }

        if (lowerDesc.includes('solar panel installations pune') || (lowerDesc.includes('solar panel installations') && lowerDesc.includes('pune'))) {
            results.passed.push('Meta description contains: "solar panel installations pune"');
        } else {
            results.warnings.push('Meta description should include "solar panel installations pune"');
        }
    }

    // 3. Headings
    const h1Matches = [...html.matchAll(/<h1[^>]*>([\s\S]*?)<\/h1>/gi)];
    if (h1Matches.length === 0) {
        results.errors.push('Missing <h1> tag');
    } else if (h1Matches.length > 1) {
        results.warnings.push(`Multiple <h1> tags found (${h1Matches.length}). Best practice is 1 primary <h1>.`);
    } else {
        const h1Text = h1Matches[0][1].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
        results.passed.push(`Single <h1> found: "${h1Text}"`);
        const lowerH1 = h1Text.toLowerCase();
        if (lowerH1.includes('solar panel dealers') && lowerH1.includes('pune')) {
            results.passed.push('H1 contains "solar panel dealers pune" keyword entity');
        }
        if (lowerH1.includes('solar panel installations') || lowerH1.includes('solar installations')) {
            results.passed.push('H1 contains "solar panel installations" keyword entity');
        }
    }

    // 4. Keyword Frequencies in Body
    const cleanText = html
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ')
        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .toLowerCase();

    function count(str, sub) {
        let c = 0, pos = 0;
        while ((pos = str.indexOf(sub, pos)) !== -1) { c++; pos += sub.length; }
        return c;
    }

    const kwDealers = count(cleanText, 'solar panel dealers pune');
    const kwDealersIn = count(cleanText, 'solar panel dealers in pune');
    const kwInstallations = count(cleanText, 'solar panel installations pune');
    const kwInstallationsIn = count(cleanText, 'solar panel installations in pune');

    results.passed.push(`Keyword "solar panel dealers pune": ${kwDealers} exact matches (${kwDealersIn} with 'in')`);
    results.passed.push(`Keyword "solar panel installations pune": ${kwInstallations} exact matches (${kwInstallationsIn} with 'in')`);

    // 5. Image Alt attributes
    const imgMatches = [...html.matchAll(/<img\b([^>]*)>/gi)];
    let missingAlt = 0;
    imgMatches.forEach(img => {
        const altMatch = img[1].match(/alt=["']([^"']*)["']/i);
        if (!altMatch || altMatch[1].trim() === '') missingAlt++;
    });
    if (missingAlt > 0) {
        results.errors.push(`${missingAlt} image(s) missing alt text`);
    } else {
        results.passed.push(`All ${imgMatches.length} images have non-empty alt text`);
    }

    // 6. JSON-LD Structured Data
    const schemas = [...html.matchAll(/<script\s+type=["']application\/ld\+json["']>([\s\S]*?)<\/script>/gi)];
    results.passed.push(`Found ${schemas.length} JSON-LD structured data scripts`);
    schemas.forEach((s, idx) => {
        try {
            const json = JSON.parse(s[1].trim());
            const type = json['@type'] || (json['@graph'] ? 'Graph' : 'Unknown');
            results.passed.push(`JSON-LD #${idx+1} valid syntax: @type=${type}`);
        } catch(err) {
            results.errors.push(`JSON-LD #${idx+1} syntax error: ${err.message}`);
        }
    });

    return results;
}

const res = validateSeo(path.join(__dirname, '..', 'index.html'));
console.log('\n=== CURRENT VALIDATION RESULTS ===');
console.log('PASSED:', res.passed.length);
res.passed.forEach(p => console.log('  [PASS]', p));
console.log('\nWARNINGS:', res.warnings.length);
res.warnings.forEach(w => console.log('  [WARN]', w));
console.log('\nERRORS:', res.errors.length);
res.errors.forEach(e => console.log('  [FAIL]', e));
