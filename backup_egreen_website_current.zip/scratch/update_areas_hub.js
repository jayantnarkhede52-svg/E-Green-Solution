const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'areas.html');
let html = fs.readFileSync(filePath, 'utf8');

// 1. Add CSS for .area-card-thumb
const oldCssMarker = '.areas-grid { display: grid;';
const newCss = `.area-card-thumb { height: 180px; margin: -36px -30px 20px -30px; overflow: hidden; position: relative; background: #f1f5f9; border-bottom: 1px solid #e2e8f0; }
        .area-card-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform 0.4s ease; }
        .area-card:hover .area-card-thumb img { transform: scale(1.06); }
        .area-badge-overlay { position: absolute; bottom: 12px; left: 16px; margin: 0; box-shadow: 0 4px 12px rgba(0,0,0,0.18); font-size: 11.5px; font-weight: 700; padding: 4px 12px; border-radius: 20px; }
        .areas-grid { display: grid;`;

if (!html.includes('.area-card-thumb {')) {
  html = html.replace(oldCssMarker, newCss);
}

// 2. Wrap main content with <main id="main-content">
if (!html.includes('<main id="main-content">')) {
  html = html.replace('<header class="page-header"', '<main id="main-content">\n    <header class="page-header"');
  html = html.replace('</section>\n\n    <!-- Footer -->', '</section>\n    </main>\n\n    <!-- Footer -->');
}

// 3. Update the 10 directory cards with rich thumbnails and proper structure
const oldGridRegex = /<!-- Comprehensive 10-Hub Service Areas Directory Grid -->[\s\S]*?<\/div>(\s*<!-- Anti-Cannibalization Anchor Box)/i;

const newGridContent = `<!-- Comprehensive 10-Hub Service Areas Directory Grid -->
            <div class="areas-grid" id="areasGrid">

                <!-- 1. Pune City Central (Links to /solar-panel-pune) -->
                <div class="area-card" data-category="central">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/areas/solar-pune.png" alt="Rooftop Solar in Pune City Central" width="1024" height="1024" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #dbeafe; color: #1e40af;">PMC Urban Zone</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-city"></i></div>
                            <div>
                                <h3>Pune City Central</h3>
                                <span class="area-badge">Shivajinagar, Kothrud, Deccan</span>
                            </div>
                        </div>
                        <p>Turnkey rooftop solar installations for independent bungalows, heritage properties, and residential societies across Shivajinagar, Deccan Gymkhana, Swargate, Model Colony, and Camp.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-bolt"></i> <strong>MSEDCL Circle:</strong> Rasta Peth &amp; Ganeshkhind Urban</li>
                            <li><i class="fas fa-house"></i> <strong>Popular Systems:</strong> 3kW - 10kW On-Grid Mono PERC</li>
                            <li><i class="fas fa-clock"></i> <strong>Sanction Timeline:</strong> 12 - 16 Business Days</li>
                        </ul>
                    </div>
                    <a href="/solar-panel-pune" class="area-link">Explore Pune City Solar Hub <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 2. Chakan MIDC Industrial (Links to /solar-panel-chakan) -->
                <div class="area-card" data-category="industrial">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/areas/solar-chakan.png" alt="Industrial Solar EPC in Chakan MIDC" width="1024" height="1024" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #fef3c7; color: #92400e;">Automotive &amp; Industrial</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-industry"></i></div>
                            <div>
                                <h3>Chakan MIDC</h3>
                                <span class="area-badge" style="background: #fef3c7; color: #92400e;">Phases 1-4 &amp; Kuruli</span>
                            </div>
                        </div>
                        <p>Specialized megawatt-scale industrial solar EPC and captive rooftop solar power plants for manufacturing plants, stamping units, and logistics parks across Chakan Phases 1 to 4.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-bolt"></i> <strong>Grid Level:</strong> 11kV / 22kV / 33kV HT Synchronization</li>
                            <li><i class="fas fa-chart-line"></i> <strong>Commercial Benefit:</strong> 40% Accelerated Tax Depreciation</li>
                            <li><i class="fas fa-shield-halved"></i> <strong>Modules:</strong> Tier-1 Bifacial Dual-Glass Panels</li>
                        </ul>
                    </div>
                    <a href="/solar-panel-chakan" class="area-link">Explore Chakan Industrial Solar <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 3. Pimpri Chinchwad (Links to /solar-panel-pimpri-chinchwad) -->
                <div class="area-card" data-category="pcmc">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/areas/solar-pcmc.png" alt="Rooftop Solar in Pimpri Chinchwad PCMC" width="1024" height="1024" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #dcfce7; color: #166534;">Smart City Zone</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-building"></i></div>
                            <div>
                                <h3>Pimpri Chinchwad (PCMC)</h3>
                                <span class="area-badge" style="background: #dcfce7; color: #166534;">Nigdi, Pradhikaran, Akurdi</span>
                            </div>
                        </div>
                        <p>High-efficiency rooftop solar installations for residential apartment societies, small commercial establishments, and mid-sized industrial units throughout the twin smart city of PCMC.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-bolt"></i> <strong>MSEDCL Circle:</strong> Bhosari Urban Circle</li>
                            <li><i class="fas fa-hand-holding-dollar"></i> <strong>Subsidy:</strong> PM Surya Ghar direct credit up to ₹78k</li>
                            <li><i class="fas fa-award"></i> <strong>Incentives:</strong> PCMC Property Tax Green Concessions</li>
                        </ul>
                    </div>
                    <a href="/solar-panel-pimpri-chinchwad" class="area-link">Explore PCMC Solar Solutions <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 4. Baner & Bavdhan (Links to /solar-panel-baner-bavdhan) -->
                <div class="area-card" data-category="west">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/areas/solar-baner-bavdhan.png" alt="Rooftop Solar in Baner and Bavdhan" width="1024" height="1024" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #e0e7ff; color: #3730a3;">West Pune Residential</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-house-chimney"></i></div>
                            <div>
                                <h3>Baner &amp; Bavdhan</h3>
                                <span class="area-badge">Balewadi &amp; Pashan</span>
                            </div>
                        </div>
                        <p>Premium rooftop solar systems engineered for upscale row houses, luxury duplex penthouses, and gated high-rise societies in Baner, Bavdhan, Balewadi, and Pashan.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-bolt"></i> <strong>Feasibility:</strong> 9-Ft Elevated Terrace Pergolas</li>
                            <li><i class="fas fa-leaf"></i> <strong>Bill Reduction:</strong> Up to 90% Savings on Domestic Tariffs</li>
                            <li><i class="fas fa-mobile-screen"></i> <strong>Monitoring:</strong> WiFi-enabled Solar Inverter Tracking</li>
                        </ul>
                    </div>
                    <a href="/solar-panel-baner-bavdhan" class="area-link">Explore West Pune Solar Hub <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 5. Hinjewadi & Wakad (IT Corridor Hub) -->
                <div class="area-card" data-category="west">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/services/commercial_solar_pune.jpg" alt="Commercial Solar in Hinjewadi & Wakad IT Corridor" width="1376" height="768" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #e0e7ff; color: #3730a3;">IT Tech Park Corridor</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-laptop-code"></i></div>
                            <div>
                                <h3>Hinjewadi &amp; Wakad</h3>
                                <span class="area-badge" style="background: #e0e7ff; color: #3730a3;">Phases 1-3 &amp; Punawale</span>
                            </div>
                        </div>
                        <p>Complete solar energy solutions for tech park commercial campuses, corporate offices, and sprawling residential townships across Hinjewadi Phases 1, 2, 3, Wakad, and Punawale.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-building-user"></i> <strong>Society Rooftops:</strong> Common Meter Solar for Lifts &amp; Pumps</li>
                            <li><i class="fas fa-bolt"></i> <strong>Net Metering:</strong> MSEDCL Hinjewadi Substation Fast-Track</li>
                            <li><i class="fas fa-money-bill-trend-up"></i> <strong>Payback:</strong> Estimated 3.0 to 3.4 Years</li>
                        </ul>
                    </div>
                    <a href="/contact" class="area-link">Book Hinjewadi Site Survey <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 6. Bhosari MIDC & PCMC Industrial (Links to /solar-panel-bhosari-pcmc) -->
                <div class="area-card" data-category="industrial">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/areas/solar-bhosari.png" alt="Industrial Solar in Bhosari MIDC" width="1024" height="1024" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #fef3c7; color: #92400e;">SME &amp; Fabrication Hub</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-gears"></i></div>
                            <div>
                                <h3>Bhosari &amp; PCMC MIDC</h3>
                                <span class="area-badge" style="background: #fef3c7; color: #92400e;">Telco Road &amp; S Block</span>
                            </div>
                        </div>
                        <p>Tailored rooftop solar plants on trapezoidal metal sheets and shed roofs for machine shops, plastic injection molders, and fabrication factories in Bhosari and Moshi.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-hammer"></i> <strong>Installation:</strong> Non-Penetrative Metal Roof Clamps</li>
                            <li><i class="fas fa-chart-line"></i> <strong>Tax Shield:</strong> 40% First-Year Accelerated Depreciation</li>
                            <li><i class="fas fa-file-shield"></i> <strong>Safety:</strong> Class-A Fire Rated Dual Earthing Protection</li>
                        </ul>
                    </div>
                    <a href="/solar-panel-bhosari-pcmc" class="area-link">Explore Bhosari Solar Plant EPC <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 7. Kiwale & Ravet (Links to /solar-panel-kiwale) -->
                <div class="area-card" data-category="pcmc">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/areas/solar-kiwale.png" alt="Rooftop Solar in Kiwale, Ravet & Mamurdi" width="1024" height="1024" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #dcfce7; color: #166534;">Expressway Growth Corridor</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-solar-panel"></i></div>
                            <div>
                                <h3>Kiwale, Ravet &amp; Mamurdi</h3>
                                <span class="area-badge">MCA Stadium Belt</span>
                            </div>
                        </div>
                        <p>Serving rapidly developing residential societies and individual private bungalows along the Pune-Mumbai Expressway corridor with cost-effective on-grid solar solutions.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-sun"></i> <strong>Sun Exposure:</strong> High Solar Irradiance 5.4 kWh/m²/day</li>
                            <li><i class="fas fa-certificate"></i> <strong>Govt. Subsidy:</strong> National Portal Direct Bank Transfer</li>
                            <li><i class="fas fa-truck-fast"></i> <strong>Turnaround:</strong> 2-Day Complete Roof Mechanical Setup</li>
                        </ul>
                    </div>
                    <a href="/solar-panel-kiwale" class="area-link">Explore Kiwale Solar Solutions <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 8. Kharadi, Viman Nagar & Magarpatta -->
                <div class="area-card" data-category="east">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/services/commercial_solar.png" alt="Commercial Rooftop Solar in Kharadi & Hadapsar" width="1024" height="1024" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #fef3c7; color: #92400e;">East Pune IT &amp; Commercial</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-briefcase"></i></div>
                            <div>
                                <h3>Kharadi, Viman Nagar &amp; Hadapsar</h3>
                                <span class="area-badge">EON IT Park &amp; Magarpatta</span>
                            </div>
                        </div>
                        <p>High-efficiency rooftop solar installations for commercial buildings, tech parks, hospitals, and residential complexes across Nagar Road, EON IT Park, Magarpatta City, and Wagholi.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-bolt"></i> <strong>MSEDCL Circle:</strong> Rasta Peth - Nagar Road Division</li>
                            <li><i class="fas fa-building-columns"></i> <strong>Commercial Solar:</strong> CapEx &amp; Zero-Investment OPEX Models</li>
                            <li><i class="fas fa-chart-pie"></i> <strong>Power Offsetting:</strong> 70% to 90% Peak Load Reduction</li>
                        </ul>
                    </div>
                    <a href="/contact" class="area-link">Book East Pune Site Survey <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 9. Kothrud, Karve Nagar & Sinhagad Road -->
                <div class="area-card" data-category="central">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/blog/elevated_rooftop_solar_structure_pune.jpg" alt="Rooftop Solar Pergola in Kothrud & Karve Nagar" width="1376" height="768" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #dbeafe; color: #1e40af;">Established Residential Hub</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-tree-city"></i></div>
                            <div>
                                <h3>Kothrud, Karve Nagar &amp; Warje</h3>
                                <span class="area-badge">Erandwane &amp; Sinhagad Rd</span>
                            </div>
                        </div>
                        <p>Expert rooftop installations for traditional housing societies, independent family villas, and commercial retail showrooms across Kothrud, Karve Nagar, Erandwane, and Sinhagad Road.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-bolt"></i> <strong>MSEDCL Circle:</strong> Kothrud Division Substation</li>
                            <li><i class="fas fa-layer-group"></i> <strong>Structures:</strong> Elevated Superstructures for Terrace Usage</li>
                            <li><i class="fas fa-shield"></i> <strong>Corrosion Proof:</strong> Hot-Dip Galvanized Iron Framing</li>
                        </ul>
                    </div>
                    <a href="/contact" class="area-link">Book Kothrud Solar Survey <i class="fas fa-arrow-right"></i></a>
                </div>

                <!-- 10. Lonavala & Khandala (Links to /solar-panel-lonavala) -->
                <div class="area-card" data-category="villas">
                    <div>
                        <div class="area-card-thumb">
                            <img src="/assets/areas/solar-lonavala.png" alt="Hybrid Solar in Lonavala & Khandala Villas and Resorts" width="1024" height="1024" loading="lazy" decoding="async">
                            <span class="area-badge-overlay" style="background: #f1f5f9; color: #0f172a;">Resorts &amp; Luxury Villas</span>
                        </div>
                        <div class="area-card-header">
                            <div class="area-card-icon"><i class="fas fa-mountain-sun"></i></div>
                            <div>
                                <h3>Lonavala &amp; Khandala</h3>
                                <span class="area-badge" style="background: #f1f5f9; color: #0f172a;">Tungarli &amp; Ryewood</span>
                            </div>
                        </div>
                        <p>Hybrid and battery-backed solar power plants designed for luxury vacation bungalows, boutique resorts, and second homes facing seasonal grid outages in the Sahyadri hills.</p>
                        <ul class="area-meta-list">
                            <li><i class="fas fa-car-battery"></i> <strong>Inverter Type:</strong> Smart Hybrid Inverters with LiFePO4 Storage</li>
                            <li><i class="fas fa-cloud-bolt"></i> <strong>Weatherproofing:</strong> Heavy Monsoon &amp; Wind Resistant Mounts</li>
                            <li><i class="fas fa-tower-broadcast"></i> <strong>Remote Monitoring:</strong> 4G Remote Health Diagnostics</li>
                        </ul>
                    </div>
                    <a href="/solar-panel-lonavala" class="area-link">Explore Lonavala Solar Solutions <i class="fas fa-arrow-right"></i></a>
                </div>

            </div>$1`;

html = html.replace(oldGridRegex, newGridContent);

// 4. Add Flagship Case Studies Showcase right before the Municipal Zoning table
const caseStudySection = `
            <!-- Flagship Landmark Case Studies Across Pune District -->
            <div style="margin-top: 70px;">
                <div style="text-align: center; max-width: 850px; margin: 0 auto 35px;">
                    <span style="color: var(--primary); font-weight: 700; text-transform: uppercase; letter-spacing: 1px; font-size: 13px;">Verified On-Site Performance</span>
                    <h2 style="font-size: 32px; color: var(--text-dark); margin: 8px 0 14px;">Flagship Solar Installations Across Pune &amp; PCMC</h2>
                    <p style="font-size: 16px; color: #64748b; line-height: 1.7;">Explore our landmark commercial, housing society, and industrial solar projects delivering verified 90% power bill reductions.</p>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 30px;">
                    <!-- Case Study 1: Konark A Plus 100kW -->
                    <div style="background: #fff; border-radius: 20px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 8px 25px rgba(0,0,0,0.06); display: flex; flex-direction: column;">
                        <div style="height: 220px; overflow: hidden; position: relative;">
                            <img src="/assets/projects/konark_society_rooftop_100kw.jpg" alt="100kW Rooftop Solar Installation at Konark A Plus Housing Society Sopan Baug Pune" width="1280" height="720" loading="lazy" decoding="async" style="width: 100%; height: 100%; object-fit: cover;">
                            <span style="position: absolute; top: 14px; left: 16px; background: #2e7d32; color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700;">100 kW Residential GHS</span>
                        </div>
                        <div style="padding: 25px; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
                            <div>
                                <h3 style="font-size: 20px; color: #0f172a; margin-bottom: 8px;">Konark A Plus Housing Society</h3>
                                <p style="font-size: 14px; color: #64748b; margin-bottom: 12px;"><i class="fas fa-location-dot" style="color: var(--primary);"></i> Sopan Baug, Pune City</p>
                                <p style="font-size: 14.5px; color: #475569; line-height: 1.6; margin-bottom: 16px;">
                                    Generates 12,000+ units monthly for campus elevators, water pumping, and common lighting. Slashed monthly bills from ₹3.2+ Lakhs down by 90% with ₹18 Lakhs central subsidy.
                                </p>
                            </div>
                            <a href="/projects/konark-a-plus-100kw-housing-society-solar-pune" class="btn-primary" style="padding: 10px 20px; font-size: 14px; text-decoration: none; text-align: center;">View 100kW Case Study &rarr;</a>
                        </div>
                    </div>

                    <!-- Case Study 2: EagleBurgmann 200kW -->
                    <div style="background: #fff; border-radius: 20px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 8px 25px rgba(0,0,0,0.06); display: flex; flex-direction: column;">
                        <div style="height: 220px; overflow: hidden; position: relative;">
                            <img src="/assets/projects/eagle_burgmann.png" alt="200kW Industrial Rooftop Solar for EagleBurgmann India" width="1024" height="1024" loading="lazy" decoding="async" style="width: 100%; height: 100%; object-fit: cover;">
                            <span style="position: absolute; top: 14px; left: 16px; background: #0288d1; color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700;">200 kW Industrial EPC</span>
                        </div>
                        <div style="padding: 25px; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
                            <div>
                                <h3 style="font-size: 20px; color: #0f172a; margin-bottom: 8px;">EagleBurgmann India Pvt. Ltd.</h3>
                                <p style="font-size: 14px; color: #64748b; margin-bottom: 12px;"><i class="fas fa-industry" style="color: #0288d1;"></i> Bhosari Industrial Belt, Pune</p>
                                <p style="font-size: 14.5px; color: #475569; line-height: 1.6; margin-bottom: 16px;">
                                    Captive industrial rooftop solar power plant eliminating 22,000+ peak daytime units monthly. 100% non-penetrative standing seam clamps and 40% first-year tax depreciation shield.
                                </p>
                            </div>
                            <a href="/projects/eagle-burgmann-200kw-solar-pune" class="btn-primary" style="padding: 10px 20px; font-size: 14px; text-decoration: none; text-align: center; background: #0288d1;">View 200kW Industrial Case Study &rarr;</a>
                        </div>
                    </div>
                </div>
            </div>
`;

if (!html.includes('Konark A Plus Housing Society') && html.includes('Municipal Zoning & Regulatory Breakdown')) {
  html = html.replace('<!-- Municipal Zoning & Regulatory Breakdown', caseStudySection + '\n            <!-- Municipal Zoning & Regulatory Breakdown');
}

fs.writeFileSync(filePath, html, 'utf8');
console.log('Successfully updated areas.html');
