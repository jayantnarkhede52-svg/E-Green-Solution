const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const files = fs.readdirSync(root).filter(f => f.endsWith('.html'));
const blogFiles = fs.existsSync(path.join(root, 'blog'))
  ? fs.readdirSync(path.join(root, 'blog')).filter(f => f.endsWith('.html')).map(f => 'blog/' + f)
  : [];
const allHtml = [...files, ...blogFiles];

const missing = [];
const linkRegex = /href=["'](\/[^"'#?]*)/g;

for (const rel of allHtml) {
  const content = fs.readFileSync(path.join(root, rel), 'utf8');
  let match;
  while ((match = linkRegex.exec(content)) !== null) {
    const target = match[1];
    if (target === '/' || target === '') continue;
    const cleanTarget = target.startsWith('/') ? target.slice(1) : target;
    const directFile = path.join(root, cleanTarget);
    const htmlFile = path.join(root, cleanTarget + '.html');
    const indexFile = path.join(root, cleanTarget, 'index.html');
    if (!fs.existsSync(directFile) && !fs.existsSync(htmlFile) && !fs.existsSync(indexFile)) {
      missing.push({ source: rel, target });
    }
  }
}
console.log('Total internal links checked across ' + allHtml.length + ' files.');
console.log('Missing/broken link references count:', missing.length);
if (missing.length > 0) {
  console.log(JSON.stringify(missing, null, 2));
}
