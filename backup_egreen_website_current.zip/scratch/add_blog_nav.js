const fs = require('fs');
const path = require('path');

const rootDir = 'c:\\work\\E GREEN WEBSITE';
const files = fs.readdirSync(rootDir).filter(f => f.endsWith('.html') && f !== 'solar-hero.html');

let modifiedCount = 0;

for (const file of files) {
    const filePath = path.join(rootDir, file);
    let content = fs.readFileSync(filePath, 'utf8');
    let original = content;

    // 1. Desktop nav-links: Add Blog after Services if not already present
    // Match <li><a href="/services"[^>]*>Services</a></li>
    content = content.replace(/(<ul[^>]*class=["']nav-links["'][^>]*>[\s\S]*?<li><a href="\/services"[^>]*>Services<\/a><\/li>)(?![\s\S]*?<li><a href="\/blog")/i, (match, p1) => {
        return p1 + '\n                <li><a href="/blog">Blog</a></li>';
    });

    // 2. Mobile nav-links: Add Blog after Services if not already present
    content = content.replace(/(<ul[^>]*class=["']mobile-nav-links["'][^>]*>[\s\S]*?<li><a href="\/services"[^>]*>Services<\/a><\/li>)(?![\s\S]*?<li><a href="\/blog")/i, (match, p1) => {
        return p1 + '\n                    <li><a href="/blog">Blog</a></li>';
    });

    // 3. Quick Links in footer: Add Blog after Services if not already present
    content = content.replace(/(<h3>Quick Links<\/h3>\s*<ul[^>]*>[\s\S]*?<li><a href="\/services"[^>]*>Services<\/a><\/li>)(?![\s\S]*?<li><a href="\/blog")/i, (match, p1) => {
        return p1 + '\n                    <li><a href="/blog">Blog</a></li>';
    });

    if (content !== original) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Updated nav & quick links in: ${file}`);
        modifiedCount++;
    } else {
        console.log(`No changes made to: ${file}`);
    }
}

console.log(`Total files updated: ${modifiedCount}`);
