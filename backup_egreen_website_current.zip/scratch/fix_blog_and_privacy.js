const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');

// 1. Fix blog/index.html
const blogIndexPath = path.join(rootDir, 'blog', 'index.html');
let blogContent = fs.readFileSync(blogIndexPath, 'utf8');

blogContent = blogContent.replace(
  /<title>[\s\S]*?<\/title>/i,
  '<title>Solar Insights & Technical Guides | E Green Solution Blog Pune</title>'
);

blogContent = blogContent.replace(
  /<meta\s+name=["']description["']\s+content=["'][\s\S]*?["']/i,
  '<meta name="description" content="Expert rooftop solar insights, technology comparisons, subsidy updates, and technical guides for homeowners and commercial businesses in Pune.">'
);

blogContent = blogContent.replace(
  /<h1[^>]*>[\s\S]*?<\/h1>/i,
  '<h1 style="font-size: 42px; margin-bottom: 18px; font-weight: 800; line-height: 1.2;">Solar Insights, Technical Guides &amp; Industry News</h1>'
);

fs.writeFileSync(blogIndexPath, blogContent, 'utf8');
console.log('Fixed blog/index.html Title, Description, and H1!');

// 2. Fix privacy-policy.html canonical
const privacyPath = path.join(rootDir, 'privacy-policy.html');
let privacyContent = fs.readFileSync(privacyPath, 'utf8');

if (!privacyContent.includes('<link rel="canonical"')) {
  privacyContent = privacyContent.replace(
    '</title>',
    '</title>\n    <link rel="canonical" href="https://egreensolution.in/privacy-policy">'
  );
  fs.writeFileSync(privacyPath, privacyContent, 'utf8');
  console.log('Added canonical link to privacy-policy.html!');
}
