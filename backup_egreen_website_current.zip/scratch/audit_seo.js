const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');

console.log('=== SEO AUDIT OF INDEX.HTML ===');
console.log('File size (bytes):', html.length);

// 1. Title
const titleMatch = html.match(/<title>([\s\S]*?)<\/title>/i);
const title = titleMatch ? titleMatch[1].trim() : 'NONE';
console.log('TITLE:', title);
console.log('TITLE LENGTH:', title.length);

// 2. Meta Description
const descMatch = html.match(/<meta\s+name=["']description["']\s+content=["']([\s\S]*?)["']/i);
const desc = descMatch ? descMatch[1].trim() : 'NONE';
console.log('META DESC:', desc);
console.log('META DESC LENGTH:', desc.length);

// 3. Meta Keywords
const kwMatch = html.match(/<meta\s+name=["']keywords["']\s+content=["']([\s\S]*?)["']/i);
console.log('META KEYWORDS:', kwMatch ? kwMatch[1].trim() : 'NONE');

// 4. Canonical
const canonicalMatch = html.match(/<link\s+rel=["']canonical["']\s+href=["']([\s\S]*?)["']/i);
console.log('CANONICAL:', canonicalMatch ? canonicalMatch[1].trim() : 'NONE');

// 5. OpenGraph & Twitter
const ogTitle = html.match(/<meta\s+property=["']og:title["']\s+content=["']([\s\S]*?)["']/i);
const ogDesc = html.match(/<meta\s+property=["']og:description["']\s+content=["']([\s\S]*?)["']/i);
console.log('OG:TITLE:', ogTitle ? ogTitle[1].trim() : 'NONE');
console.log('OG:DESC:', ogDesc ? ogDesc[1].trim() : 'NONE');

// 6. Headings Analysis
const h1Matches = [...html.matchAll(/<h1[^>]*>([\s\S]*?)<\/h1>/gi)];
console.log('\n--- HEADINGS ---');
console.log('H1 COUNT:', h1Matches.length);
h1Matches.forEach((m, i) => console.log(`H1 #${i+1}: ${m[1].replace(/<[^>]+>/g, '').trim()}`));

const h2Matches = [...html.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/gi)];
console.log('H2 COUNT:', h2Matches.length);
h2Matches.forEach((m, i) => console.log(`H2 #${i+1}: ${m[1].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()}`));

const h3Matches = [...html.matchAll(/<h3[^>]*>([\s\S]*?)<\/h3>/gi)];
console.log('H3 COUNT:', h3Matches.length);
h3Matches.slice(0, 10).forEach((m, i) => console.log(`H3 #${i+1}: ${m[1].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()}`));

// 7. Keyword Frequencies
const rawText = html
  .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ')
  .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ')
  .replace(/<[^>]+>/g, ' ')
  .replace(/\s+/g, ' ')
  .toLowerCase();

function countOccurrences(str, sub) {
    let count = 0, pos = 0;
    while ((pos = str.indexOf(sub, pos)) !== -1) { count++; pos += sub.length; }
    return count;
}

const words = rawText.split(/\s+/).filter(Boolean);
console.log('\n--- WORD COUNT & KEYWORD FREQUENCIES ---');
console.log('Total visible words (approx):', words.length);

const targetKeywords = [
    'solar panel dealers pune',
    'solar panel dealers in pune',
    'solar panel installations pune',
    'solar panel installation pune',
    'solar panel installation in pune',
    'solar panel installer in pune',
    'solar installers pune',
    'solar dealers in pune',
    'dealers',
    'installations',
    'installation',
    'pune'
];

targetKeywords.forEach(kw => {
    console.log(`Keyword "${kw}": ${countOccurrences(rawText, kw)} matches`);
});

// 8. Image Alt Tags
const imgMatches = [...html.matchAll(/<img\b([^>]*)>/gi)];
console.log('\n--- IMAGES AUDIT ---');
console.log('Total images found:', imgMatches.length);
let emptyAlt = 0;
let missingAlt = 0;
imgMatches.forEach((img, idx) => {
    const srcMatch = img[1].match(/src=["']([^"']*)["']/i);
    const altMatch = img[1].match(/alt=["']([^"']*)["']/i);
    const src = srcMatch ? srcMatch[1] : 'unknown';
    const alt = altMatch ? altMatch[1] : null;

    if (alt === null) {
        missingAlt++;
        console.log(`[MISSING ALT] ${src}`);
    } else if (alt.trim() === '') {
        emptyAlt++;
        console.log(`[EMPTY ALT] ${src}`);
    }
});
console.log(`Summary: Missing alt: ${missingAlt}, Empty alt: ${emptyAlt}`);

// 9. Schema Markup Audit
const schemaMatches = [...html.matchAll(/<script\s+type=["']application\/ld\+json["']>([\s\S]*?)<\/script>/gi)];
console.log('\n--- STRUCTURED DATA (JSON-LD) ---');
console.log('Total schemas found:', schemaMatches.length);
schemaMatches.forEach((s, idx) => {
    try {
        const parsed = JSON.parse(s[1].trim());
        const type = parsed['@type'] || (parsed['@graph'] ? 'Graph' : 'Unknown');
        console.log(`Schema #${idx+1}: @type = ${type}`);
        if (type === 'LocalBusiness') {
            console.log(`  Name: ${parsed.name}`);
            console.log(`  Geo: lat=${parsed.geo?.latitude}, lon=${parsed.geo?.longitude}`);
            console.log(`  Rating: ${parsed.aggregateRating?.ratingValue} (${parsed.aggregateRating?.reviewCount} reviews)`);
        }
        if (type === 'FAQPage') {
            console.log(`  Questions count: ${parsed.mainEntity?.length || 0}`);
        }
    } catch(err) {
        console.log(`Schema #${idx+1}: JSON Parse Error: ${err.message}`);
    }
});
