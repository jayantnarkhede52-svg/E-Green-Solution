with open('c:/work/E GREEN WEBSITE/solar-panel-pune.html', 'r', encoding='utf-8') as f:
    content = f.read()

target = '                    <!-- Frequently Asked Questions -->'

box = '''                    <!-- Local Case Study Callout -->
                    <div style="background: #fff; border: 2px solid #2e7d32; border-radius: 18px; padding: 25px 28px; margin: 30px 0; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 15px;">
                            <div>
                                <span style="background: #2e7d32; color: white; font-size: 12px; font-weight: 700; padding: 4px 12px; border-radius: 20px;"><i class="fas fa-star"></i> Featured Pune Case Study</span>
                                <h3 style="font-size: 20px; color: #0f172a; margin: 10px 0 6px;">Konark A Plus Housing Society (100kW, Sopan Baug, Pune)</h3>
                                <p style="color: #475569; font-size: 14.5px; margin: 0; line-height: 1.6; max-width: 600px;">
                                    Slashed monthly common electricity bills from ₹3.2+ Lakhs down by 90% for lifts, water pumps, and campus lighting with ₹18 Lakhs PM Surya Ghar central subsidy.
                                </p>
                            </div>
                            <a href="/projects/konark-a-plus-100kw-housing-society-solar-pune" class="btn-primary" style="padding: 10px 20px; font-size: 14px; text-decoration: none; align-self: center;">View Case Study &rarr;</a>
                        </div>
                    </div>

                    <!-- Frequently Asked Questions -->'''

if target in content:
    content = content.replace(target, box, 1)
    with open('c:/work/E GREEN WEBSITE/solar-panel-pune.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print("SUCCESS: solar-panel-pune.html updated")
else:
    print("TARGET NOT FOUND in solar-panel-pune.html")
