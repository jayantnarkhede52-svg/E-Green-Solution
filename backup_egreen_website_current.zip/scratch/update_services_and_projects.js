const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');

// 1. Update services.html
const servicesPath = path.join(rootDir, 'services.html');
let servicesContent = fs.readFileSync(servicesPath, 'utf8');

// Commercial Solar link in Row 2
servicesContent = servicesContent.replace(
  '<h2>Commercial & Industrial Solar</h2>',
  '<h2>Commercial Solar Installation Pune</h2>'
);

servicesContent = servicesContent.replace(
  '<a href="/industrial-solar" class="btn-primary" style="margin-top: 15px; font-size: 14px; padding: 10px 20px;">Explore Industrial Solar <i class="fas fa-arrow-right"></i></a>',
  '<a href="/commercial-solar-pune" class="btn-primary" style="margin-top: 15px; font-size: 14px; padding: 10px 20px;">Explore Commercial Solar <i class="fas fa-arrow-right"></i></a>'
);

// Add Industrial Solar button to Row 3
if (!servicesContent.includes('<a href="/industrial-solar" class="btn-primary" style="margin-top: 15px; font-size: 14px; padding: 10px 20px;">Explore Industrial Solar <i class="fas fa-arrow-right"></i></a>')) {
  servicesContent = servicesContent.replace(
    'corridor.</p>\n                        <ul>',
    'corridor.</p>\n                        <a href="/industrial-solar" class="btn-primary" style="margin-top: 15px; font-size: 14px; padding: 10px 20px; display: inline-block;">Explore Industrial Solar <i class="fas fa-arrow-right"></i></a>\n                        <ul style="margin-top: 20px;">'
  );
}

// Add Solar Water Heater button to Row 4
if (!servicesContent.includes('<a href="/solar-water-heater-pune" class="btn-primary"')) {
  servicesContent = servicesContent.replace(
    'operation.</p>\n                        <ul>',
    'operation.</p>\n                        <a href="/solar-water-heater-pune" class="btn-primary" style="margin-top: 15px; font-size: 14px; padding: 10px 20px; display: inline-block;">Explore Solar Water Heaters <i class="fas fa-arrow-right"></i></a>\n                        <ul style="margin-top: 20px;">'
  );
}

fs.writeFileSync(servicesPath, servicesContent, 'utf8');
console.log('Updated services.html with dedicated service links!');

// 2. Update projects.html
const projectsPath = path.join(rootDir, 'projects.html');
let projectsContent = fs.readFileSync(projectsPath, 'utf8');

// Fix canonical link
projectsContent = projectsContent.replace('href="https://egreensolution.in/projects.html"', 'href="https://egreensolution.in/projects"');

// Link Eagle Burgmann project card to case study
const oldEagleCard = `<h3>Eagle Burgmann India</h3>
                        <p><i class="fas fa-industry"></i> 200 kW Flagship Industrial EPC</p>
                        <p style="font-size: 13px; opacity: 0.9; margin-top: 4px;"><i class="fas fa-bolt"></i> 11kV HT Substation Sync</p>`;

const newEagleCard = `<h3>Eagle Burgmann India</h3>
                        <p><i class="fas fa-industry"></i> 200 kW Flagship Industrial EPC</p>
                        <p style="font-size: 13px; opacity: 0.9; margin-top: 4px;"><i class="fas fa-bolt"></i> 11kV HT Substation Sync</p>
                        <a href="/projects/eagle-burgmann-200kw-solar-pune" style="display: inline-block; margin-top: 10px; background: #fbc02d; color: #000; padding: 6px 14px; border-radius: 20px; font-weight: 700; font-size: 12px; text-decoration: none;">View Detailed 200kW Case Study &rarr;</a>`;

projectsContent = projectsContent.replace(oldEagleCard, newEagleCard);

// Add featured case study callout banner before gallery grid
const featuredBanner = `            <!-- Featured Case Study Banner -->
            <div style="background: linear-gradient(135deg, #0f172a, #1e293b); border-radius: 20px; padding: 35px 40px; color: #fff; margin-bottom: 50px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 20px;">
                <div>
                    <span style="background: #2e7d32; color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; text-transform: uppercase;">Featured Case Study</span>
                    <h3 style="font-size: 24px; margin: 10px 0 6px; color: #fff;">Eagle Burgmann 200kW Industrial Rooftop Solar Plant</h3>
                    <p style="color: #94a3b8; font-size: 15px; margin: 0;">Standing seam non-penetrative mounting, MSEDCL HT net metering, and ₹22.5+ Lakhs annual power savings.</p>
                </div>
                <a href="/projects/eagle-burgmann-200kw-solar-pune" class="btn-primary" style="background: #fbc02d; color: #000; font-weight: 700; white-space: nowrap; padding: 12px 25px;">Read Case Study &rarr;</a>
            </div>\n\n`;

if (!projectsContent.includes('Featured Case Study')) {
  projectsContent = projectsContent.replace(
    '<div class="projects-grid">',
    featuredBanner + '            <div class="projects-grid">'
  );
}

fs.writeFileSync(projectsPath, projectsContent, 'utf8');

// Also update projects/index.html to stay synchronized
const projectsIndexPath = path.join(rootDir, 'projects', 'index.html');
fs.writeFileSync(projectsIndexPath, projectsContent, 'utf8');

console.log('Updated projects.html and projects/index.html with featured case study banner and link!');

// 3. Update industrial-solar.html to link to case study
const industrialPath = path.join(rootDir, 'industrial-solar.html');
let industrialContent = fs.readFileSync(industrialPath, 'utf8');

const caseStudyCallout = `
            <!-- Eagle Burgmann Case Study Link -->
            <div style="background: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; padding: 30px; margin-top: 40px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 20px;">
                <div>
                    <span style="background: #e0f2fe; color: #0284c7; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; text-transform: uppercase;">Real Project Proof</span>
                    <h3 style="font-size: 22px; color: #0f172a; margin: 8px 0 4px;">Eagle Burgmann India 200kW Industrial Case Study</h3>
                    <p style="color: #64748b; font-size: 14.5px; margin: 0;">Discover how our engineering team delivered zero-penetration metal roof solar with MSEDCL HT synchronization.</p>
                </div>
                <a href="/projects/eagle-burgmann-200kw-solar-pune" class="btn-primary" style="padding: 10px 22px; font-size: 14px;">Read Full 200kW Case Study &rarr;</a>
            </div>
`;

if (!industrialContent.includes('Eagle Burgmann India 200kW Industrial Case Study')) {
  industrialContent = industrialContent.replace(
    '</section>\n\n    <!-- Process Section -->',
    caseStudyCallout + '\n    </section>\n\n    <!-- Process Section -->'
  );
  fs.writeFileSync(industrialPath, industrialContent, 'utf8');
  console.log('Updated industrial-solar.html with case study link!');
}
