const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const scriptPath = path.join(__dirname, 'apply_split_hero_to_all.js');
let scriptContent = fs.readFileSync(scriptPath, 'utf8');

scriptContent = scriptContent.replace(
  "'blog/elevated-rooftop-solar-structure-pune.html': {\n    eyebrow: 'Terrace Architecture & Usability',\n    title: 'Elevated Rooftop Solar Structure Pune',\n    desc: 'Preserve <span class=\"highlight-mark\">100% of your terrace space</span> for yoga, stargazing, and family gatherings. Custom-engineered <span class=\"highlight-mark\">solar pergolas (7–9.5 ft clearance)</span> that shade your top floor from 40°C heat.',\n    chips: ['7.0 to 9.5 Ft Walking Clearance', '100% Terrace Living Area Preserved', 'Shields Top Floor (3°C–5°C Cooler)', 'Hot-Dip Galvanized & 150 km/h Wind Rated'],\n    rating: '⭐ 4.9/5 Rating (Architectural Pergola Solar)',\n    subject: 'Elevated Structure Inquiry from Blog',\n    pageName: 'elevated-rooftop-solar-structure-pune',\n    reqLabel: 'Terrace Pergola Type',\n    options: ['Elevated Solar Gazebo / Pergola', 'High-Rise Terrace Canopy', 'Bungalow Walking Superstructure', 'Commercial Terrace Solar Pavilion'],\n    btnText: 'Get Elevated Structure Design Quote',\n    replaceRegex: /<header[\\s\\S]*?<\\/header>/i\n  }",
  "'blog/elevated-rooftop-solar-structure-pune.html': {\n    eyebrow: 'Terrace Architecture & Usability',\n    title: 'Elevated Rooftop Solar Structure Pune',\n    desc: 'Preserve <span class=\"highlight-mark\">100% of your terrace space</span> for yoga, stargazing, and family gatherings. Custom-engineered <span class=\"highlight-mark\">solar pergolas (7–9.5 ft clearance)</span> that shade your top floor from 40°C heat.',\n    chips: ['7.0 to 9.5 Ft Walking Clearance', '100% Terrace Living Area Preserved', 'Shields Top Floor (3°C–5°C Cooler)', 'Hot-Dip Galvanized & 150 km/h Wind Rated'],\n    rating: '⭐ 4.9/5 Rating (Architectural Pergola Solar)',\n    subject: 'Elevated Structure Inquiry from Blog',\n    pageName: 'elevated-rooftop-solar-structure-pune',\n    reqLabel: 'Terrace Pergola Type',\n    options: ['Elevated Solar Gazebo / Pergola', 'High-Rise Terrace Canopy', 'Bungalow Walking Superstructure', 'Commercial Terrace Solar Pavilion'],\n    btnText: 'Get Elevated Structure Design Quote',\n    replaceRegex: /<section\\s+style=[\"']background:\\s*linear-gradient[\\s\\S]*?<\\/section>/i\n  }"
);

fs.writeFileSync(scriptPath, scriptContent, 'utf8');
console.log('Updated regex in script!');
