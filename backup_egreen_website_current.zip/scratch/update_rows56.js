const fs = require('fs');

let s = fs.readFileSync('services.html', 'utf8');
s = s.replace('alt="Solar LED Street Lights Maharashtra" width="600" height="400" loading="lazy">', 'alt="Solar LED Street Lights Maharashtra" width="600" height="400" loading="lazy" style="border-radius: 20px; box-shadow: 0 16px 40px rgba(0,0,0,0.12); width: 100%; height: auto; object-fit: cover;">');
s = s.replace('alt="Solar Water Pump Installation" width="600" height="400" loading="lazy">', 'alt="Solar Water Pump Installation" width="600" height="400" loading="lazy" style="border-radius: 20px; box-shadow: 0 16px 40px rgba(0,0,0,0.12); width: 100%; height: auto; object-fit: cover;">');
fs.writeFileSync('services.html', s, 'utf8');
console.log('Updated rows 5 & 6 image styling successfully');
